// টুলবারের আইকনে ক্লিক করলে পেজের প্যানেল দেখাবে/লুকাবে
chrome.action.onClicked.addListener((tab) => {
  if (!tab.id) return;
  chrome.tabs.sendMessage(tab.id, { type: "avh-toggle" }).catch(() => {});
});

// ---------- Telegram ----------
// "এক বট" মোড: token "srv:<সার্ভার>|<id>|<secret>" — সরাসরি Telegram নয়, তোমার সার্ভার দিয়ে (বটের token শুধু সার্ভারে থাকে)
function srvOf(token) {
  const m = /^srv:(https:\/\/[^|]+)\|([A-Za-z0-9]+)\|([A-Za-z0-9]+)$/.exec(String(token || ""));
  return m ? { url: m[1].replace(/\/+$/, ""), id: m[2], sec: m[3] } : null;
}
async function tg(token, method, params) {
  const s = srvOf(token);
  if (s) {
    const r = await fetch(s.url + "/api/tg", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: s.id, sec: s.sec, method, params: params || {} }) });
    return r.json();
  }
  return { ok: false, description: "not linked" }; // ৬.২: শুধু সার্ভারের বট
}
let tgBusy = false;

// ⚡ ৬.৭.২০: সার্ভারের সাথে সরাসরি সংযোগ (WebSocket)। নতুন কমান্ড এলে সার্ভার "জাগো" বলে, সাথে সাথে নেওয়া হয়।
// সংযোগ না থাকলে (পুরনো সার্ভার, নেট সমস্যা) আগের মতো সার্ভারে অপেক্ষা করে নেওয়া — কিছু বদলায় না
const hub = { ws: null, url: "", ok: false, fails: 0, retryAt: 0, waiters: [], ping: null, at: 0, n: 0 };
function hubWake() { hub.pending = true; const w = hub.waiters; hub.waiters = []; for (const f of w) { try { f(); } catch (_) {} } }
function hubEnsure(token) {
  const s = srvOf(token); if (!s || typeof WebSocket === "undefined") return;
  const url = s.url.replace(/^https:/, "wss:") + "/ws?id=" + encodeURIComponent(s.id) + "&sec=" + encodeURIComponent(s.sec);
  if (hub.ws && hub.url === url && hub.ws.readyState <= 1) return;
  if (hub.ws && hub.url !== url) { try { hub.ws.close(); } catch (_) {} hub.ws = null; hub.fails = 0; hub.retryAt = 0; }
  if (Date.now() < hub.retryAt) return;
  let ws; try { ws = new WebSocket(url); } catch (_) { hub.fails++; hub.retryAt = Date.now() + Math.min(600000, 2000 * 2 ** hub.fails); return; }
  hub.ws = ws; hub.url = url; let opened = false;
  ws.onopen = () => { opened = true; hub.ok = true; hub.fails = 0; hub.at = Date.now(); hub.n++; clearInterval(hub.ping); hub.ping = setInterval(() => { try { ws.send("ping"); } catch (_) {} }, 20000); hubWake(); };
  ws.onmessage = (e) => { if (e.data === "pong") return; hubWake(); };
  ws.onclose = () => {
    if (hub.ws === ws) { hub.ws = null; hub.ok = false; clearInterval(hub.ping); }
    if (!opened) hub.fails++; // সার্ভারে Hub নেই বা নেট নেই — ধীরে ধীরে (সর্বোচ্চ ১০ মি.) আবার চেষ্টা
    hub.retryAt = Date.now() + (opened ? 1500 : Math.min(600000, 2000 * 2 ** hub.fails));
    hubWake();
  };
  ws.onerror = () => {};
}
let hubEmpty = 0; // শেষ getUpdates খালি ছিল কিনা — খালি হলে তবেই "জাগো"-র অপেক্ষা
async function tgPoll(token, timeout, watch) {
  const { avhTgOffset = 0 } = await chrome.storage.local.get("avhTgOffset");
  hubEnsure(token);
  if (hub.ok && hubEmpty && !hub.pending) { // সংযোগ আছে: সার্ভারকে বসিয়ে না রেখে নিজে অপেক্ষা (সার্ভারের ডাটাবেস পড়া অনেক কম)
    await new Promise((res) => { const t = setTimeout(res, Math.max(1, +timeout || 25) * 1000); hub.waiters.push(() => { clearTimeout(t); res(); }); });
  }
  hub.pending = false; // এর পরে আসা "জাগো" পরের বারের অপেক্ষা বাদ দেবে (মাঝখানে হারায় না)
  const j = await tg(token, "getUpdates", { offset: avhTgOffset, timeout: hub.ok ? 0 : timeout, watch: +watch || 0, allowed_updates: ["message", "edited_message"] });
  hubEmpty = j && j.ok && !(j.result && j.result.length) ? 1 : 0;
  if (j.ok && j.result && j.result.length) {
    const last = j.result[j.result.length - 1];
    const save = { avhTgOffset: last.update_id + 1 };
    await chrome.storage.local.set(save);
  }
  return j;
}

// ---------- শব্দ (offscreen পেজে বাজে, তাই ব্যবহারকারীর ক্লিক ছাড়াও কাজ করে) ----------
async function beep(kind) {
  if (!chrome.offscreen) return;
  try {
    const has = chrome.offscreen.hasDocument ? await chrome.offscreen.hasDocument() : false;
    if (!has) {
      await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["AUDIO_PLAYBACK"], justification: "Alert sound when trading stops with an error" });
      await new Promise((r) => setTimeout(r, 150));
    }
  } catch (_) {}
  chrome.runtime.sendMessage({ type: "avh-play", kind }).catch(() => {});
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  // ট্যাব লুকানো থাকলে পেজের টাইমার ধীর হয়ে যায়; এখানে অপেক্ষা করে উত্তর দিলে তা হয় না
  if (msg.type === "avh-sleep") {
    const ms = Math.max(0, Math.min(Number(msg.ms) || 0, 5 * 60 * 1000));
    setTimeout(() => { try { sendResponse({ ok: true }); } catch (_) {} }, ms);
    return true;
  }

  // পেজ জমে যাওয়া ধরার জন্য চলমান ট্যাবের শেষ সাড়া
  if (msg.type === "avh-wd") {
    const tab = sender && sender.tab ? sender.tab.id : null;
    chrome.storage.local.set({ avhWd: { on: !!msg.on, heal: !!msg.heal, tab, ts: Date.now() } });
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === "avh-notify") {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icon128.png",
      title: String(msg.title || "Alpha Volume Helper").slice(0, 100),
      message: String(msg.message || "").slice(0, 300),
      priority: 2,
    });
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === "avh-beep") {
    beep(msg.kind || "error").then(() => sendResponse({ ok: true }));
    return true;
  }

  // নতুন ভার্সনের খবর: Sheet-এর "ভার্সন" পাতা
  if (msg.type === "avh-ver") {
    (async () => {
      const url = String(msg.url || "");
      if (!/^https:\/\/script\.google\.com\/macros\//.test(url)) return sendResponse({ ok: false });
      const r = await fetch(url + (url.includes("?") ? "&" : "?") + "a=ver", { cache: "no-store" });
      let j = null; try { j = JSON.parse(await r.text()); } catch (_) {}
      sendResponse(j && j.ok ? j : { ok: false });
    })().catch(() => sendResponse({ ok: false }));
    return true;
  }

  // Google Sheet-এ হিসাব পাঠানো (Apps Script ওয়েব অ্যাপ)
  if (msg.type === "avh-report") {
    (async () => {
      const url = String(msg.url || "");
      if (!/^https:\/\/script\.google\.com\/macros\//.test(url)) return sendResponse({ ok: false, error: "bad url" });
      const r = await fetch(url, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify({ events: msg.events || [] }) });
      const t = await r.text();
      let j = null; try { j = JSON.parse(t); } catch (_) {}
      if (!r.ok || !j || !j.ok) return sendResponse({ ok: false, error: (j && j.error) || (r.ok ? "not JSON (deploy access = Anyone?)" : "HTTP " + r.status) });
      sendResponse({ ok: true, n: j.n });
    })().catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }

  // Binance ট্যাবের ছবি Telegram-এ (/shot, /live) — শুধু যে ট্যাব বার্তা পাঠিয়েছে সেটা সামনে থাকলেই ছবি তোলে
  if (msg.type === "avh-shot") {
    (async () => {
      const tabId = sender.tab && sender.tab.id;
      if (!tabId) return sendResponse({ ok: false, why: "notab" });
      const tab = await chrome.tabs.get(tabId);
      const win = await chrome.windows.get(tab.windowId);
      if (!tab.active || win.state === "minimized") return sendResponse({ ok: false, why: "hidden" });
      const url = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 72 });
      // ছবি তোলার মাঝে অন্য ট্যাব সামনে এলে বাতিল — অন্য ট্যাবের ছবি কখনো যাবে না
      const [act] = await chrome.tabs.query({ active: true, windowId: tab.windowId });
      if (!act || act.id !== tabId) return sendResponse({ ok: false, why: "hidden" });
      const blob = await (await fetch(url)).blob();
      const fd = new FormData();
      fd.append("chat_id", String(msg.chat));
      const cap = String(msg.caption || "").slice(0, 1000);
      let method = "sendPhoto";
      if (msg.editId) {
        method = "editMessageMedia";
        fd.append("message_id", String(msg.editId));
        fd.append("media", JSON.stringify({ type: "photo", media: "attach://p", caption: cap }));
        fd.append("p", blob, "binance.jpg");
      } else {
        fd.append("caption", cap);
        fd.append("photo", blob, "binance.jpg");
      }
      const sv = srvOf(msg.token);
      if (!sv) return sendResponse({ ok: false, why: "tg", description: "not linked" });
      if (msg.toSrv) { // Mini App-এর জন্য: ছবি সার্ভারে (Telegram-এ নয়)
        const f2 = new FormData(); f2.append("id", sv.id); f2.append("sec", sv.sec); f2.append("photo", blob, "binance.jpg");
        const j2 = await (await fetch(`${sv.url}/api/shotpush`, { method: "POST", body: f2 })).json().catch(() => null);
        return sendResponse(j2 && j2.ok ? { ok: true } : { ok: false, why: "err", description: (j2 && j2.description) || "" });
      }
      fd.append("id", sv.id); fd.append("sec", sv.sec);
      const r = await fetch(`${sv.url}/api/upload?method=${method}`, { method: "POST", body: fd });
      const j = await r.json();
      if (!j.ok) return sendResponse({ ok: false, why: "tg", description: j.description || "" });
      sendResponse({ ok: true, id: j.result && j.result.message_id });
    })().catch((e) => sendResponse({ ok: false, why: "err", description: String(e.message || e) }));
    return true;
  }

  // Groq (OpenAI-ধাঁচের API) — দ্রুত, ফ্রি কোটা
  // OpenRouter: চালু ফ্রি মডেলের তালিকা (৬ ঘণ্টা মনে রাখা)
  if (msg.type === "avh-or-models") {
    (async () => {
      const { avhOrModels: c } = await chrome.storage.local.get("avhOrModels");
      if (c && Date.now() - c.at < 6 * 3600000 && c.list && c.list.length) return sendResponse({ ok: true, models: c.list });
      const r = await fetch("https://openrouter.ai/api/v1/models");
      const j = await r.json();
      const PREF = [/gpt-oss/i, /gemma-4-31b/i, /nemotron-3-super/i, /minimax/i, /gemma-4-26b/i, /deepseek/i, /qwen/i, /nemotron-3\.5-lightning/i, /llama/i];
      const rank = (id) => { const i = PREF.findIndex((re) => re.test(id)); return i < 0 ? 99 : i; };
      const list = (j.data || []).filter((m) => /:free$/.test(m.id) && !/safety|guard|embed|code|coder|-vl|omni|vision|audio|tts|whisper|image|ocr/i.test(m.id))
        .sort((a, b) => {
          const ja = (a.supported_parameters || []).some((p) => /response_format|structured_outputs/.test(p)) ? 0 : 1;
          const jb = (b.supported_parameters || []).some((p) => /response_format|structured_outputs/.test(p)) ? 0 : 1;
          return ja - jb || rank(a.id) - rank(b.id);
        }).map((m) => m.id).slice(0, 10);
      if (list.length) await chrome.storage.local.set({ avhOrModels: { at: Date.now(), list } });
      sendResponse({ ok: !!list.length, models: list });
    })().catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }

  if (msg.type === "avh-ai" && msg.prov === "openrouter") {
    (async () => {
      const model = /^[a-z0-9.\-\/_:]+$/i.test(String(msg.model || "")) ? msg.model : "openai/gpt-oss-20b";
      const t0 = Date.now();
      const ac = new AbortController(); const tm = setTimeout(() => ac.abort(), 55000);
      const send = (x) => fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST", signal: ac.signal,
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + String(msg.key || ""), "X-Title": "Alpha Volume Helper" },
        body: JSON.stringify({ model, temperature: 0.2, max_tokens: 800, ...x,
          messages: [{ role: "system", content: "You are a trading assistant. Reply with a single JSON object only, no other text." }, { role: "user", content: String(msg.prompt || "").slice(0, 8000) }] }),
      });
      let r, j;
      try {
        // Claude-এ reasoning দিলে উল্টো "ভাবা" চালু হয় (ধীর, দামি) — তাই শুধু অন্য মডেলে
        r = await send(/anthropic|claude/i.test(model) ? { response_format: { type: "json_object" } } : { response_format: { type: "json_object" }, reasoning: { effort: "low", exclude: true } });
        j = await r.json().catch(() => null);
        // মডেল JSON-মোড/ভাবনা-সেটিং না মানলে ছাড়াই আবার
        if (r.status === 400) { r = await send({}); j = await r.json().catch(() => null); }
      } catch (e) {
        return sendResponse({ ok: false, error: e.name === "AbortError" ? "OpenRouter 55 সে.-এ উত্তর দেয়নি" : String(e.message || e) });
      } finally { clearTimeout(tm); }
      const em = j && j.error && (j.error.message || j.error.code);
      if (!r.ok || !j || em) return sendResponse({ ok: false, error: (r.status ? r.status + " " : "") + (em || "HTTP " + r.status) + (j && j.error && j.error.metadata && j.error.metadata.raw ? " · " + String(j.error.metadata.raw).slice(0, 120) : "") });
      const txt = String((((j.choices || [])[0] || {}).message || {}).content || "").replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
      let out = null; try { out = JSON.parse(txt.replace(/^```(json)?|```$/g, "").trim()); } catch (_) {}
      if (!out) { const m = txt.match(/\{[\s\S]*\}/); if (m) try { out = JSON.parse(m[0]); } catch (_) {} }
      if (!out) return sendResponse({ ok: false, error: "AI-র উত্তর বোঝা যায়নি" });
      sendResponse({ ok: true, json: out, ms: Date.now() - t0 });
    })().catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }

  if (msg.type === "avh-ai" && msg.prov === "groq") {
    (async () => {
      const model = /^[a-z0-9.\-\/_:]+$/i.test(String(msg.model || "")) ? msg.model : "qwen/qwen3.8-27b";
      const t0 = Date.now();
      const ac = new AbortController(); const tm = setTimeout(() => ac.abort(), 55000);
      let r, j;
      // "ভাবা" কম রাখো (টোকেন ও সময় বাঁচে): gpt-oss → reasoning_effort low, qwen → ভাবনা লুকানো; মডেল না মানলে এগুলো ছাড়াই আবার
      const extra = /gpt-oss/i.test(model) ? { reasoning_effort: "low" } : /qwen/i.test(model) ? { reasoning_format: "hidden" } : {};
      const send = (x) => fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST", signal: ac.signal,
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + String(msg.key || "") },
        body: JSON.stringify({ model, temperature: 0.2, max_tokens: 1024, response_format: { type: "json_object" }, ...x,
          messages: [{ role: "system", content: "You are a trading assistant. Reply with a single JSON object only." }, { role: "user", content: String(msg.prompt || "").slice(0, 8000) }] }),
      });
      try {
        r = await send(extra);
        j = await r.json().catch(() => null);
        if (r.status === 400 && Object.keys(extra).length && /reasoning/i.test(JSON.stringify(j || {}))) { r = await send({}); j = await r.json().catch(() => null); }
      } catch (e) {
        return sendResponse({ ok: false, error: e.name === "AbortError" ? "Groq 55 সে.-এ উত্তর দেয়নি" : String(e.message || e) });
      } finally { clearTimeout(tm); }
      if (!r.ok || !j) return sendResponse({ ok: false, error: (j && j.error && (j.error.message || j.error.code)) || "HTTP " + r.status });
      const txt = String((((j.choices || [])[0] || {}).message || {}).content || "").replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
      let out = null; try { out = JSON.parse(txt.replace(/^```(json)?|```$/g, "").trim()); } catch (_) {}
      if (!out) { const m = txt.match(/\{[\s\S]*\}/); if (m) try { out = JSON.parse(m[0]); } catch (_) {} }
      if (!out) return sendResponse({ ok: false, error: "AI-র উত্তর বোঝা যায়নি" });
      sendResponse({ ok: true, json: out, ms: Date.now() - t0 });
    })().catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }

  if (msg.type === "avh-tg-edit") {
    tg(msg.token, "editMessageCaption", { chat_id: msg.chat, message_id: msg.id, caption: String(msg.caption || "").slice(0, 1000) })
      .then((j) => sendResponse(j)).catch(() => sendResponse({ ok: false }));
    return true;
  }

  // Telegram-এর "/" মেনুতে কমান্ডের তালিকা
  if (msg.type === "avh-tg-cmds") {
    tg(msg.token, "setMyCommands", { commands: (msg.commands || []).slice(0, 100) })
      .then((j) => sendResponse(j))
      .catch((e) => sendResponse({ ok: false, description: String(e.message || e) }));
    return true;
  }
  if (msg.type === "avh-tg-send") {
    tg(msg.token, "sendMessage", Object.assign({ chat_id: msg.chat, text: String(msg.text || "").slice(0, 4000) }, msg.markup ? { reply_markup: msg.markup } : {}))
      .then((j) => sendResponse(j))
      .catch((e) => sendResponse({ ok: false, description: String(e.message || e) }));
    return true;
  }

  // Telegram বট খোলা — শুধু t.me লিংক
  if (msg.type === "avh-open") {
    const u = String(msg.url || ""); // t.me বট, বা সার্ভারের 👤 প্রোফাইল পাতা
    if (!/^https:\/\/t\.me\/[A-Za-z0-9_]{3,40}(\?start=[A-Za-z0-9_]{1,64})?$/.test(u) && !/^https:\/\/[a-z0-9.-]+\/me#t=[A-Za-z0-9.]{20,200}$/.test(u)) { sendResponse({ ok: false }); return; }
    chrome.tabs.create({ url: u, active: true }).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;
  }
  // ইনলাইন বোতামের উত্তর ইত্যাদি (শুধু নির্দিষ্ট কয়েকটা)
  if (msg.type === "avh-tg-call") {
    if (!["answerCallbackQuery", "editMessageText"].includes(msg.method)) { sendResponse({ ok: false }); return; }
    tg(msg.token, msg.method, msg.params || {}).then((j) => sendResponse(j)).catch((e) => sendResponse({ ok: false, description: String(e.message || e) }));
    return true;
  }
  // এক বট: সার্ভারের সাথে কোড/অবস্থা/বিচ্ছিন্ন (শুধু https)
  if (msg.type === "avh-srv") {
    if (!/^https:\/\/[^/]+\/api\/[a-z]{2,20}$/.test(String(msg.url || ""))) { sendResponse({ ok: false, description: "bad url" }); return; }
    fetch(msg.url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(msg.body || {}) })
      .then((r) => r.json()).then((j) => sendResponse(j))
      .catch((e) => sendResponse({ ok: false, description: String(e.message || e) }));
    return true;
  }
  // ৬.৭.১১: চলার সময় Chrome যেন ট্যাব বন্ধ/ঘুম না করে; আর অন্য ট্যাব ব্যবহারের জন্য আলাদা উইন্ডো
  if (msg.type === "avh-hub") { sendResponse({ ok: hub.ok, since: hub.at, n: hub.n, fails: hub.fails }); return; }
  if (msg.type === "avh-keep") {
    const id = sender.tab && sender.tab.id; if (!id) { sendResponse({ ok: false }); return; }
    chrome.tabs.update(id, { autoDiscardable: false }).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (msg.type === "avh-winmax") { // উইন্ডো পুরো বড় না থাকলে বড় করা (ছোট হলে পাতার রূপ বদলে Sell আটকায়)
    (async () => {
      const id = sender.tab && sender.tab.id; if (!id) return sendResponse({ ok: false });
      const w = await chrome.windows.get((await chrome.tabs.get(id)).windowId);
      if (w.state === "maximized" || w.state === "fullscreen") return sendResponse({ ok: true, changed: false, state: w.state });
      await chrome.windows.update(w.id, { state: "maximized" });
      sendResponse({ ok: true, changed: true, from: w.state });
    })().catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }
  if (msg.type === "avh-ownwin") {
    (async () => {
      const id = sender.tab && sender.tab.id; if (!id) return sendResponse({ ok: false });
      const tab = await chrome.tabs.get(id), all = await chrome.tabs.query({ windowId: tab.windowId });
      // ৬.৭.২৩: ছোট উইন্ডোতে Binance পাতার ছোট রূপ আসে (Sell অংশ ঠিকমতো পড়া যায় না) — তাই সবসময় পুরো বড় (maximized)
      if (all.length <= 1) { await chrome.windows.update(tab.windowId, { focused: true, state: "maximized" }); return sendResponse({ ok: true, already: true }); }
      await chrome.windows.create({ tabId: id, focused: true, state: "maximized" });
      sendResponse({ ok: true });
    })().catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }
  // 📋 CSV ফাইল Telegram-এ (সার্ভার হয়ে)
  if (msg.type === "avh-doc") {
    (async () => {
      const sv = srvOf(msg.token); if (!sv) return sendResponse({ ok: false, description: "no server" });
      const fd = new FormData(); fd.append("id", sv.id); fd.append("sec", sv.sec); fd.append("caption", String(msg.caption || "").slice(0, 1000));
      fd.append("document", new Blob([String(msg.text || "")], { type: "text/csv" }), String(msg.name || "rounds.csv").replace(/[^\w.-]/g, "_"));
      const r = await fetch(`${sv.url}/api/upload?method=sendDocument`, { method: "POST", body: fd });
      sendResponse(await r.json());
    })().catch((e) => sendResponse({ ok: false, description: String(e.message || e) }));
    return true;
  }
  if (msg.type === "avh-tg-poll") {
    if (tgBusy) { sendResponse({ busy: true }); return; }
    tgBusy = true;
    tgPoll(msg.token, 25, msg.watch)
      .then((j) => sendResponse(j))
      .catch((e) => sendResponse({ ok: false, description: String(e.message || e) }))
      .finally(() => { tgBusy = false; });
    return true;
  }

});

// ---------- নিজে সারানো: চলমান Binance ট্যাব ৪ মিনিট সাড়া না দিলে (জমে গেছে/Chrome ঘুম পাড়িয়েছে) রিলোড ----------
try { chrome.alarms.create("avh-wd", { periodInMinutes: 1 }); } catch (_) {}
if (chrome.alarms) chrome.alarms.onAlarm.addListener(async (a) => {
  if (!a || a.name !== "avh-wd") return;
  const { avhWd: w, avhHeal: h0 } = await chrome.storage.local.get(["avhWd", "avhHeal"]);
  if (!w || !w.on || !w.heal || w.tab == null || Date.now() - w.ts < 4 * 60000) return;
  await chrome.storage.local.set({ avhWd: { ...w, on: false } }); // একবারই — পেজ আবার চললে নিজে চালু করবে
  const h = (h0 || []).filter((t) => Date.now() - t < 3600000);
  if (h.length >= 3) return;
  let tab = null;
  try { tab = await chrome.tabs.get(w.tab); } catch (_) { return; }
  if (!tab || !/binance\.com\/.*alpha/i.test(tab.url || "")) return;
  h.push(Date.now());
  await chrome.storage.local.set({ avhHeal: h, avhReloadAt: Date.now(), avhHealWhy: "frozen" });
  try { await chrome.tabs.reload(w.tab); } catch (_) {}
});

// ======================= 👁 ৬.৯.১২ পাহারাদার পেছনে =======================
// Chrome খোলা থাকলেই (Binance-এর পাতা খোলা না থাকলেও) Binance Alpha-র খোলা বাজারের ডাটা মেপে সার্ভারে পাঠায়।
// কাজ ভাগ: সার্ভার অনলাইনের সব এক্সটেনশনের মধ্যে টোকেন ভাগ করে দেয় — বেশি পিসি অনলাইন থাকলে প্রত্যেকে কম, একটা থাকলে সেটাই সব।
// লগইন/কুকি ছাড়া (credentials: omit) — শুধু খোলা ডাটা। সেটিংসে "🩺 ভাগ করে বাজার দেখা" বা "👁 পাহারাদার" বন্ধ করলে বন্ধ।
let MK_SRV = "https://avh-bot.yahiahossain24.workers.dev";
let MK_BN = "https://www.binance.com/bapi/defi/v1/public";
let mkBusy = false;
const mkSym = (id) => (/^ALPHA_/i.test(id) ? String(id).toUpperCase() : "ALPHA_" + id) + "USDT";
async function mkCfg() {
  const { avhCfg: c, avhMkTest: t } = await chrome.storage.local.get(["avhCfg", "avhMkTest"]);
  if (t && /^http:\/\/127\.0\.0\.1:\d+$/.test(t.srv || "")) { MK_SRV = t.srv; MK_BN = t.srv + "/bapi/defi/v1/public"; } // শুধু নিজের পিসির টেস্টের জন্য
  return c && c.tgId && c.tgSec && c.tgSChat && c.mktShare !== false && c.mktWatch !== false ? c : null;
}
async function bnGet(p) {
  const r = await fetch(MK_BN + p, { credentials: "omit", headers: { clienttype: "web" } });
  if (!r.ok) throw new Error("HTTP " + r.status);
  const j = await r.json();
  if (!j || (j.code != null && String(j.code) !== "000000")) throw new Error("code " + (j && j.code));
  return j.data;
}
async function mkPost(c, path, body) {
  const r = await fetch(MK_SRV + path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: c.tgId, sec: c.tgSec, ...body }) });
  return r.json();
}
function mkBook(d) {
  if (!d) return null;
  let B = (d.bids || []).map((x) => [+x[0], +x[1]]).filter((x) => x[0] > 0 && x[1] > 0).sort((a, b) => b[0] - a[0]);
  let A = (d.asks || []).map((x) => [+x[0], +x[1]]).filter((x) => x[0] > 0 && x[1] > 0).sort((a, b) => a[0] - b[0]);
  if (!B.length || !A.length) return null;
  if (A[0][0] < B[0][0]) { const m0 = (A[0][0] + B[0][0]) / 2; A = A.filter((x) => x[0] >= m0); B = B.filter((x) => x[0] <= m0); if (!A.length || !B.length) return null; } // ৬.৯.১৩: খুব দ্রুত টোকেনে বুক এক মুহূর্ত উল্টো (crossed) থাকে — আগে পুরো মাপ বাদ যেত (CT)
  const mid = (A[0][0] + B[0][0]) / 2;
  const fill = (L, usd, buy) => { let left = usd, qty = 0; for (const [p, q] of L) { const v = p * q; if (v >= left) { qty += left / p; left = 0; break; } qty += q; left -= v; } if (left > 0) return null; const avg = usd / qty; return (buy ? avg - mid : mid - avg) / mid * 100; };
  const rt = (u) => { const b = fill(A, u, true), s = fill(B, u, false); return b == null || s == null ? 99 : +(b + s).toFixed(4); };
  const dep = Math.min(A.filter((x) => x[0] <= mid * 1.02).reduce((s, x) => s + x[0] * x[1], 0), B.filter((x) => x[0] >= mid * 0.98).reduce((s, x) => s + x[0] * x[1], 0));
  return { sp: +(((A[0][0] - B[0][0]) / mid) * 100).toFixed(4), rt: rt(100), rt1k: rt(1000), dep: Math.round(dep) };
}
const isMk = (x) => { const v = x.m != null ? x.m : x.isBuyerMaker; return v === true || v === 1 || v === "true" || v === "1"; };
function mkTrades(data) {
  const L = (Array.isArray(data) ? data : []).map((x) => ({ t: +(x.T != null ? x.T : x.time), m: isMk(x) })).filter((x) => x.t > 0).sort((a, b) => a.t - b.t);
  if (L.length < 10) return null;
  const span = Math.max(0.05, (L[L.length - 1].t - L[0].t) / 60000), buys = L.filter((x) => !x.m).length, sells = L.length - buys, g = [];
  for (let i = 1; i < L.length; i++) g.push((L[i].t - L[i - 1].t) / 1000); g.sort((a, b) => a - b);
  return { tpm: +Math.min(600, L.length / span).toFixed(2), bal: buys && sells ? +(Math.min(buys, sells) / Math.max(buys, sells)).toFixed(2) : null, gap: +g[Math.floor(g.length / 2)].toFixed(1) };
}
function mkKlines(rows) {
  const k = (Array.isArray(rows) ? rows : []).map((x) => (Array.isArray(x) ? x : [x.openTime, x.open, x.high, x.low, x.close, x.volume])).map((a) => ({ o: +a[1], h: +a[2], l: +a[3], c: +a[4], v: +a[5] || 0 })).filter((x) => x.c > 0);
  if (k.length < 15) return null;
  const z = k.slice(-20), last = k[k.length - 1].c, f5 = k[Math.max(0, k.length - 6)].c, f0 = k[0].o;
  return { rng: +(z.reduce((a, x) => a + ((x.h - x.l) / x.c) * 100, 0) / z.length).toFixed(3), chg30: +(((last - f0) / f0) * 100).toFixed(2), chg5: +(((last - f5) / f5) * 100).toFixed(2), flat: +(z.filter((x) => x.h === x.l).length / z.length).toFixed(2), qv: Math.round(k.reduce((a, x) => a + x.v * x.c, 0)) };
}
function mkCand(list) {
  const num = (...a) => { for (const x of a) { const v = parseFloat(x); if (isFinite(v) && v > 0) return v; } return 0; };
  const best = new Map();
  for (const t of list || []) { if (!t || t.alphaId == null || t.offline || t.offsell) continue; const k = String(t.contractAddress || "").toLowerCase(), o = best.get(k); if (!o || (num(t.count24h) || num(t.volume24h)) > (num(o.count24h) || num(o.volume24h))) best.set(k, t); }
  return [...best.values()].filter((t) => /^0x[0-9a-fA-F]{40}$/.test(String(t.contractAddress || "")))
    .map((t) => ({ tok: String(t.contractAddress).toLowerCase(), sym: String(t.symbol || t.name || t.alphaId).slice(0, 20), id: String(t.alphaId), v: num(t.volume24h, t.volume24H, t.volume), mp: num(t.mulPoint, t.mulPoints, t.multiplier) || 1, ch: String(t.chainId || ""), liq: num(t.liquidity), n24: num(t.count24h) }))
    .filter((c) => c.mp > 1 || (c.v >= 50000 && (!c.liq || c.liq >= 30000) && (!c.n24 || c.n24 >= 20000)))
    .sort((a, b) => (b.mp > 1) - (a.mp > 1) || (b.n24 || 0) - (a.n24 || 0) || b.v - a.v).slice(0, 60);
}
async function mkMeasure(j, full) {
  const s = encodeURIComponent(mkSym(j.id));
  const [bk, ac, m] = await Promise.all([
    bnGet(`/alpha-trade/fullDepth?symbol=${s}&limit=100`).then(mkBook).catch(() => null),
    bnGet(`/alpha-trade/agg-trades?symbol=${s}&limit=300`).then(mkTrades).catch(() => null),
    full ? bnGet(`/alpha-trade/klines?symbol=${s}&interval=1m&limit=30`).then(mkKlines).catch(() => null) : null]);
  return { tok: j.tok, sym: j.sym, id: j.id, bk, ac, m };
}
async function mkRound(c, st) {
  if (Date.now() - (st.at || 0) >= 55000) { // মিনিটে একবার: সার্ভার থেকে কাজ নেওয়া + আগের মাপ পাঠানো
    st.at = Date.now();
    const body = { bg: true, want: 3, fastOk: true, own: { tok: "" }, dones: st.dones || [] };
    if (st.needCand) { try { body.cand = mkCand(await bnGet("/wallet-direct/buw/wallet/cex/alpha/all/token/list")); } catch (_) {} }
    st.dones = [];
    const r = await mkPost(c, "/api/mkt", body);
    if (r && r.ok) { st.jobs = (r.jobs || []).filter((j) => j && j.id && j.tok); st.fast = (r.fast || []).filter((j) => j && j.id && j.tok); st.needCand = !!r.needCand; st.full = 0; }
    for (const j of st.jobs || []) { const x = await mkMeasure(j, true); if (x.m) st.dones.push(x); }
    st.jobs = [];
  }
  if ((st.fast || []).length) { // ১০ সেকেন্ডে: আমার ভাগের ৪x/২x টোকেন (মিনিটে একবার দামসহ)
    const full = (st.full = (st.full || 0) + 1) % 6 === 1;
    const items = (await Promise.all(st.fast.slice(0, 8).map((j) => mkMeasure(j, full)))).filter((x) => x.bk || x.ac).map((x) => (x.m ? x : { tok: x.tok, sym: x.sym, id: x.id, bk: x.bk, ac: x.ac }));
    if (items.length) { const r2 = await mkPost(c, "/api/mkf", { items }); if (r2 && r2.ok && r2.lease === false) st.fast = []; }
  }
}
async function mkTickBg() {
  if (mkBusy) return;
  const c = await mkCfg().catch(() => null); if (!c) return;
  mkBusy = true;
  try {
    const { avhMkSt: st0 } = await chrome.storage.local.get("avhMkSt"), st = st0 || {};
    const t0 = Date.now();
    for (let k = 0; k < 3; k++) { // ৩০ সেকেন্ডের alarm-এ ১০ সেকেন্ড পরপর তিন বার
      await mkRound(c, st).catch(() => {});
      st.bgAt = Date.now(); await chrome.storage.local.set({ avhMkSt: st }); // (এক্সটেনশনের কাজ Chrome-কে জাগিয়ে রাখে)
      if (k < 2) await new Promise((r) => setTimeout(r, Math.max(0, t0 + (k + 1) * 10000 - Date.now())));
    }
  } finally { mkBusy = false; }
}
try { chrome.alarms.create("avh-mk", { periodInMinutes: 0.5 }); } catch (_) {}
if (chrome.alarms) chrome.alarms.onAlarm.addListener((a) => { if (a && a.name === "avh-mk") mkTickBg(); });
setTimeout(mkTickBg, 5000);
