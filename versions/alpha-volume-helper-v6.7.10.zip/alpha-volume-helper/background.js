// টুলবারের আইকনে ক্লিক করলে পেজের প্যানেল দেখাবে/লুকাবে
chrome.action.onClicked.addListener((tab) => {
  if (!tab.id) return;
  chrome.tabs.sendMessage(tab.id, { type: "avh-toggle" }).catch(() => {});
});

// ---------- Telegram ----------
// "এক বট" মোড: token "srv:<সার্ভার>|<id>|<secret>" — সরাসরি Telegram নয়, তোমার সার্ভার দিয়ে (বটের token শুধু সার্ভারে থাকে)
function srvOf(token) {
  const m = /^srv:(https:\/\/[^|]+)\|([A-Za-z0-9]+)\|([A-Za-z0-9]+)$/.exec(String(token || ""));
  return m ? { url: m[1].replace(/\/+$/, ""), id: m[2], sec: m[3] } : null;
}
async function tg(token, method, params) {
  const s = srvOf(token);
  if (s) {
    const r = await fetch(s.url + "/api/tg", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: s.id, sec: s.sec, method, params: params || {} }) });
    return r.json();
  }
  return { ok: false, description: "not linked" }; // ৬.২: শুধু সার্ভারের বট
}
let tgBusy = false;

async function tgPoll(token, timeout, watch) {
  const { avhTgOffset = 0 } = await chrome.storage.local.get("avhTgOffset");
  const j = await tg(token, "getUpdates", { offset: avhTgOffset, timeout, watch: +watch || 0, allowed_updates: ["message", "edited_message"] });
  if (j.ok && j.result && j.result.length) {
    const last = j.result[j.result.length - 1];
    const save = { avhTgOffset: last.update_id + 1 };
    await chrome.storage.local.set(save);
  }
  return j;
}

// ---------- শব্দ (offscreen পেজে বাজে, তাই ব্যবহারকারীর ক্লিক ছাড়াও কাজ করে) ----------
async function beep(kind) {
  if (!chrome.offscreen) return;
  try {
    const has = chrome.offscreen.hasDocument ? await chrome.offscreen.hasDocument() : false;
    if (!has) {
      await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: ["AUDIO_PLAYBACK"], justification: "Alert sound when trading stops with an error" });
      await new Promise((r) => setTimeout(r, 150));
    }
  } catch (_) {}
  chrome.runtime.sendMessage({ type: "avh-play", kind }).catch(() => {});
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  // ট্যাব লুকানো থাকলে পেজের টাইমার ধীর হয়ে যায়; এখানে অপেক্ষা করে উত্তর দিলে তা হয় না
  if (msg.type === "avh-sleep") {
    const ms = Math.max(0, Math.min(Number(msg.ms) || 0, 5 * 60 * 1000));
    setTimeout(() => { try { sendResponse({ ok: true }); } catch (_) {} }, ms);
    return true;
  }

  // পেজ জমে যাওয়া ধরার জন্য চলমান ট্যাবের শেষ সাড়া
  if (msg.type === "avh-wd") {
    const tab = sender && sender.tab ? sender.tab.id : null;
    chrome.storage.local.set({ avhWd: { on: !!msg.on, heal: !!msg.heal, tab, ts: Date.now() } });
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === "avh-notify") {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icon128.png",
      title: String(msg.title || "Alpha Volume Helper").slice(0, 100),
      message: String(msg.message || "").slice(0, 300),
      priority: 2,
    });
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === "avh-beep") {
    beep(msg.kind || "error").then(() => sendResponse({ ok: true }));
    return true;
  }

  // নতুন ভার্সনের খবর: Sheet-এর "ভার্সন" পাতা
  if (msg.type === "avh-ver") {
    (async () => {
      const url = String(msg.url || "");
      if (!/^https:\/\/script\.google\.com\/macros\//.test(url)) return sendResponse({ ok: false });
      const r = await fetch(url + (url.includes("?") ? "&" : "?") + "a=ver", { cache: "no-store" });
      let j = null; try { j = JSON.parse(await r.text()); } catch (_) {}
      sendResponse(j && j.ok ? j : { ok: false });
    })().catch(() => sendResponse({ ok: false }));
    return true;
  }

  // Google Sheet-এ হিসাব পাঠানো (Apps Script ওয়েব অ্যাপ)
  if (msg.type === "avh-report") {
    (async () => {
      const url = String(msg.url || "");
      if (!/^https:\/\/script\.google\.com\/macros\//.test(url)) return sendResponse({ ok: false, error: "bad url" });
      const r = await fetch(url, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify({ events: msg.events || [] }) });
      const t = await r.text();
      let j = null; try { j = JSON.parse(t); } catch (_) {}
      if (!r.ok || !j || !j.ok) return sendResponse({ ok: false, error: (j && j.error) || (r.ok ? "not JSON (deploy access = Anyone?)" : "HTTP " + r.status) });
      sendResponse({ ok: true, n: j.n });
    })().catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }

  // Binance ট্যাবের ছবি Telegram-এ (/shot, /live) — শুধু যে ট্যাব বার্তা পাঠিয়েছে সেটা সামনে থাকলেই ছবি তোলে
  if (msg.type === "avh-shot") {
    (async () => {
      const tabId = sender.tab && sender.tab.id;
      if (!tabId) return sendResponse({ ok: false, why: "notab" });
      const tab = await chrome.tabs.get(tabId);
      const win = await chrome.windows.get(tab.windowId);
      if (!tab.active || win.state === "minimized") return sendResponse({ ok: false, why: "hidden" });
      const url = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 72 });
      // ছবি তোলার মাঝে অন্য ট্যাব সামনে এলে বাতিল — অন্য ট্যাবের ছবি কখনো যাবে না
      const [act] = await chrome.tabs.query({ active: true, windowId: tab.windowId });
      if (!act || act.id !== tabId) return sendResponse({ ok: false, why: "hidden" });
      const blob = await (await fetch(url)).blob();
      const fd = new FormData();
      fd.append("chat_id", String(msg.chat));
      const cap = String(msg.caption || "").slice(0, 1000);
      let method = "sendPhoto";
      if (msg.editId) {
        method = "editMessageMedia";
        fd.append("message_id", String(msg.editId));
        fd.append("media", JSON.stringify({ type: "photo", media: "attach://p", caption: cap }));
        fd.append("p", blob, "binance.jpg");
      } else {
        fd.append("caption", cap);
        fd.append("photo", blob, "binance.jpg");
      }
      const sv = srvOf(msg.token);
      if (!sv) return sendResponse({ ok: false, why: "tg", description: "not linked" });
      if (msg.toSrv) { // Mini App-এর জন্য: ছবি সার্ভারে (Telegram-এ নয়)
        const f2 = new FormData(); f2.append("id", sv.id); f2.append("sec", sv.sec); f2.append("photo", blob, "binance.jpg");
        const j2 = await (await fetch(`${sv.url}/api/shotpush`, { method: "POST", body: f2 })).json().catch(() => null);
        return sendResponse(j2 && j2.ok ? { ok: true } : { ok: false, why: "err", description: (j2 && j2.description) || "" });
      }
      fd.append("id", sv.id); fd.append("sec", sv.sec);
      const r = await fetch(`${sv.url}/api/upload?method=${method}`, { method: "POST", body: fd });
      const j = await r.json();
      if (!j.ok) return sendResponse({ ok: false, why: "tg", description: j.description || "" });
      sendResponse({ ok: true, id: j.result && j.result.message_id });
    })().catch((e) => sendResponse({ ok: false, why: "err", description: String(e.message || e) }));
    return true;
  }

  // Groq (OpenAI-ধাঁচের API) — দ্রুত, ফ্রি কোটা
  // OpenRouter: চালু ফ্রি মডেলের তালিকা (৬ ঘণ্টা মনে রাখা)
  if (msg.type === "avh-or-models") {
    (async () => {
      const { avhOrModels: c } = await chrome.storage.local.get("avhOrModels");
      if (c && Date.now() - c.at < 6 * 3600000 && c.list && c.list.length) return sendResponse({ ok: true, models: c.list });
      const r = await fetch("https://openrouter.ai/api/v1/models");
      const j = await r.json();
      const PREF = [/gpt-oss/i, /gemma-4-31b/i, /nemotron-3-super/i, /minimax/i, /gemma-4-26b/i, /deepseek/i, /qwen/i, /nemotron-3\.5-lightning/i, /llama/i];
      const rank = (id) => { const i = PREF.findIndex((re) => re.test(id)); return i < 0 ? 99 : i; };
      const list = (j.data || []).filter((m) => /:free$/.test(m.id) && !/safety|guard|embed|code|coder|-vl|omni|vision|audio|tts|whisper|image|ocr/i.test(m.id))
        .sort((a, b) => {
          const ja = (a.supported_parameters || []).some((p) => /response_format|structured_outputs/.test(p)) ? 0 : 1;
          const jb = (b.supported_parameters || []).some((p) => /response_format|structured_outputs/.test(p)) ? 0 : 1;
          return ja - jb || rank(a.id) - rank(b.id);
        }).map((m) => m.id).slice(0, 10);
      if (list.length) await chrome.storage.local.set({ avhOrModels: { at: Date.now(), list } });
      sendResponse({ ok: !!list.length, models: list });
    })().catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }

  if (msg.type === "avh-ai" && msg.prov === "openrouter") {
    (async () => {
      const model = /^[a-z0-9.\-\/_:]+$/i.test(String(msg.model || "")) ? msg.model : "openai/gpt-oss-20b";
      const t0 = Date.now();
      const ac = new AbortController(); const tm = setTimeout(() => ac.abort(), 55000);
      const send = (x) => fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST", signal: ac.signal,
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + String(msg.key || ""), "X-Title": "Alpha Volume Helper" },
        body: JSON.stringify({ model, temperature: 0.2, max_tokens: 800, ...x,
          messages: [{ role: "system", content: "You are a trading assistant. Reply with a single JSON object only, no other text." }, { role: "user", content: String(msg.prompt || "").slice(0, 8000) }] }),
      });
      let r, j;
      try {
        // Claude-এ reasoning দিলে উল্টো "ভাবা" চালু হয় (ধীর, দামি) — তাই শুধু অন্য মডেলে
        r = await send(/anthropic|claude/i.test(model) ? { response_format: { type: "json_object" } } : { response_format: { type: "json_object" }, reasoning: { effort: "low", exclude: true } });
        j = await r.json().catch(() => null);
        // মডেল JSON-মোড/ভাবনা-সেটিং না মানলে ছাড়াই আবার
        if (r.status === 400) { r = await send({}); j = await r.json().catch(() => null); }
      } catch (e) {
        return sendResponse({ ok: false, error: e.name === "AbortError" ? "OpenRouter 55 সে.-এ উত্তর দেয়নি" : String(e.message || e) });
      } finally { clearTimeout(tm); }
      const em = j && j.error && (j.error.message || j.error.code);
      if (!r.ok || !j || em) return sendResponse({ ok: false, error: (r.status ? r.status + " " : "") + (em || "HTTP " + r.status) + (j && j.error && j.error.metadata && j.error.metadata.raw ? " · " + String(j.error.metadata.raw).slice(0, 120) : "") });
      const txt = String((((j.choices || [])[0] || {}).message || {}).content || "").replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
      let out = null; try { out = JSON.parse(txt.replace(/^```(json)?|```$/g, "").trim()); } catch (_) {}
      if (!out) { const m = txt.match(/\{[\s\S]*\}/); if (m) try { out = JSON.parse(m[0]); } catch (_) {} }
      if (!out) return sendResponse({ ok: false, error: "AI-র উত্তর বোঝা যায়নি" });
      sendResponse({ ok: true, json: out, ms: Date.now() - t0 });
    })().catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }

  if (msg.type === "avh-ai" && msg.prov === "groq") {
    (async () => {
      const model = /^[a-z0-9.\-\/_:]+$/i.test(String(msg.model || "")) ? msg.model : "qwen/qwen3.8-27b";
      const t0 = Date.now();
      const ac = new AbortController(); const tm = setTimeout(() => ac.abort(), 55000);
      let r, j;
      // "ভাবা" কম রাখো (টোকেন ও সময় বাঁচে): gpt-oss → reasoning_effort low, qwen → ভাবনা লুকানো; মডেল না মানলে এগুলো ছাড়াই আবার
      const extra = /gpt-oss/i.test(model) ? { reasoning_effort: "low" } : /qwen/i.test(model) ? { reasoning_format: "hidden" } : {};
      const send = (x) => fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST", signal: ac.signal,
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + String(msg.key || "") },
        body: JSON.stringify({ model, temperature: 0.2, max_tokens: 1024, response_format: { type: "json_object" }, ...x,
          messages: [{ role: "system", content: "You are a trading assistant. Reply with a single JSON object only." }, { role: "user", content: String(msg.prompt || "").slice(0, 8000) }] }),
      });
      try {
        r = await send(extra);
        j = await r.json().catch(() => null);
        if (r.status === 400 && Object.keys(extra).length && /reasoning/i.test(JSON.stringify(j || {}))) { r = await send({}); j = await r.json().catch(() => null); }
      } catch (e) {
        return sendResponse({ ok: false, error: e.name === "AbortError" ? "Groq 55 সে.-এ উত্তর দেয়নি" : String(e.message || e) });
      } finally { clearTimeout(tm); }
      if (!r.ok || !j) return sendResponse({ ok: false, error: (j && j.error && (j.error.message || j.error.code)) || "HTTP " + r.status });
      const txt = String((((j.choices || [])[0] || {}).message || {}).content || "").replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
      let out = null; try { out = JSON.parse(txt.replace(/^```(json)?|```$/g, "").trim()); } catch (_) {}
      if (!out) { const m = txt.match(/\{[\s\S]*\}/); if (m) try { out = JSON.parse(m[0]); } catch (_) {} }
      if (!out) return sendResponse({ ok: false, error: "AI-র উত্তর বোঝা যায়নি" });
      sendResponse({ ok: true, json: out, ms: Date.now() - t0 });
    })().catch((e) => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }

  if (msg.type === "avh-tg-edit") {
    tg(msg.token, "editMessageCaption", { chat_id: msg.chat, message_id: msg.id, caption: String(msg.caption || "").slice(0, 1000) })
      .then((j) => sendResponse(j)).catch(() => sendResponse({ ok: false }));
    return true;
  }

  // Telegram-এর "/" মেনুতে কমান্ডের তালিকা
  if (msg.type === "avh-tg-cmds") {
    tg(msg.token, "setMyCommands", { commands: (msg.commands || []).slice(0, 100) })
      .then((j) => sendResponse(j))
      .catch((e) => sendResponse({ ok: false, description: String(e.message || e) }));
    return true;
  }
  if (msg.type === "avh-tg-send") {
    tg(msg.token, "sendMessage", Object.assign({ chat_id: msg.chat, text: String(msg.text || "").slice(0, 4000) }, msg.markup ? { reply_markup: msg.markup } : {}))
      .then((j) => sendResponse(j))
      .catch((e) => sendResponse({ ok: false, description: String(e.message || e) }));
    return true;
  }

  // Telegram বট খোলা — শুধু t.me লিংক
  if (msg.type === "avh-open") {
    if (!/^https:\/\/t\.me\/[A-Za-z0-9_]{3,40}(\?start=[A-Za-z0-9_]{1,64})?$/.test(String(msg.url || ""))) { sendResponse({ ok: false }); return; }
    chrome.tabs.create({ url: msg.url, active: true }).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;
  }
  // ইনলাইন বোতামের উত্তর ইত্যাদি (শুধু নির্দিষ্ট কয়েকটা)
  if (msg.type === "avh-tg-call") {
    if (!["answerCallbackQuery", "editMessageText"].includes(msg.method)) { sendResponse({ ok: false }); return; }
    tg(msg.token, msg.method, msg.params || {}).then((j) => sendResponse(j)).catch((e) => sendResponse({ ok: false, description: String(e.message || e) }));
    return true;
  }
  // এক বট: সার্ভারের সাথে কোড/অবস্থা/বিচ্ছিন্ন (শুধু https)
  if (msg.type === "avh-srv") {
    if (!/^https:\/\/[^/]+\/api\/[a-z]{2,20}$/.test(String(msg.url || ""))) { sendResponse({ ok: false, description: "bad url" }); return; }
    fetch(msg.url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(msg.body || {}) })
      .then((r) => r.json()).then((j) => sendResponse(j))
      .catch((e) => sendResponse({ ok: false, description: String(e.message || e) }));
    return true;
  }
  if (msg.type === "avh-tg-poll") {
    if (tgBusy) { sendResponse({ busy: true }); return; }
    tgBusy = true;
    tgPoll(msg.token, 25, msg.watch)
      .then((j) => sendResponse(j))
      .catch((e) => sendResponse({ ok: false, description: String(e.message || e) }))
      .finally(() => { tgBusy = false; });
    return true;
  }

});

// ---------- নিজে সারানো: চলমান Binance ট্যাব ৪ মিনিট সাড়া না দিলে (জমে গেছে/Chrome ঘুম পাড়িয়েছে) রিলোড ----------
try { chrome.alarms.create("avh-wd", { periodInMinutes: 1 }); } catch (_) {}
if (chrome.alarms) chrome.alarms.onAlarm.addListener(async (a) => {
  if (!a || a.name !== "avh-wd") return;
  const { avhWd: w, avhHeal: h0 } = await chrome.storage.local.get(["avhWd", "avhHeal"]);
  if (!w || !w.on || !w.heal || w.tab == null || Date.now() - w.ts < 4 * 60000) return;
  await chrome.storage.local.set({ avhWd: { ...w, on: false } }); // একবারই — পেজ আবার চললে নিজে চালু করবে
  const h = (h0 || []).filter((t) => Date.now() - t < 3600000);
  if (h.length >= 3) return;
  let tab = null;
  try { tab = await chrome.tabs.get(w.tab); } catch (_) { return; }
  if (!tab || !/binance\.com\/.*alpha/i.test(tab.url || "")) return;
  h.push(Date.now());
  await chrome.storage.local.set({ avhHeal: h, avhReloadAt: Date.now(), avhHealWhy: "frozen" });
  try { await chrome.tabs.reload(w.tab); } catch (_) {}
});
