// সতর্কতার শব্দ: তিনটি ছোট বিপ
let ctx = null;
function tone(freq, start, len, type) {
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type || "square";
  o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, start);
  g.gain.exponentialRampToValueAtTime(0.25, start + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, start + len);
  o.connect(g).connect(ctx.destination);
  o.start(start);
  o.stop(start + len + 0.05);
}
chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.type !== "avh-play") return;
  ctx = ctx || new AudioContext();
  const t = ctx.currentTime + 0.05;
  if (msg.kind === "done") {
    // কাজ শেষ: নরম, ওপরে ওঠা তিনটি সুর
    [[523, 0], [659, 0.18], [784, 0.36]].forEach(([f, d]) => tone(f, t + d, 0.35, "sine"));
  } else {
    // এরর: তিনটি তীক্ষ্ণ বিপ
    [0, 0.3, 0.6].forEach((d, i) => tone(i === 2 ? 660 : 880, t + d, 0.22, "square"));
  }
});
