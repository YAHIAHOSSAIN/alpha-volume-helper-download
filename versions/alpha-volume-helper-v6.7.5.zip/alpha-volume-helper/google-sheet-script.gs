/**
 * Alpha Volume Helper — সবার ভলিউমের হিসাব (Google Sheet)
 *
 * সেটআপ (একবারই, শুধু Sheet-এর মালিক করবে):
 * 1) নতুন Google Sheet খোলো → Extensions → Apps Script
 * 2) এই পুরো কোড পেস্ট করো, নিচের KEY বদলে নিজের একটা গোপন কোড দাও → 💾 Save
 * 3) উপরের ফাংশন তালিকা থেকে "setup" বেছে ▶ Run → অনুমতি চাইলে Allow
 * 4) Deploy → New deployment → ⚙ Web app → Execute as: Me, Who has access: Anyone → Deploy
 * 5) যে Web app URL পাবে তার শেষে ?k=তোমার_KEY যোগ করো, যেমন:
 *    https://script.google.com/macros/s/AKfy.../exec?k=amar-gopon-123
 *    এই লিংক এক্সটেনশনের "Sheet-এর লিংক" ঘরে দাও (বন্ধুদেরও এটাই দেবে)
 *
 * কোড পরে বদলালে: Deploy → Manage deployments → ✏ → Version: New version → Deploy (লিংক একই থাকে)
 *
 * নতুন ভার্সনের খবর: Sheet-এর "ভার্সন" পাতায় B1 = সর্বশেষ ভার্সন, B2 = ডাউনলোড লিংক, B3 = কী নতুন,
 * B4 = সর্বনিম্ন ভার্সন (এর চেয়ে পুরনো ভার্সন চলবে না; খালি রাখলে কোনো বাধা নেই)।
 * সবার এক্সটেনশন ৩ ঘণ্টা পরপর আর চালু হওয়ার সময় এটা দেখে।
 */
const KEY = "avh-0ee798eefa"; // তোমার গোপন কোড (এক্সটেনশনের লিংকের ?k= এর সাথে মিলতে হবে)

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    if (KEY && String((e.parameter && e.parameter.k) || "") !== KEY) return out_({ ok: false, error: "bad key" });
    const body = JSON.parse((e.postData && e.postData.contents) || "{}");
    const evs = Array.isArray(body.events) ? body.events.slice(0, 100) : [];
    const ss = SpreadsheetApp.getActive();
    const sh = ss.getSheetByName("Log") || setup_().log;
    migrate_(sh); // পুরনো ১০ কলামের Log হলে "প্রাইজ" কলাম যোগ
    const tz = ss.getSpreadsheetTimeZone();
    const cache = CacheService.getScriptCache();
    const rows = [];
    for (const v of evs) {
      const id = String(v.id || "").slice(0, 80);
      if (id && cache.get(id)) continue; // একই সারি দুবার না
      const d = new Date(Number(v.ts) || Date.now());
      // পুরনো ভার্সন (৩.৪.২৯-এর আগে) টোকেনের ঘরে দাম পাঠাত — সেটা প্রাইজে সরাও
      let tok = String(v.token || "").slice(0, 20), px = Number(v.price) > 0 ? Number(v.price) : "";
      if (/^\d+(\.\d+)?$/.test(tok)) { if (px === "") px = Number(tok); tok = ""; }
      rows.push([
        d,
        "'" + Utilities.formatDate(d, tz, "yyyy-MM-dd"),
        String(v.name || "?").slice(0, 40),
        tok,
        px,
        String(v.type || "").slice(0, 10),
        num_(v.vol),
        num_(v.trades),
        v.loss === "" || v.loss == null ? "" : num_(v.loss),
        id,
        String(v.v || "").slice(0, 12),
      ]);
      if (id) cache.put(id, "1", 21600);
    }
    // নতুন সারি উপরে (হেডারের ঠিক নিচে), প্যানেলের লগের মতো — সবচেয়ে নতুনটা সবার উপরে
    if (rows.length) {
      rows.reverse();
      sh.insertRowsBefore(2, rows.length);
      const nr = sh.getRange(2, 1, rows.length, rows[0].length);
      nr.setValues(rows);
      if (!sh.getBandings().length) { try { style_(sh, ss.getSheetByName("সারাংশ"), ss.getSheetByName("দৈনিক")); } catch (er) {} }
      try { if (!cache.get("rb")) { cache.put("rb", "1", 20); rebuild_(ss); } } catch (er) {} // সারাংশ নতুন করে (২০ সে.-এ একবার)
      fmtRows_(sh, 2, rows.length); // নতুন সারি শিরোনামের সাজ পাবে না — সাধারণ সারির সাজ
    }
    return out_({ ok: true, n: rows.length });
  } catch (err) {
    return out_({ ok: false, error: String(err && err.message || err) });
  } finally {
    lock.releaseLock();
  }
}

function doGet(e) {
  const p = (e && e.parameter) || {};
  if (p.a === "ver") {
    if (KEY && String(p.k || "") !== KEY) return out_({ ok: false, error: "bad key" });
    const v = verSheet_().getRange("B1:B4").getDisplayValues().map((r) => String(r[0] || "").trim());
    return out_({ ok: true, latest: v[0], url: v[1], notes: v[2], min: v[3] });
  }
  return out_({ ok: true, msg: "Alpha Volume Sheet চালু আছে" });
}

// "ভার্সন" পাতা না থাকলে বানাও (তোমার লেখা মান কখনো মোছে না)
function verSheet_() {
  const ss = SpreadsheetApp.getActive();
  let vs = ss.getSheetByName("ভার্সন");
  if (!vs) {
    vs = ss.insertSheet("ভার্সন");
    vs.getRange("A1:C4").setValues([
      ["সর্বশেষ ভার্সন", "3.4.27", "← নতুন ভার্সন দিলে এখানে নম্বর বদলাও"],
      ["ডাউনলোড লিংক", "https://claude.ai/artifact/97zVYdr7WQ7c6W6smVCpNc", "← বন্ধুরা ⬇ চাপলে এটা খুলবে"],
      ["কী নতুন", "নতুন ভার্সনের খবর প্যানেলে", "← এক লাইনে লেখো"],
      ["সর্বনিম্ন ভার্সন", "", "← এর চেয়ে পুরনো ভার্সন চলবে না (খালি = বাধা নেই)"],
    ]);
    vs.getRange("B1:B4").setNumberFormat("@");
    vs.getRange("A1:A4").setFontWeight("bold");
    vs.getRange("C1:C4").setFontColor("#888888");
    vs.setColumnWidth(1, 140); vs.setColumnWidth(2, 340);
  }
  return vs;
}

function setup() { setup_(); }

function setup_() {
  const ss = SpreadsheetApp.getActive();
  let log = ss.getSheetByName("Log");
  if (!log) {
    log = ss.insertSheet("Log");
    log.appendRow(HEAD);
    log.setFrozenRows(1);
    log.getRange("A:A").setNumberFormat("yyyy-mm-dd hh:mm:ss");
  }
  migrate_(log);
  // আগের সারিগুলো নতুনটা উপরে রেখে সাজাও (একবার setup চালালেই)
  if (log.getLastRow() > 2) log.getRange(2, 1, log.getLastRow() - 1, 11).sort({ column: 1, ascending: false });
  let sm = ss.getSheetByName("সারাংশ");
  if (!sm) sm = ss.insertSheet("সারাংশ", 0);
  sm.clear();
  // হিসাব এখন স্ক্রিপ্ট নিজে করে (rebuild_) — সূত্র আটকে গেলেও সংখ্যা ঠিক থাকে
  sm.getRange("A1:K3").setFontWeight("bold");
  sm.getRange("B1:H1").setNumberFormat("#,##0.00");
  sm.getRange("B4:C").setNumberFormat("#,##0.00");
  sm.getRange("G4:H").setNumberFormat("#,##0.00");
  sm.getRange("L4:M").setNumberFormat("#,##0.00");
  ["D4:D", "I4:I", "N4:N"].forEach((r) => sm.getRange(r).setNumberFormat('[Red]0.0000;[Color10]"+"0.0000;0'));
  sm.setFrozenRows(1);

  let dl = ss.getSheetByName("দৈনিক");
  if (!dl) dl = ss.insertSheet("দৈনিক", 1);
  dl.clear();
  dl.getRange("A1").setValue("প্রতিদিন প্রতি জনের ভলিউম (নতুন তারিখ উপরে)");
  dl.getRange("A1").setFontWeight("bold");
  verSheet_();
  rebuild_(ss);
  style_(log, sm, dl);
  // প্রতি ৫ মিনিটে নিজে হিসাব নতুন করে (কেউ ট্রেড না করলেও "আজ" তারিখ বদলালে ঠিক থাকে)
  ScriptApp.getProjectTriggers().filter((t) => t.getHandlerFunction() === "rebuild").forEach((t) => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger("rebuild").timeBased().everyMinutes(5).create();
  return { log, sm, dl };
}

// ---------- Log-এর কলাম ----------
// A সময় · B তারিখ · C নাম · D টোকেন · E প্রাইজ · F ধরন · G ভলিউম · H ট্রেড · I লস/প্রোফিট · J id (লুকানো) · K ভার্সন
const HEAD = ["সময়", "তারিখ", "নাম", "টোকেন", "প্রাইজ", "ধরন", "ভলিউম", "ট্রেড", "লস/প্রোফিট", "id", "ভার্সন"];
function migrate_(log) {
  if (String(log.getRange(1, 5).getValue()) === "প্রাইজ") return;
  if (String(log.getRange(1, 5).getValue()) !== "ধরন") return; // অচেনা গঠন — হাত দিও না
  // পুরনো ১০ কলাম: টোকেনের পরে "প্রাইজ" কলাম ঢোকাও, পুরনো সব ডাটা এক ঘর ডানে সরে
  log.getBandings().forEach((b) => b.remove());
  log.setConditionalFormatRules([]);
  log.insertColumnAfter(4);
  log.getRange(1, 1, 1, HEAD.length).setValues([HEAD]);
  // পুরনো ভার্সনের টোকেন ঘরে দাম থাকলে প্রাইজে সরাও
  const n = log.getLastRow() - 1;
  if (n > 0) {
    const r = log.getRange(2, 4, n, 2).getValues();
    let ch = false;
    r.forEach((x) => { const t = String(x[0]); if (/^\d+(\.\d+)?$/.test(t)) { x[1] = Number(t); x[0] = ""; ch = true; } });
    if (ch) log.getRange(2, 4, n, 2).setValues(r);
  }
  style_(log, null, null);
}

// ---------- সারাংশ ও দৈনিক: Log পড়ে স্ক্রিপ্ট নিজে যোগ করে লেখে ----------
function rebuild() { rebuild_(SpreadsheetApp.getActive()); }
function rebuild_(ss) {
  const log = ss.getSheetByName("Log"), sm = ss.getSheetByName("সারাংশ"), dl = ss.getSheetByName("দৈনিক");
  if (!log || !sm || !dl) return;
  const tz = ss.getSpreadsheetTimeZone(), now = new Date();
  const today = Utilities.formatDate(now, tz, "yyyy-MM-dd"), month = today.slice(0, 7);
  const n = log.getLastRow() - 1;
  const rows = n > 0 ? log.getRange(2, 2, n, 8).getValues() : []; // B..I: তারিখ, নাম, টোকেন, প্রাইজ, ধরন, ভলিউম, ট্রেড, লস/প্রোফিট
  const T = { all: 0, today: 0, month: 0, trades: 0 };
  const per = { d: {}, m: {}, a: {} }, daily = {}, names = {};
  const add = (o, k, v, t, l) => { const x = o[k] || (o[k] = [k, 0, 0, 0]); x[1] += v; x[2] += t; x[3] += l; };
  for (const r of rows) {
    const date = String(r[0] || "").replace(/^'/, "").slice(0, 10), name = String(r[1] || "").trim();
    if (!name) continue;
    const v = Number(r[5]) || 0, t = Number(r[6]) || 0, l = Number(r[7]) || 0;
    T.all += v; T.trades += t;
    add(per.a, name, v, t, l);
    if (date.slice(0, 7) === month) { T.month += v; add(per.m, name, v, t, l); }
    if (date === today) { T.today += v; add(per.d, name, v, t, l); }
    if (date) { (daily[date] || (daily[date] = {}))[name] = ((daily[date] || {})[name] || 0) + v; names[name] = (names[name] || 0) + v; }
  }
  sm.getRange("A1:H1").setValues([["📊 সবার লাইফটাইম ভলিউম", T.all, "আজ সবার", T.today, "এই মাসে সবার", T.month, "মোট ট্রেড", T.trades]]);
  sm.getRange("A3").setValue("আজ — প্রতি জন");
  sm.getRange("F3").setValue("এই মাস — প্রতি জন");
  sm.getRange("K3").setValue("লাইফটাইম — প্রতি জন");
  const head = ["নাম", "ভলিউম", "ট্রেড", "লস/প্রোফিট"];
  const maxR = Math.max(sm.getMaxRows() - 3, 1);
  [[per.d, 1], [per.m, 6], [per.a, 11]].forEach(([o, col]) => {
    const list = Object.values(o).sort((a, b) => b[1] - a[1]);
    sm.getRange(5, col, maxR - 1, 4).clearContent();
    sm.getRange(4, col, 1, 4).setValues([head]);
    if (list.length) sm.getRange(5, col, list.length, 4).setValues(list);
    else sm.getRange(5, col).setValue("এখনো কিছু নেই");
  });
  // দৈনিক: তারিখ × নাম (নতুন তারিখ উপরে, বেশি ভলিউমের নাম আগে)
  const nm = Object.keys(names).sort((a, b) => names[b] - names[a]);
  const dates = Object.keys(daily).sort().reverse();
  dl.getRange(2, 1, Math.max(dl.getMaxRows() - 1, 1), Math.max(dl.getMaxColumns(), 1)).clearContent();
  dl.getRange("A1").setValue("প্রতিদিন প্রতি জনের ভলিউম (নতুন তারিখ উপরে)");
  const out = [["তারিখ"].concat(nm)].concat(dates.map((d) => [d].concat(nm.map((k) => daily[d][k] || ""))));
  if (dl.getMaxColumns() < out[0].length) dl.insertColumnsAfter(dl.getMaxColumns(), out[0].length - dl.getMaxColumns());
  if (dl.getMaxRows() < out.length + 1) dl.insertRowsAfter(dl.getMaxRows(), out.length + 1 - dl.getMaxRows());
  dl.getRange(2, 1, out.length, out[0].length).setValues(out);
  if (out.length > 1) dl.getRange(3, 1, out.length - 1, 1).setNumberFormat("@");
}

// ---------- সাজ (ডিজাইন) ----------
const C_DARK = "#1e2329", C_GOLD = "#f0b90b";
function fmtRows_(sh, r, n) {
  if (n < 1) return;
  sh.getRange(r, 1, n, 11).setFontWeight("normal").setFontColor("#202124").setBackground(null).setFontSize(10)
    .setVerticalAlignment("middle").setFontFamily("Arial");
  sh.getRange(r, 1, n, 1).setNumberFormat("dd-MM  HH:mm:ss");
  sh.getRange(r, 3, n, 2).setFontWeight("bold");
  sh.getRange(r, 5, n, 1).setNumberFormat('0.00000###;-0.00000###;""').setHorizontalAlignment("right"); // প্রাইজ
  sh.getRange(r, 6, n, 1).setHorizontalAlignment("center");
  sh.getRange(r, 7, n, 1).setNumberFormat('#,##0.00;-#,##0.00;""'); // ০ হলে ফাঁকা
  sh.getRange(r, 8, n, 1).setHorizontalAlignment("center").setNumberFormat('0;-0;""');
  sh.getRange(r, 9, n, 1).setNumberFormat('[Red]0.000000;[Color10]"+"0.000000;""');
  sh.getRange(r, 11, n, 1).setFontColor("#9aa0a6").setFontSize(9).setHorizontalAlignment("center");
  // ধরন অনুযায়ী রঙ সরাসরি ঘরে বসাও (setup না চালালেও নতুন সারি রঙিন হবে)
  const last = Math.min(n, Math.max(0, sh.getLastRow() - r + 1));
  if (last < 1) return;
  const tv = sh.getRange(r, 6, last, 1).getValues();
  const bgE = [], fgE = [], fgH = [], bgH = [];
  tv.forEach(([t]) => {
    const p = String(t).trim().toLowerCase();
    const c = TYPE_C[p] || [null, "#202124"];
    bgE.push([c[0]]); fgE.push([c[1]]);
    bgH.push([p === "profit" ? "#eefaf3" : p === "loss" ? "#fdf1f3" : null]);
    fgH.push([p === "profit" ? "#06763f" : p === "loss" ? "#b3122a" : "#202124"]);
  });
  sh.getRange(r, 6, last, 1).setBackgrounds(bgE).setFontColors(fgE).setFontWeight("bold");
  sh.getRange(r, 9, last, 1).setBackgrounds(bgH).setFontColors(fgH);
}
const TYPE_C = {
  buy: ["#e6f7ef", "#0b8f5a"], sell: ["#fdecee", "#d6334a"],
  profit: ["#c8f0d9", "#06763f"], loss: ["#f9d3d8", "#b3122a"],
  test: ["#eef0f3", "#6b7280"], join: ["#eef0f3", "#6b7280"], rename: ["#eef0f3", "#6b7280"],
};
function style_(log, sm, dl) {
  // Log
  log.getBandings().forEach((b) => b.remove());
  const last = Math.max(log.getMaxRows(), 2);
  log.getRange(1, 1, 1, 11).setBackground(C_DARK).setFontColor(C_GOLD).setFontWeight("bold").setFontSize(10)
    .setHorizontalAlignment("center").setVerticalAlignment("middle");
  log.setRowHeight(1, 32);
  log.setFrozenRows(1);
  fmtRows_(log, 2, last - 1);
  log.getRange("A:K").applyRowBanding(SpreadsheetApp.BandingTheme.LIGHT_GREY, true, false)
    .setHeaderRowColor(C_DARK).setFirstRowColor("#ffffff").setSecondRowColor("#f6f8fa");
  [[1, 120], [2, 85], [3, 95], [4, 70], [5, 90], [6, 70], [7, 85], [8, 50], [9, 100], [11, 60]].forEach(([c, w]) => log.setColumnWidth(c, w));
  try { log.showColumns(9); } catch (er) {}
  log.hideColumns(10); // id — শুধু একই সারি দুবার না আসার জন্য
  const E = log.getRange("F2:F");
  const rule = (t, bg, fg) => SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo(t)
    .setBackground(bg).setFontColor(fg).setBold(true).setRanges([E]).build();
  log.setConditionalFormatRules(Object.keys(TYPE_C).map((t) => rule(t, TYPE_C[t][0], TYPE_C[t][1])));

  log.setTabColor(C_GOLD);
  if (!sm || !dl) return;
  // সারাংশ
  sm.getRange("A1:H1").setFontSize(11).setVerticalAlignment("middle");
  ["B1", "D1", "F1", "H1"].forEach((a) => sm.getRange(a).setFontSize(15).setFontWeight("bold").setFontColor("#06763f"));
  ["A1", "C1", "E1", "G1"].forEach((a) => sm.getRange(a).setFontColor("#5f6368"));
  sm.setRowHeight(1, 40);
  ["A3", "F3", "K3"].forEach((a) => sm.getRange(a).setFontColor(C_DARK).setFontSize(12));
  ["A4:D4", "F4:I4", "K4:N4"].forEach((a) => sm.getRange(a).setBackground(C_DARK).setFontColor(C_GOLD).setFontWeight("bold").setHorizontalAlignment("center"));
  [[1, 140], [2, 100], [3, 70], [4, 90], [5, 20], [6, 120], [7, 100], [8, 70], [9, 90], [10, 20], [11, 120], [12, 100], [13, 70], [14, 90]]
    .forEach(([c, w]) => sm.setColumnWidth(c, w));
  sm.setTabColor("#0ecb81");
  // দৈনিক
  dl.getRange("A1").setFontSize(12).setFontColor(C_DARK);
  dl.getRange("A2:Z2").setBackground(C_DARK).setFontColor(C_GOLD).setFontWeight("bold").setHorizontalAlignment("center");
  dl.getRange("B3:Z").setNumberFormat("#,##0.00");
  dl.setColumnWidth(1, 110);
  dl.setTabColor("#1e6fff");
}

function num_(x) { x = Number(x); return isFinite(x) ? x : 0; }
function out_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
