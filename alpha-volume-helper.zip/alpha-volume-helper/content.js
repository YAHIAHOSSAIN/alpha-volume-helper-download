(() => {
  if (window.__avhLoaded) return;
  window.__avhLoaded = true;

  const I18N = window.__AVH_I18N;
  const T = (k, ...a) => {
    const d = I18N[cfg.lang] || I18N.bn;
    const v = k in d ? d[k] : I18N.bn[k];
    return typeof v === "function" ? v(...a) : v;
  };

  // ---------- সেটিংস ----------
  // Suggest দাম আর লাগে না (সবসময় লাইভ বাজার দাম) — তাই তালিকা থেকে বাদ
  const KEYS = ["buyTab", "orderType", "livePrice", "priceInput", "amountInput", "buyButton", "sellTab", "sellAvailable", "sellAmountInput", "sellButton",
    "confirmButton", "balanceText", "openOrders", "cancelAll", "cancelConfirm", "bookAsk", "bookBid"];
  const OPTIONAL = new Set(["orderType", "suggestPrice", "livePrice", "confirmButton", "balanceText", "cancelConfirm", "bookAsk", "bookBid"]);
  const LBL = (k) => T("L_" + k);
  // সবার হিসাব যায় মালিকের Google Sheet-এ — সবসময় চালু, বন্ধ করা যায় না
  const REPORT_URL = "https://script.google.com/macros/s/AKfycbwvZITWFabpz0e9ZIOJpG7HQOjvRALVdHk0gU5knudSWisDCJztP3dYNuUh89aVKTIF/exec?k=avh-0ee798eefa";
  // এক্সটেনশন আপডেট/রিলোডের পর পুরনো ট্যাবের কপি: Chrome-এর "Extension context invalidated" এরর জমতে দিও না
  window.addEventListener("unhandledrejection", (e) => {
    const m = String((e.reason && e.reason.message) || e.reason || "");
    if (/Extension context invalidated/i.test(m)) e.preventDefault();
  });
  {
    const _si = window.setInterval.bind(window), _st = window.setTimeout.bind(window);
    const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch (_) { return false; } };
    const wrap = (fn) => (typeof fn !== "function" ? fn : function (...a) {
      if (!alive()) return;
      try { return fn.apply(this, a); } catch (err) { if (!alive()) return; throw err; }
    });
    window.setInterval = (fn, ms, ...a) => _si(wrap(fn), ms, ...a);
    window.setTimeout = (fn, ms, ...a) => _st(wrap(fn), ms, ...a);
  }
  const MIN_ORDER = 1; // শেষ ট্রেডে সর্বনিম্ন অ্যামাউন্ট (USDT)
  const MIN_SELL_USDT = 0.1 * 1.1; // Binance-এর সর্বনিম্ন Sell মূল্য 0.1 USDT (+১০% নিরাপত্তা) — এর কম টোকেন বিক্রি করা যায় না
  const MAX_SELL_DROP = 10; // Sell দ্রুত পূরণে মোট দাম কমানোর সীমা (%)
  // সেটিংসের সীমা [সর্বনিম্ন, সর্বোচ্চ, পূর্ণসংখ্যা?] — ভুল করে বড়/ছোট সংখ্যা দিলে এর মধ্যে আনা হয়
  const LIMITS = {
    amount: [1, 1e7], target: [1, 1e9], amountJitter: [0, 50], minDelay: [1, 3600], maxDelay: [1, 3600], maxLoss: [0, 1e7],
    sellDecimals: [0, 8, true], fillTimeout: [3, 600], retries: [0, 10, true], sellStep: [0, 1], sellFastWait: [2, 600], liveWait: [2, 600],
    maxSpread: [0, 100], minDepth: [1, 1000], spreadWait: [1, 3600], retryMax: [1, 20, true], retryWait: [3, 600],
    liveBuf: [0, 1], balAlert: [0, 50], stopAfter: [0, 10080, true], ptGoal: [0, 10000, true], ptBalPts: [0, 20, true], aiConf: [0, 100, true], autoCost: [0.01, 100], makerWait: [2, 60], makerStop: [0.01, 1], aiEvery: [15, 600, true],
  };
  function clampVal(f, v) {
    const L = LIMITS[f];
    v = Number(v);
    if (!L) return v;
    if (!isFinite(v)) return null;
    if (L[2]) v = Math.round(v);
    return Math.min(L[1], Math.max(L[0], v));
  }
  const OLD_KEYS = ["apOn", "profitOn", "pSellLive", "pTake", "pStop", "pHoldMin", "pScoreMin", "schedOn", "schedStart", "schedEnd", "schedDoneKey",
    "candleOn", "candleNeed", "candleSec", "candleSrc", "costGuardOn", "maxPer1000", "costPauseMin", "bullOnly", "maxPer100"];
  function clampCfg() {
    for (const f of Object.keys(LIMITS)) {
      const v = clampVal(f, cfg[f]);
      if (v != null) cfg[f] = v;
    }
    // ৩.৮ থেকে স্থির নিয়ম (সেটিংসে নেই): সবসময় লাইভ বাজার দাম, Sell-ও ভলিউমে গোনা, শুরুর আগে হাতের টোকেন বিক্রি;
    // প্রফিট মোড আর দৈনিক শিডিউল বাদ
    cfg.priceMode = "live"; cfg.countSell = true; cfg.heldMode = "sell";
    if (!["stable", "bull", "off"].includes(cfg.entryMode)) cfg.entryMode = "stable";
    if (!["openrouter", "groq"].includes(cfg.aiProv)) cfg.aiProv = "openrouter"; // ৬.১ থেকে Gemini বাদ
    // ৫.৫: প্রফিট মোড, শিডিউল, ক্যান্ডেল-ফিল্টার, পুরনো খরচ-রক্ষী বাদ — পুরনো সেভের ঘরও মুছে ফেলা
    if (!["free", "paid"].includes(cfg.orMode)) cfg.orMode = "paid";
    for (const k of OLD_KEYS) delete cfg[k];
  }

  let cfg = {
    lang: "bn",
    amount: 10, target: 1000, amountJitter: 0,
    minDelay: 5, maxDelay: 10, sellDecimals: 2, priceMode: "suggest", countSell: false,
    fillTimeout: 15, retries: 3, sellStep: 0.05, sellFastWait: 5,
    histVol: 0, histLoss: 0, cfgVer: 2,
    lossOn: false, maxLoss: 2,
    spreadOn: false, maxSpread: 0.5,
    depthOn: false, minDepth: 3,
    retryOn: true, retryMax: 3, retryWait: 15,
    spreadWait: 5,
    heldMode: "sell", liveWait: 5, liveBuf: 0.08, syncOn: true, updatedAt: 0,
    notifyOn: true, soundOn: true,
    tgReport: false,
    tgId: "", tgSec: "", tgSChat: "", tgSName: "",
    dzOn: true,
    entryMode: "stable", makerSell: true, makerWait: 4, makerStop: 0.05,
    obOn: true, makerAuto: true, airOn: true, airTg: true,
    balAlert: 1, stopAfter: 0, stopAt: "", dayRep: true, evOn: true, ptGoal: 0, ptBalPts: 0, tgBot: "",
    selAuto: true, selVer: 0, lbShow: true, repNameSent: "",
    aiOn: false, aiWant: true, aiProv: "openrouter", aiKeyGroq: "", aiModelGroq: "qwen/qwen3.8-27b", aiKeyOr: "", aiModelOr: "", orPaid: true, orMode: "paid", aiEvery: 15, aiConf: 65,
    ptOn: true, ptMult: 1, autoSpeed: true, autoCost: 0.2, autoBuf: true, bufAuto: 0, healOn: true,
    selectors: {},
  };
  let stKind = "idle", stText = ""; // উপরের অবস্থা লাইন
  const MY_VER = (() => { try { return chrome.runtime.getManifest().version; } catch (_) { return "0"; } })();
  let verInfo = null; // নতুন ভার্সনের খবর: { latest, url, notes, min }
  let state = { running: false, volume: 0, trades: 0, startBal: null, lastBal: null, totalLoss: null, lossOffset: 0, dust: 0, t0: 0, v0: 0 };
  let progSnap = null; // থামার সময়ের অবস্থা — পরের বার এখান থেকে চলবে
  let stopFlag = false;
  let pickingKey = null;
  let paused = false, pauseStart = 0, pausedMs = 0;

  // সেভ: এই কম্পিউটারে + (চালু থাকলে) Google অ্যাকাউন্টের মাধ্যমে অন্য কম্পিউটারে
  const NO_SYNC = ["bufAuto", "selVer", "tgId", "tgSec", "tgSChat", "tgSName", "aiKeyGroq", "aiKeyOr", "histVol", "histLoss", "selectors", "updatedAt", "cfgVer", "syncOn"];
  let syncTimer = null;
  const save = (touch = true) => {
    if (touch) cfg.updatedAt = Date.now();
    chrome.storage.local.set({ avhCfg: cfg });
    if (touch) setTimeout(() => { try { cfgSrvSched(); } catch (_) {} }, 0); // ☁ সার্ভারেও (১ মিনিট পরে, একসাথে)
    if (!cfg.syncOn || !touch || !chrome.storage.sync) return;
    clearTimeout(syncTimer);
    syncTimer = setTimeout(() => {
      const data = {}; for (const k of Object.keys(cfg)) if (!NO_SYNC.includes(k)) data[k] = cfg[k];
      try {
        chrome.storage.sync.set({ avhSyncA: { ts: cfg.updatedAt, data }, avhSyncS: { ts: cfg.updatedAt, data: cfg.selectors } }, () => {
          const e = chrome.runtime.lastError;
          if (e) log(T("syncErr", e.message || ""));
        });
      } catch (_) {}
    }, 3000);
  };
  function applySync(a, sel, why) {
    if (!a || !a.data || !(a.ts > (cfg.updatedAt || 0))) return false;
    const keep = {}; for (const k of NO_SYNC) keep[k] = cfg[k];
    cfg = { ...cfg, ...a.data, ...keep, updatedAt: a.ts };
    if (sel && sel.data && sel.ts >= a.ts) cfg.selectors = { ...sel.data };
    clampCfg();
    chrome.storage.local.set({ avhCfg: cfg });
    renderInputs(); applyI18n();
    log(T(why));
    return true;
  }

  // ---------- প্যানেল UI ----------
  const host = document.createElement("div");
  host.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647;";
  const root = host.attachShadow({ mode: "open" });
  const L = (key, input) => `<label><span data-t="${key}"></span>${input}</label>`;
  const num = (id, a = "") => `<input type="number" id="${id}" ${a}>`;
  const chk = (id) => `<input type="checkbox" id="${id}">`;
  root.innerHTML = `
  <style>
    :host{--bg:#0f1318;--c2:#161b22;--c3:#0c1015;--ln:rgba(255,255,255,.07);--ln2:rgba(255,255,255,.13);--tx:#eaecef;--tx2:#a3acb9;--tx3:#6b7480;--gold:#f0b90b;--gold2:#fcd535;--green:#0ecb81;--red:#f6465d;--amber:#f5a524;--blue:#3d8bfd}
    *{box-sizing:border-box;font-family:Inter,"Segoe UI","Nirmala UI",system-ui,"Noto Sans Bengali",sans-serif}
    .num,#barp,#hvVol,.kv,#cvTr,#cvEl,#cvEta,#sgVal{font-variant-numeric:tabular-nums;letter-spacing:-.01em}
    .p{width:384px;max-height:88vh;overflow:auto;background:linear-gradient(180deg,#151a21 0%,#0f1318 100%);color:var(--tx);border:1px solid var(--ln);border-radius:18px;padding:0 14px 12px;font-size:12px;box-shadow:0 24px 70px rgba(0,0,0,.55);position:relative}
    .p::-webkit-scrollbar{width:6px}.p::-webkit-scrollbar-thumb{background:#2b3139;border-radius:3px}
    .p:before{content:"";position:absolute;left:0;right:0;top:0;height:110px;background:radial-gradient(240px 80px at 25% -20%,rgba(240,185,11,.15),transparent 70%);pointer-events:none;border-radius:18px 18px 0 0}
    h3{cursor:move;user-select:none;margin:0 -14px 8px;padding:12px 12px 8px 14px;font-size:14px;display:flex;justify-content:space-between;align-items:center;gap:8px;position:sticky;top:0;z-index:3;background:linear-gradient(180deg,#151a21 75%,rgba(21,26,33,0))}
    .ttl{display:flex;align-items:center;gap:9px;min-width:0;flex:1 1 auto;overflow:hidden}
    .logo{width:30px;height:30px;border-radius:9px;flex:0 0 auto;box-shadow:0 4px 14px rgba(240,185,11,.3)}
    .tt{display:flex;flex-direction:column;min-width:0;line-height:1.2}.tt b{font-size:14px;font-weight:700;color:var(--tx);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .tt small{font-size:10.5px;color:var(--tx3);font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .hbtns{display:flex;align-items:center;gap:2px;flex:0 0 auto}
    label{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 2px;border-top:1px solid var(--ln);font-size:12.5px;color:var(--tx)}
    .grp+label{border-top:none}
    input[type=number]{width:96px}input[type=time]{width:118px}input[type=text],input[type=password]{width:180px}
    input[type=number],input[type=time],input[type=text],input[type=password],select{background:var(--c3);color:var(--tx);border:1px solid var(--ln2);border-radius:8px;padding:6px 9px;color-scheme:dark;font-size:12.5px;font-weight:600;text-align:right;outline:none;transition:border-color .15s}
    select{text-align:left;font-weight:500}
    input:focus,select:focus{border-color:var(--gold)}
    input:disabled,select:disabled{opacity:.45}
    input[type=checkbox]{appearance:none;-webkit-appearance:none;width:36px;height:21px;border-radius:99px;background:#2a313b;position:relative;cursor:pointer;flex:0 0 auto;transition:background .2s;margin:0}
    input[type=checkbox]:after{content:"";position:absolute;top:3px;left:3px;width:15px;height:15px;border-radius:50%;background:#fff;transition:left .2s}
    input[type=checkbox]:checked{background:var(--green)}input[type=checkbox]:checked:after{left:18px}
    button{background:rgba(255,255,255,.04);color:var(--tx);border:1px solid var(--ln2);border-radius:9px;padding:6px 10px;cursor:pointer;font-size:12px;font-weight:600;transition:all .15s}
    button:hover{border-color:rgba(240,185,11,.6)}button:active{transform:scale(.97)}
    button:disabled{opacity:.4;cursor:default;transform:none}
    .row{display:flex;gap:8px;margin-top:8px}.row button{flex:1}
    .ctl{display:flex;gap:8px;margin:12px 0}
    .ctl button{height:40px;border-radius:11px;font-size:13px;display:flex;align-items:center;justify-content:center;gap:7px}
    .go{flex:1.6;background:linear-gradient(180deg,#fcd535,#f0b90b);color:#1a1400;border:none;box-shadow:0 6px 18px rgba(240,185,11,.25)}
    .go:disabled{display:none}
    .stop{flex:1.6;background:linear-gradient(180deg,#ff5a6f,#e33c52);color:#fff;border:none;box-shadow:0 6px 18px rgba(246,70,93,.25);display:none!important}
    .p.running .stop{display:flex!important}
    #pause{flex:1}
    #reset{flex:0 0 auto;padding:0 12px}
    .x,.mbtn{background:none;border:1px solid transparent;color:var(--tx2);width:28px;height:28px;padding:0;border-radius:8px;font-size:15px;line-height:1;display:grid;place-items:center}
    .x:hover,.mbtn:hover,.mbtn.on{background:rgba(255,255,255,.06);border-color:var(--ln);color:var(--tx)}
    .stl{display:flex;align-items:center;gap:8px;margin:0 0 4px;padding:8px 10px;border-radius:11px;background:rgba(255,255,255,.025);border:1px solid var(--ln);font-size:12px;white-space:nowrap;overflow:hidden;transition:border-color .3s}
    .stl .dot{width:8px;height:8px;border-radius:50%;flex:0 0 auto;background:#5e6673;position:relative}
    .stl.run .dot{background:var(--green)}.stl.run .dot:after{content:"";position:absolute;inset:-4px;border-radius:50%;border:2px solid var(--green);animation:avhRing 1.6s infinite}
    .stl.wait .dot{background:var(--amber)}.stl.wait{border-color:rgba(245,165,36,.3)}
    .stl.err .dot{background:var(--red)}.stl.err{border-color:rgba(246,70,93,.35)}.stl.done .dot{background:var(--blue)}
    @keyframes avhRing{0%{transform:scale(.6);opacity:.7}100%{transform:scale(1.7);opacity:0}}
    .stl b{font-weight:700}.stl span{overflow:hidden;text-overflow:ellipsis;color:var(--tx2)}
    .stl #stlB{flex:1;min-width:0}
    .cn{flex:0 0 auto;display:flex;align-items:center;gap:4px;font-size:10px;color:var(--tx3);padding:2px 6px;border-radius:6px;background:rgba(255,255,255,.035)}
    .cn i{width:5px;height:5px;border-radius:50%;background:var(--green)}.cn.bad i{background:var(--red)}.cn[hidden]{display:none}
    .who{flex:0 0 auto;display:flex;align-items:center;gap:6px;padding:3px 9px 3px 3px;border-radius:99px;background:rgba(255,255,255,.04);border:1px solid var(--ln);font-size:11.5px;color:var(--tx2);max-width:98px;min-width:0;overflow:hidden;white-space:nowrap;font-weight:500}
    .who .av{width:20px;height:20px;border-radius:50%;background:linear-gradient(135deg,#3d8bfd,#7b61ff);display:grid;place-items:center;font-size:10.5px;font-weight:700;color:#fff;flex:0 0 auto}
    .who #whoName{overflow:hidden;text-overflow:ellipsis}.who.solo{padding:3px;gap:0}.who.solo .av{width:24px;height:24px;font-size:12px}
    .who.blink{animation:avhBlink .5s 5}@keyframes avhBlink{50%{box-shadow:0 0 0 2px var(--gold)}}
    .who.none{border-color:var(--gold);color:var(--gold);animation:avhPulse 1.4s infinite}
    .upd{margin:6px 0;padding:10px;border:1px solid rgba(240,185,11,.5);border-radius:12px;background:rgba(240,185,11,.07)}
    .upd.must{border-color:rgba(246,70,93,.6);background:rgba(246,70,93,.08)}
    .updT{font-weight:700;color:var(--gold)}.upd.must .updT{color:#ff8a98}
    .updN{color:var(--tx2);font-size:11px;margin:3px 0 6px;white-space:pre-line}.updN:empty{display:none}
    .upd button{width:100%;background:var(--gold);color:#1a1400;border:none;padding:7px}.upd.must button{background:var(--red);color:#fff}
    @keyframes avhPulse{50%{opacity:.4}}
    .sel{display:flex;justify-content:space-between;align-items:center;padding:7px 2px;border-top:1px solid var(--ln);gap:6px}
    .sel span{flex:1}.sel button{padding:4px 9px;font-size:11.5px}
    .ok{color:var(--green)}.no{color:var(--red)}.opt{color:var(--tx3)}
    details{border-top:1px solid var(--ln);padding-top:6px;margin-top:6px}
    #tgBadge{display:none!important}
    .badge{font-size:10px;color:#1a1400;background:var(--gold);border-radius:5px;padding:1px 5px;margin-left:2px;font-weight:700}
    .mmenu{position:absolute;top:50px;right:12px;width:240px;background:#1b212a;border:1px solid var(--ln2);border-radius:14px;box-shadow:0 18px 50px rgba(0,0,0,.6);padding:6px;z-index:6;transform-origin:top right;animation:avhMIn .16s ease}
    .mmenu[hidden]{display:none}
    @keyframes avhMIn{from{opacity:0;transform:scale(.94)}to{opacity:1;transform:none}}
    .mmenu button{display:flex;align-items:center;gap:10px;width:100%;background:none;border:none;color:var(--tx);font-size:13px;padding:8px 9px;border-radius:10px;text-align:left;font-weight:500}
    .mmenu button:hover{background:rgba(255,255,255,.06)}
    .mmenu .ic{width:30px;height:30px;border-radius:9px;background:rgba(255,255,255,.05);display:grid;place-items:center;font-size:15px;flex:0 0 auto}
    .mmenu small{display:block;color:var(--tx3);font-size:10.5px;font-weight:400}
    .mmenu .mbadge{margin-left:auto;background:var(--red);color:#fff;font-size:10px;font-weight:700;border-radius:99px;padding:1px 6px}
    .mmenu .mbadge[hidden],.mdot[hidden]{display:none}
    .mbtn{position:relative}.mdot{position:absolute;top:3px;right:3px;width:7px;height:7px;border-radius:50%;background:var(--red)}
    .air{display:block;padding:8px 2px;border-top:1px solid var(--ln);color:var(--tx);text-decoration:none}
    .air:first-child{border-top:none}.air:hover b{color:var(--gold)}
    .air b{display:block;font-size:12px;font-weight:600;line-height:1.35}
    .air small{display:block;font-size:10.5px;color:var(--tx3);margin-top:2px}
    .air.new b:before{content:"নতুন";font-size:9px;background:var(--red);color:#fff;border-radius:4px;padding:0 4px;margin-right:5px;vertical-align:1px}
    #airList{max-height:340px;overflow:auto}
    .note.pre{white-space:pre-line}
    #cnTg{cursor:pointer}
    #pbody>details{display:none}#pbody>details>summary{display:none}
    .mhead{display:none;align-items:center;gap:10px;margin:2px 0 6px;padding:0 0 10px}
    .mhead button{height:30px;padding:0 11px}
    .mhead b{color:var(--tx);font-size:14px}
    #pbody.inview>*{display:none!important}
    #pbody.inview>.mhead{display:flex!important}
    #pbody.inview>details.cur{display:block!important;border-top:none;margin-top:0;padding:4px 12px 8px;background:var(--c2);border:1px solid var(--ln);border-radius:14px;animation:avhVIn .2s ease}
    @keyframes avhVIn{from{opacity:0;transform:translateX(16px)}to{opacity:1;transform:none}}
    summary{cursor:pointer;font-weight:600;color:var(--tx2);padding:6px 4px;list-style:none}
    summary::-webkit-details-marker{display:none}
    .grp{font-size:10.5px;color:var(--gold);font-weight:700;letter-spacing:.03em;margin:14px 2px 2px}
    details>.grp:first-of-type{margin-top:8px}
    .note{color:var(--tx3);line-height:1.55;margin:4px 2px 2px;font-size:11px}
    .hero{display:flex;gap:14px;align-items:center;margin:12px 0 0}
    .ring{position:relative;width:92px;height:92px;flex:0 0 auto}
    .ring svg{width:92px;height:92px;display:block}
    #ringArc{transition:stroke-dashoffset .8s ease}
    .ring .rc{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center}
    #barp{font-size:21px;font-weight:700}.ring small{font-size:10px;color:var(--tx3);margin-top:-1px}
    .hv{min-width:0;flex:1}
    .hv .lb{font-size:11px;color:var(--tx3);display:flex;align-items:center;gap:6px}
    .tag{font-size:9.5px;padding:1px 6px;border-radius:5px;background:rgba(240,185,11,.12);color:var(--gold);font-weight:700}
    #pmTag,#aiTag{cursor:pointer;user-select:none}
    #pmTag.on,#aiTag.on{background:rgba(14,203,129,.13);color:var(--green)}
    #pmTag.off{background:rgba(246,70,93,.15);color:var(--red)}
    #aiTag.off{background:rgba(255,255,255,.06);color:var(--tx3)}
    .big{display:flex;align-items:baseline;gap:5px;margin-top:2px;white-space:nowrap}
    #hvVol{font-size:27px;font-weight:700;letter-spacing:-.02em;line-height:1.15}
    #hvTgt{font-size:12px;color:var(--tx3);font-weight:500;overflow:hidden;text-overflow:ellipsis}
    .meta{display:flex;gap:11px;margin-top:5px;font-size:11px;color:var(--tx2);white-space:nowrap}
    .meta b{color:var(--tx);font-weight:600;font-size:11.5px}
    .cards{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
    .cd{background:var(--c2);border:1px solid var(--ln);border-radius:12px;padding:8px 10px;min-width:0;position:relative;overflow:hidden;transition:all .3s}
    .cd small{display:block;font-size:10.5px;color:var(--tx3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .cd b{display:block;font-size:15px;font-weight:700;margin-top:2px;font-variant-numeric:tabular-nums;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .cd i{display:block;font-style:normal;font-size:10px;color:var(--tx3)}
    .cd.red b{color:var(--red)}.cd.grn b{color:var(--green)}.cd.yel b{color:var(--gold)}
    .cd.fl{box-shadow:0 0 0 1px rgba(14,203,129,.45) inset}
    #plSpark{position:absolute;right:7px;bottom:7px;width:44px;height:16px}
    .mk{margin-top:10px;background:var(--c2);border:1px solid var(--ln);border-radius:14px;padding:10px 12px}
    .mk:not(:has(.sg:not([hidden]))):not(:has(.kbox:not([hidden]))){display:none}
    .kbox{flex:1;min-width:0;display:flex;flex-direction:column;gap:1px}
    .kbox[hidden]{display:none}
    .kbox svg{width:100%;display:block;border-radius:6px;background:rgba(255,255,255,.015)}
    #k1svg{height:62px}#k15svg{height:40px}
    .kh{display:flex;align-items:center;gap:6px;font-size:10px;color:var(--tx3);line-height:1.5}
    .kh b{color:var(--tx2);font-weight:600}
    .kh span{margin-left:auto;font-variant-numeric:tabular-nums;font-weight:600}
    .kh .up{color:var(--green)}.kh .dn{color:var(--red)}.kh .fl{color:var(--tx3)}
    .kpx{font-size:11px;font-weight:700;color:var(--gold);font-variant-numeric:tabular-nums;margin-left:auto}
    .mh .seg[hidden]{display:none!important}
    .mh{display:flex;align-items:center;gap:8px;font-size:11.5px;color:var(--tx2);margin-bottom:4px}
    .mh .seg{margin-left:auto;display:flex;background:rgba(255,255,255,.04);border-radius:8px;padding:2px}
    .mh .seg button{font-size:10.5px;padding:2px 8px;border-radius:6px;color:var(--tx3);border:none;background:none;font-weight:500}
    .mh .seg button.on{background:rgba(255,255,255,.09);color:var(--tx)}
    .mk.solo .cstate,.mk.solo .seg{display:none!important}
    .mrow{display:flex;gap:10px;align-items:center}
    .cstate{font-size:10.5px!important;font-weight:700;padding:3px 9px;border-radius:99px;display:flex;align-items:center;gap:5px;white-space:nowrap}
    .cstate:before{content:"";width:6px;height:6px;border-radius:50%;background:currentColor}
    .cstate.on{background:rgba(14,203,129,.12);color:var(--green)}.cstate.off{background:rgba(246,70,93,.12);color:var(--red)}.cstate.wait{background:rgba(245,165,36,.12);color:var(--amber)}
    .sg{flex:0 0 100px;text-align:center}
    .mk.solo .sg{flex:1}
    .sg[hidden]{display:none}
    .sg svg{width:96px;height:56px;display:block;margin:0 auto}
    .sg .sv{font-size:16px;font-weight:700;line-height:1.1;margin-top:2px}
    .sg .sw{font-size:10px;color:var(--tx3);margin-top:1px}
    .sg .g{color:var(--green)}.sg .y{color:var(--gold)}.sg .r{color:var(--red)}.sg .n{color:#5e6673}
    #sgNeedle{transition:all .45s ease}
    #prog{margin-top:8px;white-space:pre-line;line-height:1.45;font-variant-numeric:tabular-nums;font-size:11px;color:var(--tx2);padding:0 2px}
    #prog:empty{display:none}
    #ptRow{margin-top:8px;white-space:pre-line;line-height:1.5;font-size:11px;font-variant-numeric:tabular-nums;color:var(--tx2);padding:7px 9px;border-radius:9px;background:rgba(252,213,53,.06);border:1px solid rgba(252,213,53,.16)}
    #ptRow:empty{display:none}
    .lgw{margin-top:10px;background:var(--c2);border:1px solid var(--ln);border-radius:14px;overflow:hidden}
    .lgh{display:flex;align-items:center;padding:8px 10px 8px 12px;font-size:11.5px;color:var(--tx2);border-bottom:1px solid var(--ln)}
    .lgh .seg{margin-left:auto;display:flex;gap:3px}
    .lgh .seg button{font-size:10.5px;padding:2px 9px;border-radius:99px;color:var(--tx3);border:1px solid transparent;background:none;font-weight:500}
    .lgh .seg button.on{color:var(--tx);border-color:var(--ln2);background:rgba(255,255,255,.04)}
    .log{padding:4px 0;height:168px;overflow:auto;font-size:11.5px}
    .log .lr{display:flex;gap:8px;align-items:center;padding:4px 12px;line-height:1.35;animation:avhIn .3s ease}
    @keyframes avhIn{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:none}}
    .log .li{flex:0 0 20px;height:20px;border-radius:6px;display:grid;place-items:center;font-size:10.5px;background:rgba(255,255,255,.05)}
    .log .lt{flex:0 0 auto;color:var(--tx3);font-family:ui-monospace,Consolas,monospace;font-size:10.5px}
    .log .lm{flex:1;min-width:0;color:var(--tx2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .log .err .lm,.log .warn .lm{white-space:normal;word-break:break-word}
    .log .ok .li{background:rgba(14,203,129,.12)}.log .ok .lm{color:var(--green)}
    .log .err .li{background:rgba(246,70,93,.15)}.log .err .lm{color:var(--red);font-weight:600}
    .log .warn .li{background:rgba(245,165,36,.14)}.log .warn .lm{color:var(--amber)}
    .log .buy .li{background:rgba(14,203,129,.14)}.log .buy .lm{color:var(--tx);font-weight:600}
    .log .sell .li{background:rgba(246,70,93,.14)}.log .sell .lm{color:var(--tx);font-weight:600}
    .log .ai .li{background:rgba(123,97,255,.16)}.log .ai .lm{color:#c9b8ff;white-space:normal;word-break:break-word}
    .log .info .li{background:rgba(61,139,253,.14)}.log .info .lm{color:#8ab4ff}
    .log .err{background:rgba(246,70,93,.06)}.log .ok.done{background:rgba(14,203,129,.07)}
    .log.f-trade .lr:not(.buy):not(.sell):not(.ok){display:none}
    .log.f-warn .lr:not(.warn):not(.err){display:none}
    .log::-webkit-scrollbar{width:6px}.log::-webkit-scrollbar-thumb{background:#2b3139;border-radius:3px}
    .ft{display:flex;align-items:center;gap:6px;margin-top:9px;font-size:10.5px;color:var(--tx3);padding:0 2px}
    .ft .sp{flex:1}
    .p.min{width:280px;padding-bottom:10px}
    .p.min .body{display:none}
    .mini{display:none;margin-top:2px;white-space:pre-line;font-variant-numeric:tabular-nums;color:var(--tx2);padding:0 2px}
    .p.min .mini{display:block}
    .hint{display:none;position:fixed;top:12px;left:50%;transform:translateX(-50%);background:var(--gold);color:#000;padding:8px 12px;border-radius:10px;font-size:13px;font-weight:600;box-shadow:0 4px 16px #0008;align-items:center;gap:8px;max-width:92vw}
    .hint button{background:#000;color:var(--gold);border:none}
    :host(.picking) .p{display:none}
    :host(.picking) .hint{display:flex}
    .all{width:100%;margin:6px 0;background:var(--gold);color:#1a1400;border:none;padding:8px}
  </style>
  <div class="hint" id="hint"><span id="hintText"></span><button id="skip" data-t="skip"></button><button id="cancel" data-t="cancel"></button></div>
  <div class="p" id="panel">
    <h3 id="drag"><span class="ttl"><img class="logo" alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAGfUlEQVR4nMWXe4zUVxXHP+feea+7sOyyC90FuhSKhbaUbtG2qUVEotY/jMZHGqtGLdRWSaM0pIkaWyO+0qQaH01spJAapUqriQFJJabxD2ttA0tsYipYSrMLy+7M7uzM7M78Xvf4x+83s8uKCYY1Pclv5s5vzuN7zr3ncYWYLBBl2q9aZ4z5sirvF+hL3gtXRgpECiMiHHXOPe5Xz73WtCnNRXZR3w5R+T5iFqOayC0kCYiAurKK7vGmRp4ErABk2/s/Z4z5ucaGI8Bw5Z7PJwUciBURnHOf96rD+yTb0b9G4CSQSxjNAhueTy75bihsNKLsQaSQIPx/GyexoYgURNkj2fa+ERFZnvy50GH/b6QAqno+JSLLLsuwzGPRKzqkEquUZSkuCvsllGpi3DkIw9n36fT/AGI+nzQdMqkWixgQ08Q2h1cgCiFtoac3xuMcFEtIJpsANHNEZmXFxIY0UmROBNVFENQBmANAUGNjRpFZRQJEIeGjT+FuvwVRH3pT2G/uxezfj3QtTRyUxGi8dIEjrAXgHJnOfOyrCIhBQg/1Z0Bk3qlXN/u4EETR8hjR1o/g3rUFiQqQ6wTbTvTgV3Bdi3EzNTT00dBDIw9/okJjpISGdbru7GLjk3fQ9b5e/Ikq6gI0CsBFLf9mI6AaG1TivRVBvTp0LMF99CGk7FCJ4giNO1jVg/vsDsy3H4Wly8A51I/ovG0pvXddzdIPrKJ9QzdgeP2nQyAhEMtrqxTMy3tVbUVAAa2WcB/cBb19MBUhpEFSEFgYd+hn7kUHBtDpKorD+T6dt/Ww9qF30L6+C5xS/MubVI6PYvIGf2Ka+oUponrQyqp5W6CoKoqg9Qqs2ADv2YmUQrAWTp2Co7+FlIWJAJYsQnfsQmcmQEBdyL8e+yvlE+cRMRiTonjsLAQhLghZefcaBn+4lfb1i3GNCDFzz0CSUtoE4U3DXV9F0gWohVhj4Nc/QL93HxTr4FIw7KGf+DTcuoWwOErqbSluPfJJujcNUP1nEa9RZ/zoGdQFRJUZ+j5+Ddc+cDuF65fgvBCMXGILxKDTJXj7NuwNH8IUfVI2i331FPrnX0FlHJ75WZyWJguRIUq1kV/XxabnH6B322ZGT5zlxa1PM/Sp3+NqPsu3r6XQ30al2KAU+viNsJWsLQDa/HQBagxm6yNIQzB1Ja1C9Nxe8KqQ7YRDj8PQWfTQIeRj76Znfcj1Lz1G++BNnDkyxEvbD+Cdm+bCoZP0vPdqtj1/P6u+dDO1yZBaKkfoJAagc7IAdXExmi4im3bAskHcRAPbmcO9+jLhiwdivF4Z9arYH91NfvNaun58L1133IJ6Z3nt679g+DtHkLSlcMNygtFJ6j6cc0K1AS5tqJBqFVSdm4YABA200A03P0xUdhgxmAD83+yGlddhNm1B1qwmNXgj2ZuuIX9dH+g4YwefpvTEYeqvvA4uojC4mmuPfZGJZ48zdewUF0yOGU8wWcN0I0UUCiJ6cR0AgzZKsHkvmuuHqQauO0f4wn60w2C++wrSXcAuAdogmJ4gOPAsk788gF/OwteewJw/g7vvw4QmTanRTi3M4weWyeksjYYllRXqtTQuknmFSAzqT6Hta2Hg/jjF0hYdm8KdfgYePoyaAozMEA79HU78AX3hd+jIGLL7ILL9TugAXbcBWfdOguIkpbEM4aQl8oTyeBpvxqB5oV4zRNHs6U8iIBA24MZvgV0EHpABOfkUrNkMx/8IB/+EvvE3ePMfENRA8pBWrDVoDVzZR1dnkC98A/eTB5kp52EmC76lUW/DeWnCKEUU5lFnZ1tNrmOl4ur42QHcxv0gCsZCWIKX74FwEmlUYpA2j+TawMa4tVaEFRsxu5/DteXQvMJiC4/cA9U3wFOYmoKBFcjIBcikkat6sWfHsJUaWIPkOvoVFKcGdUFcikXABbFRkwKbTiZaRZq9XTVeBR7kOiCTiYuZNeD7UC5COgPGgOdDNoMoEDkkl2215wRAnBTSGp016augaHOA4lIkYuLOqXOAGYOk0qhLxntj4oEmFphdJ2fAxQkuzUGtVRcuh1QdiL24q6iiUTT7e+764inKGVUdTdy7giFPY8XN57IEUFUdNYIcTjbk8lxeGHKIiCCH3/qLiVcZPq3KLhGTTKVELPzFkERnBGJEjFFll1cZPm0A61WH9zminaBlxNj/vAQsBInEurXsiHZ61eF9NC+nvIXX838DtfAmYlgaA88AAAAASUVORK5CYII="><span class="tt"><b>Alpha Volume Helper</b><small id="hsub">Binance Alpha</small></span><span class="badge" id="tgBadge" hidden>📱</span></span><span class="hbtns"><button class="who" id="who" type="button"><span class="av" id="whoAv">?</span><span id="whoName"></span></button><button class="mbtn" id="mbtn" type="button">☰<i class="mdot" id="mdot" hidden></i></button><button class="x" id="min">–</button><button class="x" id="close">✕</button></span></h3>
    <div class="stl" id="stl"><i class="dot"></i><b id="stlA"></b><span id="stlB"></span><span class="cn" id="cnSheet"><i></i>Sheet</span><span class="cn" id="cnTg" hidden><i></i>Telegram</span></div>
    <div class="upd" id="upd" hidden><div class="updT" id="updT"></div><div class="updN" id="updN"></div><button id="updGo" data-t="updGo"></button></div>
    <div class="mini" id="miniProg"></div>
    <div class="mmenu" id="mmenu" hidden>
      <button data-v="dSet"><span class="ic">⚙</span><span><span data-t="settings"></span><small data-t="mSetSub"></small></span></button>
      <button data-v="dBak"><span class="ic">💾</span><span><span data-t="backup"></span><small data-t="mBakSub"></small></span></button>
      <button data-v="dSel"><span class="ic">🎯</span><span><span data-t="mSelName"></span><small data-t="mSelSub"></small></span></button>
      <button data-v="dStats"><span class="ic">📊</span><span><span data-t="stTitle"></span><small data-t="stSub"></small></span></button>
      <button data-v="dAir"><span class="ic">📰</span><span><span data-t="airTitle"></span><small data-t="airSub"></small></span><b class="mbadge" id="airBadge" hidden></b></button>
    </div>
    <div class="body" id="pbody">
    <div class="mhead" id="mhead"><button id="mback" data-t="mBack"></button><b id="mtitle"></b></div>
    <div class="hero">
      <div class="ring"><svg viewBox="0 0 92 92"><defs><linearGradient id="avhRg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fcd535"/><stop offset="1" stop-color="#0ecb81"/></linearGradient></defs><circle cx="46" cy="46" r="38" stroke="rgba(255,255,255,.07)" stroke-width="8" fill="none"/><circle id="ringArc" cx="46" cy="46" r="38" stroke="url(#avhRg)" stroke-width="8" fill="none" stroke-linecap="round" stroke-dasharray="238.8" stroke-dashoffset="238.8" transform="rotate(-90 46 46)"/></svg><div class="rc"><span id="barp">0%</span><small data-t="hTarget"></small></div></div>
      <div class="hv">
        <div class="lb"><span data-t="hVol"></span><span class="tag" id="pmTag"></span><span class="tag" id="aiTag"></span></div>
        <div class="big"><span id="hvVol">0.00</span><span id="hvTgt"></span></div>
        <div class="meta"><span><span data-t="cTrades"></span> <b id="cvTr">0</b></span><span><span data-t="cRun"></span> <b id="cvEl">–</b></span><span><span data-t="cEta"></span> <b id="cvEta">–</b></span></div>
      </div>
    </div>
    <div class="ctl">
      <button class="go" id="start"></button>
      <button class="stop" id="stop" data-t="stop"></button>
      <button id="pause" data-t="pause" disabled></button>
      <button id="reset" data-t="reset"></button>
    </div>
    <div class="cards" id="cards">
      <div class="cd" id="ccLoss"><small id="clLoss"></small><b id="cvLoss">–</b><i>USDT</i><svg id="plSpark" viewBox="0 0 44 16"></svg></div>
      <div class="cd" id="ccPer"><small id="clPer"></small><b id="cvPer">–</b><i>USDT</i></div>
      <div class="cd"><small data-t="cBal"></small><b id="cvBal">–</b><i>USDT</i></div>
    </div>
    <div class="mk" id="mk">
      <div class="mh"><span data-t="mkTitle"></span><span class="cstate wait" id="cstate"></span><span class="kpx" id="kpx"></span></div>
      <div class="mrow">
      <div class="sg" id="sgbox" hidden><svg viewBox="0 0 96 56"><defs><linearGradient id="avhSg" x1="0" x2="1"><stop offset="0" stop-color="#0ecb81"/><stop offset=".5" stop-color="#f5a524"/><stop offset="1" stop-color="#f6465d"/></linearGradient></defs><path d="M8 50 A40 40 0 0 1 88 50" stroke="rgba(255,255,255,.07)" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M8 50 A40 40 0 0 1 88 50" stroke="url(#avhSg)" stroke-width="8" fill="none" stroke-linecap="round"/><line id="sgNeedle" x1="48" y1="50" x2="15.2" y2="50" stroke="#fff" stroke-width="2.5" stroke-linecap="round"/><circle cx="48" cy="50" r="4.5" fill="#fff"/></svg><div class="sv n" id="sgVal">–</div><div class="sw" id="sgWord"></div><span id="sgAsk" hidden></span><span id="sgBid" hidden></span></div>
      <div class="kbox" id="kbox" hidden>
        <div class="kh"><b>১ মি.</b><span id="k1i"></span></div><svg id="k1svg" viewBox="0 0 220 62" preserveAspectRatio="none"></svg>
        <div class="kh"><b>১৫ সে.</b><span id="k15i"></span></div><svg id="k15svg" viewBox="0 0 220 40" preserveAspectRatio="none"></svg>
      </div>
      </div>
    </div>
    <div id="prog"></div>
    <div id="ptRow"></div>
    <div class="lgw"><div class="lgh"><span data-t="lgTitle"></span><span class="seg" id="lgf"><button type="button" class="on" data-f="" data-t="lgAll"></button><button type="button" data-f="f-trade" data-t="lgTrade"></button><button type="button" data-f="f-warn" data-t="lgWarn"></button></span></div>
    <div class="log" id="log"></div></div>
    <div class="ft"><span id="ftSync"></span><span class="sp"></span><span id="ftVer"></span></div>

    <details id="dSet">
      <summary data-t="settings"></summary>
      <div class="grp" data-t="gLang"></div>
      <label><span>বাংলা / English</span><select id="lang"><option value="bn">বাংলা</option><option value="en">English</option></select></label>

      <div class="grp" data-t="gPreset"></div>
      <div class="row"><button type="button" class="pset" data-p="fast" data-t="psFast"></button><button type="button" class="pset" data-p="safe" data-t="psSafe"></button></div>
      <div class="note" data-t="psNote"></div>

      <div class="grp" data-t="gTrade"></div>
      ${L("amount", num("amount", 'min="0" step="any"'))}
      ${L("target", num("target", 'min="0" step="any"'))}
      ${L("ptOn", chk("ptOn"))}
      ${L("ptMult", '<select id="ptMult"><option value="1">×1</option><option value="2">×2 (BSC)</option><option value="4">×4</option></select>')}
      <div class="note" data-t="ptNote"></div>
      ${L("amountJitter", num("amountJitter", 'min="0" max="50" step="any"'))}
      ${L("minDelay", num("minDelay", 'min="1" step="any"'))}
      ${L("maxDelay", num("maxDelay", 'min="1" step="any"'))}
      ${L("sellDecimals", num("sellDecimals", 'min="0" max="8" step="1"'))}
      <div hidden>
      ${L("priceMode", '<select id="priceMode"><option value="suggest" data-t="pmSuggest"></option><option value="live" data-t="pmLive"></option></select>')}
      ${L("countSell", chk("countSell"))}
      ${L("heldMode", '<select id="heldMode"><option value="sell" data-t="heldSell"></option><option value="keep" data-t="heldKeep"></option></select>')}
      ${L("sellStep", num("sellStep", 'min="0" max="1" step="any"'))}
      ${L("sellFastWait", num("sellFastWait", 'min="2" step="1"'))}
      </div>

      <div class="grp" data-t="gFill"></div>
      <div hidden>${L("fillTimeout", num("fillTimeout", 'min="3" step="1"'))}</div>
      ${L("retries", num("retries", 'min="0" max="10" step="1"'))}
      ${L("liveWait", num("liveWait", 'min="2" step="1"'))}
      ${L("liveBuf", num("liveBuf", 'min="0" max="1" step="any"'))}
      ${L("autoBuf", chk("autoBuf"))}
      <div class="note" data-t="bufNote"></div>

      <div class="grp" data-t="gSafe"></div>
      ${L("balAlert", num("balAlert", 'min="0" max="50" step="any"'))}
      ${L("stopAfter", num("stopAfter", 'min="0" step="1"'))}
      ${L("stopAt", '<input type="time" id="stopAt">')}
      <div class="note" data-t="timeNote"></div>
      ${L("lossOn", chk("lossOn"))}
      ${L("maxLoss", num("maxLoss", 'min="0" step="any"'))}
      ${L("spreadOn", chk("spreadOn"))}
      ${L("maxSpread", num("maxSpread", 'min="0" step="any"'))}
      ${L("depthOn", chk("depthOn"))}
      ${L("minDepth", num("minDepth", 'min="1" step="any"'))}
      ${L("spreadWait", num("spreadWait", 'min="1" step="any"'))}
      ${L("autoSpeed", chk("autoSpeed"))}
      ${L("autoCost", num("autoCost", 'min="0.05" step="any"'))}
      <div class="note" data-t="spNote"></div>


      <div class="grp" data-t="gDz"></div>
      ${L("dzOn", chk("dzOn"))}
      <div class="note" data-t="dzNote"></div>
      ${L("entryMode", '<select id="entryMode"><option value="stable" data-t="emStable"></option><option value="bull" data-t="emBull"></option><option value="off" data-t="emOff"></option></select>')}
      <div class="note" data-t="emNote"></div>
      ${L("obOn", chk("obOn"))}
      <div class="note" data-t="obNote"></div>
      ${L("makerSell", chk("makerSell"))}
      ${L("makerWait", num("makerWait", 'min="2" max="60" step="1"'))}
      ${L("makerAuto", chk("makerAuto"))}

      <div hidden>${L("makerStop", num("makerStop", 'min="0.01" max="1" step="any"'))}</div>
      <div class="note" data-t="makerNote"></div>
      <div hidden>${L("aiOn", chk("aiOn"))}</div>
      ${L("aiWant", chk("aiWant"))}
      ${L("aiProv", '<select id="aiProv"><option value="openrouter">OpenRouter</option><option value="groq">Groq</option></select>')}
      ${L("aiKey", '<input type="password" id="aiKey" autocomplete="off">')}
      ${L("aiModel", '<input type="text" id="aiModel" list="aiModels" autocomplete="off" spellcheck="false"><datalist id="aiModels"></datalist>')}
      ${L("orMode", '<select id="orMode"><option value="free" data-t="orModeFree"></option><option value="paid" data-t="orModePaid"></option></select>')}
      ${L("orPaid", chk("orPaid"))}
      ${L("aiEvery", '<select id="aiEvery"><option value="15">15</option><option value="30">30</option><option value="60">60</option><option value="90">90</option><option value="120">120</option></select>')}
      ${L("aiConf", num("aiConf", 'min="0" max="100" step="1"'))}
      <div class="row"><button id="aiTest" data-t="aiTest"></button><button id="pCheck" data-t="pCheck"></button></div>
      <div class="note" data-t="aiNote"></div>
      <div class="grp" data-t="gRetry"></div>
      ${L("retryOn", chk("retryOn"))}
      ${L("retryMax", num("retryMax", 'min="1" max="20" step="1"'))}
      ${L("retryWait", num("retryWait", 'min="3" step="1"'))}
      <div class="note" data-t="retryNote"></div>

      <div class="grp" data-t="gReload"></div>
      ${L("healOn", chk("healOn"))}
      <div class="note" data-t="healNote"></div>

      <div class="grp" data-t="gAlert"></div>
      ${L("notifyOn", chk("notifyOn"))}
      ${L("soundOn", chk("soundOn"))}
      <div class="row"><button id="testNotify" data-t="testNotify"></button><button id="testSound" data-t="testSound"></button></div>


    </details>

    <details id="dBak">
      <summary data-t="backup"></summary>
      ${L("syncOn", chk("syncOn"))}
      <div class="note" data-t="syncNote"></div>
      <div class="row"><button id="exportCfg" data-t="exportCfg"></button><button id="importCfg" data-t="importCfg"></button></div>
      <input type="file" id="importFile" accept=".json,application/json" hidden>
      <div class="note" data-t="shortcuts"></div>
    </details>

    <details id="dStats">
      <summary data-t="stTitle"></summary>
      <div class="grp" data-t="plTitle"></div>
      ${L("ptGoal", num("ptGoal", 'min="0" step="1"'))}
      ${L("ptBalPts", num("ptBalPts", 'min="0" max="20" step="1"'))}
      <div class="note pre" id="plOut"></div>
      <div class="grp" data-t="hsTitle"></div>
      <div class="note pre" id="hsOut"></div>
      <div class="grp" data-t="tsTitle"></div>
      <div class="note pre" id="tsOut"></div>
      <div class="grp" data-t="dhTitle"></div>
      <div class="note pre" id="dhOut"></div>
      <div class="row"><button id="stReset" data-t="stReset"></button></div>
    </details>

    <details id="dAir">
      <summary data-t="airTitle"></summary>
      ${L("airOn", chk("airOn"))}
      ${L("airTg", chk("airTg"))}
      <div class="note" data-t="airNote"></div>
      <div class="row"><button id="airCheck" data-t="airCheck"></button></div>
      <div class="note" id="airSt"></div>
      <div id="airList"></div>
    </details>

    <details id="dSel">
      <summary data-t="selTitle"></summary>
      <button class="all" id="pickAll" data-t="pickAll"></button>
      ${L("selAuto", chk("selAuto"))}
      <div class="row"><button id="selPull" data-t="selPullBtn"></button><button id="selPush" data-t="selPushBtn"></button></div>
      <div class="note" data-t="selNote"></div>
      <div id="sels"></div>
    </details>
    </div>
  </div>`;

  const $ = (id) => root.getElementById(id);
  const EM_LBL = { stable: "emStable", bull: "emBull", off: "emOff" };
  // একটা অংশ খুললে বাকিগুলো বন্ধ — জায়গা কম লাগে
  // সেটিংস / ব্যাকআপ / পেজের বাটন — উপরের ☰ মেনু থেকে, আলাদা পাতায় খোলে
  const SECTIONS = ["dSet", "dBak", "dSel", "dAir", "dStats"];
  const MICON = { dSet: "⚙", dBak: "💾", dSel: "🎯", dAir: "📰", dStats: "📊" };
  let curView = null;
  function closeMenu() { $("mmenu").hidden = true; $("mbtn").classList.remove("on"); }
  function openView(id) {
    closeMenu();
    for (const o of SECTIONS) { const d = $(o); d.classList.toggle("cur", o === id); d.open = o === id; }
    curView = id;
    $("mtitle").textContent = MICON[id] + " " + $(id).querySelector("summary").textContent;
    $("pbody").classList.add("inview");
    $("panel").scrollTop = 0;
    if (id === "dAir") airSeenAll();
    if (id === "dStats") renderStats();
  }
  function closeView() {
    if (!curView) return;
    if (curView === "dAir") airSeenAll(true);
    $("pbody").classList.remove("inview");
    for (const o of SECTIONS) { $(o).classList.remove("cur"); $(o).open = false; }
    curView = null;
  }
  $("mbtn").addEventListener("click", (e) => {
    e.stopPropagation();
    const open = $("mmenu").hidden;
    if (open && $("panel").classList.contains("min")) toggleMin();
    $("mmenu").hidden = !open; $("mbtn").classList.toggle("on", open);
  });
  root.querySelectorAll("#mmenu button[data-v]").forEach((b) => b.addEventListener("click", () => openView(b.dataset.v)));
  $("mback").addEventListener("click", closeView);
  // এক চাপে সাজানো সেটিং (প্রিসেট) — শুধু ট্রেডের ধরন-সংক্রান্ত ঘর বদলায়; অ্যামাউন্ট/টার্গেট/বাটন/Telegram আগের মতো থাকে
  const PRESETS = {
    fast: { entryMode: "stable", makerSell: true, dzOn: true, priceMode: "live", liveBuf: 0.08, liveWait: 3, spreadOn: true, maxSpread: 0.15, minDelay: 2, maxDelay: 4, retryOn: true },
    safe: { entryMode: "stable", makerSell: true, dzOn: true, priceMode: "live", liveBuf: 0.08, liveWait: 3, spreadOn: true, maxSpread: 0.1, minDelay: 5, maxDelay: 10, autoSpeed: true, retryOn: true },
  };
  root.querySelectorAll(".pset").forEach((b) => b.addEventListener("click", () => {
    if (state.running) return log(T("cfgRunning"));
    const p = PRESETS[b.dataset.p];
    Object.assign(cfg, p); aiSync(); cfg.bufAuto = 0; abuf = null; clampCfg(); save(); renderInputs();
    log("✅ " + T("psDone", b.textContent));
  }));
  // কার্যকলাপের ছাঁকনি: সব / ট্রেড / সতর্কতা
  root.querySelectorAll("#lgf button").forEach((b) => b.addEventListener("click", () => {
    root.querySelectorAll("#lgf button").forEach((x) => x.classList.toggle("on", x === b));
    $("log").className = "log" + (b.dataset.f ? " " + b.dataset.f : "");
  }));
  root.addEventListener("click", (e) => { if (!$("mmenu").hidden && !e.composedPath().some((n) => n === $("mmenu") || n === $("mbtn"))) closeMenu(); });
  const fields = ["amount", "target", "amountJitter", "minDelay", "maxDelay", "maxLoss", "sellDecimals", "fillTimeout", "retries", "sellStep", "sellFastWait", "liveWait", "liveBuf", "maxSpread", "minDepth", "spreadWait", "retryMax", "retryWait", "aiConf", "autoCost", "makerWait", "makerStop", "balAlert", "stopAfter", "ptGoal", "ptBalPts"];
  const checks = ["countSell", "syncOn", "lossOn", "spreadOn", "depthOn", "retryOn", "notifyOn", "soundOn", "dzOn", "ptOn", "autoBuf", "autoSpeed", "healOn", "makerSell", "obOn", "makerAuto", "aiWant", "orPaid", "airOn", "airTg", "selAuto"];

  function applyI18n() {
    root.querySelectorAll("[data-t]").forEach((el) => { el.textContent = T(el.dataset.t); });
    $("drag").title = T("dragTitle"); $("min").title = T("minTitle"); $("close").title = T("closeTitle");
    if ($("pause")) $("pause").textContent = paused ? T("resume") : T("pause");
    if ($("start")) $("start").textContent = state.running ? T("runningBtn") : T("start");
    if ($("stl")) setStatus(stKind, stText);
    if ($("who")) renderWho();
    if ($("upd")) renderUpd();
    renderSelectors();
    renderProgress();
  }

  // লগ: প্রতি লাইন আলাদা সারি — সময় ধূসর, বার্তা ধরন অনুযায়ী রঙে; নতুনটা উপরে, সর্বোচ্চ ৮০ সারি
  function logKind(m) {
    if (/^❌|সমস্যা|error|stopping|থামছি/i.test(m)) return "err";
    if (/^🎯/u.test(m)) return "ai"; // মেকার Sell — পুরো লেখা দেখাও
    if (/^✅/.test(m)) return "ok done";
    if (/^✓|পূরণ হয়েছে|filled|বাতিল হয়েছে|cancelled/i.test(m)) return "ok";
    if (/লাভ:|profit:/i.test(m) && !/লস:|loss:/i.test(m.split("·")[0])) return "ok";
    if (/^⚠|^🛑|সতর্ক|warning/i.test(m)) return "warn";
    if (/^Buy\b/.test(m)) return "buy";
    if (/^Sell\b/.test(m)) return "sell";
    if (/^▶|^↻|^📱|^💾|^⏸/.test(m)) return "info";
    return "";
  }
  // প্রতি লাইনের শুরুতে আইকন: বার্তায় আগে থেকে চিহ্ন থাকলে সেটাই, না থাকলে ধরন দেখে
  function logIcon(m, kind) {
    const lead = m.match(/^(ℹ\uFE0F?|[^\p{L}\p{N}\s"'(\[]+)\s*/u);
    if (lead) return [lead[1], m.slice(lead[0].length)];
    let ic = "•";
    if (kind === "err") ic = "❌";
    else if (/^Buy\b/.test(m)) ic = "🟢";
    else if (/^Sell\b/.test(m)) ic = "🔴";
    else if (/অপেক্ষা|wait/i.test(m)) ic = "⏸";
    else if (/বাতিল|cancel/i.test(m)) ic = "🚫";
    else if (/^[^·]*(লাভ|profit):/i.test(m)) ic = "💚";
    else if (/লস|loss/i.test(m)) ic = "💸";
    else if (/ভলিউম|volume/i.test(m)) ic = "📈";
    else if (/দাম|price/i.test(m)) ic = "💲";
    else if (/ব্যালেন্স|balance/i.test(m)) ic = "💰";
    else if (/শুরু|start/i.test(m)) ic = "▶";
    return [ic, m];
  }
  function log(msg) {
    const t = new Date().toLocaleTimeString("en-GB");
    const el = $("log");
    const row = document.createElement("div");
    const kind = logKind(String(msg));
    row.className = "lr " + kind;
    const [ic, text] = logIcon(String(msg), kind);
    const ts = document.createElement("span"); ts.className = "lt"; ts.textContent = t;
    const is = document.createElement("span"); is.className = "li"; is.textContent = ic;
    const ms = document.createElement("span"); ms.className = "lm"; ms.textContent = text;
    row.append(ts, is, ms, document.createTextNode("\n"));
    el.prepend(row);
    while (el.children.length > 80) el.lastElementChild.remove();
  }

  // ---------- ব্যাকগ্রাউন্ডের সাথে যোগাযোগ ----------
  // এক্সটেনশন reload/আপডেট হলে পুরনো পেজের সংযোগ কেটে যায় — তখন পেজ রিফ্রেশ করতে বলো
  let orphanWarned = false;
  function extAlive() {
    try { return !!(chrome.runtime && chrome.runtime.id); } catch (_) { return false; }
  }
  function warnOrphan() {
    if (orphanWarned) return;
    orphanWarned = true;
    log(T("orphan"));
    const h = root.querySelector("h3"); if (h) h.style.background = "#5c1d24";
  }
  function bg(msg, timeoutMs = 10000) {
    return new Promise((resolve) => {
      let done = false;
      const fin = (v) => { if (!done) { done = true; resolve(v); } };
      if (!extAlive()) { warnOrphan(); return fin(null); }
      setTimeout(() => fin(null), timeoutMs);
      try { chrome.runtime.sendMessage(msg, (res) => { if (chrome.runtime.lastError) fin(null); else fin(res); }); }
      catch (_) { warnOrphan(); fin(null); }
    });
  }

  // ---------- একসাথে একটাই ট্যাব চালাবে ----------
  // চলমান ট্যাব নিয়মিত avhLock-এ সময় লেখে; অন্য ট্যাব তা টাটকা দেখলে নিজে শুরু/রিজিউম/শিডিউল/Telegram কিছুই করে না
  const TAB_ID = Math.random().toString(36).slice(2) + Date.now().toString(36);
  const LOCK_STALE = 120000;
  let lockCache = null, lastBeat = 0, starting = false;
  const otherTabRunning = () => !!(lockCache && lockCache.id !== TAB_ID && Date.now() - lockCache.ts < LOCK_STALE);
  const getLock = () => new Promise((r) => {
    try { chrome.storage.local.get("avhLock", (d) => r((d && d.avhLock) || null)); } catch (_) { r(null); }
  });
  function beat() {
    lastBeat = Date.now();
    lockCache = { id: TAB_ID, ts: lastBeat };
    try { chrome.storage.local.set({ avhLock: lockCache }); } catch (_) {}
    // পেজ জমে গেলে/বন্ধ হলে ব্যাকগ্রাউন্ড টের পেয়ে ট্যাব রিলোড করবে
    if (state.running) { try { chrome.runtime.sendMessage({ type: "avh-wd", on: true, heal: !!cfg.healOn }, () => void chrome.runtime.lastError); } catch (_) {} }
  }
  function releaseLock() {
    if (!lockCache || lockCache.id !== TAB_ID) return;
    lockCache = null;
    try { chrome.storage.local.remove("avhLock"); } catch (_) {}
  }
  async function acquireLock() {
    lockCache = await getLock();
    if (otherTabRunning()) return false;
    beat();
    // দুই ট্যাব একসাথে লিখলে শেষে যেটা লিখেছে সেটাই জিতবে
    await new Promise((r) => setTimeout(r, 400));
    lockCache = (await getLock()) || lockCache;
    return !otherTabRunning();
  }
  try {
    chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.avhLock) lockCache = ch.avhLock.newValue || null; });
  } catch (_) {}
  setInterval(() => { if (state.running) beat(); }, 10000);

  // ট্যাব লুকানো থাকলে Chrome পেজের setTimeout ধীর করে দেয়; তাই অপেক্ষাটা এক্সটেনশনের ব্যাকগ্রাউন্ডে করানো হয়
  function sleep(ms) {
    if (state.running && Date.now() - lastBeat > 5000) beat(); // লুকানো ট্যাবে setInterval ধীর হয়, তাই এখানেও
    return new Promise((resolve) => {
      let done = false;
      const fin = () => { if (!done) { done = true; resolve(); } };
      setTimeout(fin, ms);
      if (ms < 100) return;
      if (!extAlive()) { warnOrphan(); return; }
      try { chrome.runtime.sendMessage({ type: "avh-sleep", ms }, () => { if (!chrome.runtime.lastError) fin(); }); } catch (_) { warnOrphan(); }
    });
  }

  // ---------- সতর্কতা: নোটিফিকেশন, শব্দ, Telegram ----------
  function notify(title, message, { error = false, done = false } = {}) {
    if (cfg.notifyOn) bg({ type: "avh-notify", title, message });
    if (cfg.soundOn && (error || done)) bg({ type: "avh-beep", kind: error ? "error" : "done" });
    if (tgReady()) tgSend(`${title}\n${message}`);
  }
  // ---------- নতুন ভার্সনের খবর (মালিকের Google Sheet-এর "ভার্সন" পাতা থেকে) ----------
  const verNum = (v) => String(v || "").trim().replace(/^v/i, "").split(".").map((x) => parseInt(x, 10) || 0);
  function verCmp(a, b) {
    const x = verNum(a), y = verNum(b);
    for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0 ? 1 : -1; }
    return 0;
  }
  // "সর্বনিম্ন ভার্সন" তখনই মানা হবে যখন সেটা সঠিক নম্বর আর "সর্বশেষ ভার্সন"-এর চেয়ে বড় না (Sheet-এ ভুল লিখলে সবাই আটকে যাবে না)
  const verOk = (v) => /^v?\d+(\.\d+){0,3}$/.test(String(v || "").trim());
  function mustUpdate() {
    if (!verInfo || !verOk(verInfo.min)) return false;
    if (!verOk(verInfo.latest) || verCmp(verInfo.min, verInfo.latest) > 0) return false;
    return verCmp(MY_VER, verInfo.min) < 0;
  }
  function renderUpd() {
    const box = $("upd"); if (!box) return;
    const newer = !!(verInfo && verInfo.latest && verCmp(verInfo.latest, MY_VER) > 0);
    const must = mustUpdate();
    box.hidden = !(newer || must);
    if (box.hidden) return;
    box.classList.toggle("must", must);
    $("updT").textContent = must ? T("updMust", MY_VER, verInfo.min) : T("updNew", verInfo.latest, MY_VER);
    $("updN").textContent = verInfo.notes ? T("updNotes", verInfo.notes) : "";
    $("updGo").hidden = !verInfo.url;
  }
  const DL_URL = "https://github.com/YAHIAHOSSAIN/alpha-volume-helper-download"; // ডাউনলোড পাতা (পাবলিক GitHub)
  async function checkUpdate() {
    const r = await bg({ type: "avh-ver", url: REPORT_URL }, 25000);
    if (!r || !r.ok) return;
    verInfo = { latest: String(r.latest || ""), url: String(r.url || ""), notes: String(r.notes || "").slice(0, 300), min: String(r.min || "") };
    chrome.storage.local.set({ avhVerInfo: verInfo });
    renderUpd();
    if (verInfo.latest && verCmp(verInfo.latest, MY_VER) > 0) {
      const d = await lget("avhVerSeen");
      if (d.avhVerSeen !== verInfo.latest) {
        chrome.storage.local.set({ avhVerSeen: verInfo.latest });
        const msg = T("updNew", verInfo.latest, MY_VER) + (verInfo.notes ? "\n" + verInfo.notes : "") + (verInfo.url ? "\n" + verInfo.url : "");
        log(T("updNew", verInfo.latest, MY_VER));
        bg({ type: "avh-notify", title: "Alpha Volume Helper", message: msg });
      }
      // Telegram-এ আলাদা হিসাব: তখন যুক্ত না থাকলেও পরে যুক্ত হলে একবার পাঠাবে
      const tv = (await lget("avhVerTg")).avhVerTg;
      if (tgReady() && tv !== verInfo.latest && !srvUpd) { // সার্ভার নিজে খবর দিলে (Cron চালু) এখান থেকে আর নয়
        chrome.storage.local.set({ avhVerTg: verInfo.latest });
        tgSend(T("updNew", verInfo.latest, MY_VER) + (verInfo.notes ? "\n" + verInfo.notes : "") + "\n⬇ " + (verInfo.url || DL_URL));
      }
    }
  }
  // শেষ জানা তথ্য আগে দেখাও (নেট না থাকলেও "সর্বনিম্ন ভার্সন" মানা হবে), তারপর ১০ সে. পর ও প্রতি ৩ ঘণ্টায় দেখো
  try { chrome.storage.local.get("avhVerInfo", (d) => { if (d && d.avhVerInfo && !verInfo) { verInfo = d.avhVerInfo; renderUpd(); } }); } catch (_) {}
  setTimeout(() => checkUpdate(), 10000);
  setTimeout(() => dangerLoop(), 3000);
  setInterval(() => checkUpdate(), 30 * 60 * 1000); // নতুন ভার্সনের খবর ৩০ মিনিটে একবার

  // ---------- হিসাব পাঠানো (Google Sheet): প্রতি Buy/Sell ও রান শেষে নাম দিয়ে একটা সারি ----------
  // না পাঠানো গেলে লাইনে জমে থাকে (সর্বোচ্চ ৫০০), পরে নিজে আবার পাঠায়; Sheet-এর স্ক্রিপ্ট id দেখে দুবার গোনে না
  const lget = (k) => new Promise((r) => { try { chrome.storage.local.get(k, (d) => r(d || {})); } catch (_) { r({}); } });
  // টোকেনের নাম: পেজের শিরোনাম থেকে প্রথম আসল নাম (দাম/সংখ্যা ও সাধারণ শব্দ বাদ); না পেলে কন্ট্র্যাক্ট ঠিকানা ছোট করে
  const TOKEN_SKIP = new Set(["USDT", "USDC", "USD", "BINANCE", "ALPHA", "PRICE", "CHART", "TRADE", "BUY", "SELL", "BSC", "SOL", "ETH", "BASE", "LIVE", "TODAY", "MARKET", "SPOT", "DEX", "TO", "AND", "THE"]);
  function tokenName() {
    const words = (document.title || "").match(/[A-Za-z0-9$_.-]+/g) || [];
    for (const w of words) {
      const u = w.replace(/^[$.]+|[.]+$/g, "");
      if (!/[A-Za-z]/.test(u) || u.length < 2 || u.length > 15) continue;
      if (TOKEN_SKIP.has(u.toUpperCase())) continue;
      if (u === u.toUpperCase()) return u;
    }
    const a = (location.pathname.match(/0x[0-9a-fA-F]{40}/) || [])[0];
    return a ? a.slice(0, 6) + "…" + a.slice(-4) : (location.pathname.split("/").filter(Boolean).pop() || "").slice(0, 14);
  }
  // অর্ডার দেওয়ার মুহূর্তের দাম (Sheet-এর "প্রাইজ" কলামের জন্য): Price ঘরের মান, না পেলে বিকল্প
  function orderPx(fallback) {
    try {
      const p = cfg.selectors.priceInput ? find("priceInput") : null;
      const v = p ? parseFloat(String(p.value || p.innerText || "").replace(/,/g, "")) : NaN;
      if (v > 0) return v;
      const f = fallback && fallback();
      return f > 0 ? +f : null;
    } catch (_) { return null; }
  }
  // ৬.১: পরিচয় = Telegram (যুক্ত করা বাধ্যতামূলক) — Sheet-এ আর প্যানেলের উপরে Telegram username
  const uName = () => String(cfg.tgSChat ? cfg.tgSName || "tg:" + cfg.tgSChat : "").slice(0, 40);
  function repEvent(ev) {
    let v = ""; try { v = chrome.runtime.getManifest().version; } catch (_) {}
    return { ...ev, name: uName(), token: tokenName(), ts: Date.now(), id: TAB_ID + "-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 7), v };
  }
  // আজকের হিসাব (Telegram /today) — এই কম্পিউটারে, দিন বদলালে নতুন করে
  // Alpha-র দিন UTC ধরে (বাংলাদেশে সকাল ৬টায় নতুন দিন) — পয়েন্টের হিসাবের সাথে মিল
  function alphaDay() { return new Date().toISOString().slice(0, 10); }
  // দিন বদলালে আগের দিন ইতিহাসে (শেষ ৩০ দিন) আর সকাল ৬টার রিপোর্ট Telegram-এ (একাধিক ট্যাবেও একবার)
  let dayRolling = false;
  async function dayRoll() {
    if (dayRolling) return;
    dayRolling = true;
    try {
      const today = alphaDay();
      const g = await lget(["avhDay", "avhDayHist", "avhDayRep"]);
      const d = g.avhDay;
      if (!d || !d.d || d.d === today) return;
      const hist = (Array.isArray(g.avhDayHist) ? g.avhDayHist : []).filter((x) => x.d !== d.d).concat([d]).slice(-30);
      await new Promise((r) => chrome.storage.local.set({ avhDayHist: hist, avhDay: { d: today, vol: 0, trades: 0, loss: 0, buy: 0, toks: {} }, avhDayRep: d.d }, r));
      if (g.avhDayRep !== d.d && d.vol > 0) {
        const txt = dayReport(d);
        log("📅 " + txt.split("\n")[0]);
        if (cfg.dayRep && tgReady()) tgSend(txt);
      }
    } catch (_) {} finally { dayRolling = false; }
  }
  function dayReport(d) {
    const m = [1, 2, 4].includes(+cfg.ptMult) ? +cfg.ptMult : 1;
    const pts = ptOf((d.buy || d.vol / 2) * m * PT_SAFE);
    const per = d.vol > 0 ? ((d.loss || 0) / d.vol) * 1000 : null;
    const toks = Object.entries(d.toks || {}).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([k, v]) => `${k} ${fmtK(v)}`).join(", ");
    return T("dayRepMsg", d.d, fmtK(d.vol), d.trades || 0, (d.loss < 0 ? "+" + fmt(-d.loss) : fmt(d.loss || 0)) + " USDT", per != null ? per.toFixed(3) : "–", pts, m, toks || "–");
  }
  async function dayAdd(ev) {
    try {
      await dayRoll();
      const today = alphaDay();
      const d = (await lget("avhDay")).avhDay;
      const s = d && d.d === today ? d : { d: today, vol: 0, trades: 0, loss: 0, buy: 0, toks: {} };
      s.vol += +ev.vol || 0; s.trades += +ev.trades || 0;
      if (ev.type === "buy") s.buy = (s.buy || 0) + (+ev.vol || 0);
      if (+ev.vol > 0) { const tk = tokenName(); s.toks = s.toks || {}; s.toks[tk] = (s.toks[tk] || 0) + (+ev.vol || 0); }
      if (ev.type === "loss" || ev.type === "profit") s.loss += +ev.loss || 0;
      chrome.storage.local.set({ avhDay: s });
    } catch (_) {}
  }
  // প্রতি রাউন্ডের ফল জমানো: ঘণ্টা ধরে (বাংলাদেশ সময়) আর টোকেন ধরে — কখন আর কোন টোকেনে খরচ কম
  let mkLastRound = null;
  async function statRound(vol, loss) {
    try {
      if (!(vol > 0) || !isFinite(loss)) return;
      const g = await lget(["avhHourStat", "avhTokStat"]);
      const hs = Array.isArray(g.avhHourStat) && g.avhHourStat.length === 24 ? g.avhHourStat : Array.from({ length: 24 }, () => ({ v: 0, l: 0, mt: 0, mh: 0 }));
      const h = new Date().getHours(), x = hs[h];
      x.v += vol; x.l += loss;
      if (mkLastRound != null) { x.mt++; if (mkLastRound) x.mh++; }
      const ts = g.avhTokStat && typeof g.avhTokStat === "object" ? g.avhTokStat : {};
      const tk = tokenName(), t = ts[tk] || (ts[tk] = { v: 0, l: 0, n: 0, at: 0 });
      t.v += vol; t.l += loss; t.n++; t.at = Date.now();
      const keep = Object.entries(ts).sort((a, b) => b[1].at - a[1].at).slice(0, 40);
      chrome.storage.local.set({ avhHourStat: hs, avhTokStat: Object.fromEntries(keep) });
    } catch (_) {} finally { mkLastRound = null; }
  }
  async function reportPush(ev) {
    dayAdd(ev);
    if (ev.type === "buy") ptAdd(ev.vol);
    if (!uName()) return;
    const d = await lget("avhRepQ");
    const q = Array.isArray(d.avhRepQ) ? d.avhRepQ : [];
    q.push(repEvent(ev));
    while (q.length > 500) q.shift();
    chrome.storage.local.set({ avhRepQ: q });
    reportFlush();
  }
  let repBusy = false, repWarned = false;
  async function reportFlush() {
    if (repBusy) return;
    repBusy = true;
    try {
      for (let i = 0; i < 20; i++) {
        const q = (await lget("avhRepQ")).avhRepQ || [];
        if (!q.length) break;
        const batch = q.slice(0, 50);
        const r = await bg({ type: "avh-report", url: REPORT_URL, events: batch }, 25000);
        if (!r || !r.ok) { if (!repWarned) { log("⚠ " + T("repFail", (r && r.error) || "?")); repWarned = true; } break; }
        repWarned = false;
        try { $("ftSync").textContent = "✓ " + T("ftSync", new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })); $("cnSheet").classList.remove("bad"); } catch (_) {}
        const ids = new Set(batch.map((x) => x.id));
        const cur = (await lget("avhRepQ")).avhRepQ || [];
        chrome.storage.local.set({ avhRepQ: cur.filter((x) => !ids.has(x.id)) });
      }
    } finally { repBusy = false; }
  }
  setInterval(() => reportFlush(), 60000);

  // Telegram দুই ধরনের: "নিজের বট" (নিজের token + Chat ID) অথবা "এক বট" (তোমার সার্ভারের এক বট, কোড দিয়ে যুক্ত)
  // ৫.৮.১ থেকে শুধু "এক বট" — সবার জন্য একই সার্ভার, আগে থেকে বসানো
  const TG_SRV_DEFAULT = "https://avh-bot.yahiahossain24.workers.dev";
  const tgShared = () => true;
  const tgSrvUrl = () => TG_SRV_DEFAULT;
  const tgTok = () => (cfg.tgId && cfg.tgSec ? `srv:${tgSrvUrl()}|${cfg.tgId}|${cfg.tgSec}` : "");
  const tgChatId = () => cfg.tgSChat;
  const tgReady = () => !!(tgTok() && tgChatId());
  // Telegram-এ নিচের বোতামগুলো (কমান্ড টাইপ না করে চাপলেই হয়)
  const TG_BTNS = [["btnRun", "btnPause", "btnResume", "btnStop"], ["btnStatus", "btnToday", "btnMarket", "btnBal"], ["btnDz", "btnAi", "btnMaker", "btnSettings"], ["btnShot", "btnLive", "btnLog", "btnReload"], ["btnAir", "btnPts", "btnTop", "btnStats"], ["btnHelp"]];
  const BTN_CMD = { btnRun: "/run", btnPause: "/pause", btnResume: "/resume", btnStop: "/stop", btnStatus: "/status", btnShot: "/shot", btnLive: "/live", btnLog: "/log", btnReload: "/reload", btnSettings: "/settings", btnHelp: "/help",
    btnToday: "/today", btnMarket: "/price", btnBal: "/balance", btnDz: "/danger", btnMaker: "/maker", btnAi: "/ai", btnPts: "/points", btnAir: "/news", btnStats: "/stats", btnTop: "/top" };
  // Telegram-এর "/" মেনু: সব কমান্ড ছোট বিবরণসহ (ভাষা বদলালে বা নতুন ভার্সনে আবার পাঠানো)
  const TG_CMDS = ["run", "stop", "pause", "resume", "status", "today", "price", "balance", "danger", "ai", "aievery", "aipaid", "aistat", "maker", "entry", "points", "news", "top", "rank", "plan", "stats", "stopafter", "stopat",
    "settings", "preset", "amount", "target", "delay", "maxloss", "random", "report", "sellall", "shot", "live", "stoplive", "log", "reload", "reset", "menu", "help"];
  const TG_KB_VER = "620-";
  async function tgMenuSync(force) {
    const key = TG_KB_VER + cfg.lang, d = await lget("avhTgKb");
    if (!force && d.avhTgKb === key) return;
    const r = await bg({ type: "avh-tg-cmds", token: tgTok(), commands: TG_CMDS.map((c) => ({ command: c, description: T("tc_" + c) })) });
    if (!r || r.ok === false) return;
    chrome.storage.local.set({ avhTgKb: key });
    await tgSend("🔄 " + T("tgMenuNew") + "\n\n" + T("tgHelp"), tgKeyboard());
  }
  const tgKeyboard = () => ({ keyboard: TG_BTNS.map((r) => r.map((k) => ({ text: T(k) }))), resize_keyboard: true, is_persistent: true });
  function btnToCmd(text) {
    for (const k in BTN_CMD) for (const L of Object.keys(I18N)) if (I18N[L][k] && I18N[L][k] === text) return BTN_CMD[k];
    return null;
  }
  async function tgSend(text, markup) {
    const r = await bg({ type: "avh-tg-send", token: tgTok(), chat: tgChatId(), text, markup });
    if (r && r.ok === false) log(T("tgErr", r.description || "?"));
    return r;
  }

  // লস/লাভের লেখা: লস হলে "লস 0.0163 USDT", লাভ হলে "লাভ +0.0163 USDT" (total = "মোট লস/মোট লাভ")
  function plText(loss, total) {
    if (loss == null || isNaN(loss)) return "";
    const gain = loss < -1e-9;
    return T(total ? (gain ? "plTotGain" : "plTotLoss") : (gain ? "plGain" : "plLoss"), (gain ? "+" : "") + Math.abs(loss).toFixed(4));
  }
  function fmt(n, d = 4) { return n == null || isNaN(n) ? "–" : Number(n).toFixed(d); }
  function dur(ms) {
    const s = Math.max(0, Math.round(ms / 1000));
    return T("dur", Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60);
  }
  function timing() {
    if (!state.t0) return { el: "", eta: "" };
    const el = Date.now() - state.t0 - pausedMs - (paused ? Date.now() - pauseStart : 0);
    const done = state.volume - state.v0;
    const left = cfg.target - state.volume;
    const eta = state.running && !paused && done > 0 && left > 0 ? dur((el / done) * left) : "";
    return { el: dur(el), eta };
  }

  // ---------- আনুমানিক খরচ: আগের রানগুলোর গড় লস থেকে ----------
  function per1000Hist() { return cfg.histVol >= 50 ? (cfg.histLoss / cfg.histVol) * 1000 : null; }
  function estCost(vol) { const p = per1000Hist(); return p == null ? null : (p * Math.max(0, vol)) / 1000; }
  function estLine(fromVol) {
    const left = cfg.target - fromVol;
    if (left <= 0) return "";
    const c = estCost(left);
    return c == null ? T("estNone") : T("estLine", left.toFixed(0), c.toFixed(2), per1000Hist().toFixed(3));
  }


  // ================= Alpha পয়েন্ট-ধাপ =================
  // দিনের (UTC — বাংলাদেশ ভোর ৬টা থেকে) Buy ভলিউম দ্বিগুণ হলে ১ পয়েন্ট বেশি: $2=1, $4=2 … $8,192=13, $16,384=14।
  // Sell পয়েন্টে গোনা হয় না; BSC টোকেনে Buy ×2 (সেটিংসে "গুণ")। ১% নিরাপত্তা রেখে হিসাব।
  const PT_SAFE = 0.99;
  const utcDay = () => new Date().toISOString().slice(0, 10);
  const fmtK = (n) => Math.round(n).toLocaleString("en-US");
  let ptDay = { d: "", buy: 0 }, ptPlan = null;
  function ptBuy() { return ptDay.d === utcDay() ? ptDay.buy : 0; }
  function ptAdd(v) {
    const d = utcDay();
    if (ptDay.d !== d) ptDay = { d, buy: 0 };
    ptDay.buy += +v || 0;
    try { chrome.storage.local.set({ avhPt: ptDay }); } catch (_) {}
  }
  const ptOf = (eff) => (eff >= 2 ? Math.floor(Math.log2(eff) + 1e-9) : 0);
  function ptInfo() {
    const m = [1, 2, 4].includes(+cfg.ptMult) ? +cfg.ptMult : 1;
    const buy = ptBuy(), pts = ptOf(buy * m * PT_SAFE);
    const needBuy = Math.max(0, Math.pow(2, pts + 1) / (m * PT_SAFE) - buy);
    return { m, buy, pts, next: pts + 1, needBuy, needVol: needBuy * 2 };
  }
  // এই রান কোথায় থামবে: টার্গেটের ভেতরে যে সর্বোচ্চ পূর্ণ ধাপে পৌঁছানো যায় ঠিক সেখানে — তার পরের ভলিউমে পয়েন্ট নেই, শুধু খরচ
  function makePtPlan() {
    if (!cfg.ptOn) return (ptPlan = null);
    const i = ptInfo(), left = Math.max(0, cfg.target - state.volume) / 2;
    const top = ptOf((i.buy + left) * i.m * PT_SAFE);
    const stopBuy = Math.pow(2, top) / (i.m * PT_SAFE);
    ptPlan = { d: utcDay(), tgt: cfg.target, m: i.m, top, stopBuy, none: top <= i.pts, skip: Math.max(0, (i.buy + left - stopBuy) * 2) };
    return ptPlan;
  }
  // প্যানেলের তথ্য-লাইন: খরচের ধাপ, পয়েন্ট
  function infoLine() {
    return [costLine(), aiLastLine(), aiStatLine(), ptLine()].filter(Boolean).join("\n");
  }
  function ptLine() {
    if (!cfg.ptOn) return "";
    const i = ptInfo(), c = estCost(i.needVol);
    let s = T("ptLine", i.pts, fmtK(i.buy), i.m, i.next, fmtK(i.needVol), c != null ? c.toFixed(2) : "–");
    if (state.running && ptPlan && !ptPlan.none && ptPlan.d === utcDay()) s += "\n" + T("ptStopAt", ptPlan.top, fmtK(Math.max(0, (ptPlan.stopBuy - i.buy) * 2)));
    return s;
  }

  // ================= খরচ বুঝে নিজে গতি বদলানো =================
  // শেষ ৫–৮ রাউন্ডের আসল খরচ (প্রতি ১০০০ ভলিউমে) লক্ষ্যের বেশি হলে ধাপে ধাপে সাবধানী, কমলে আবার দ্রুত
  // ধাপ ১: বিরতি +৩ সে., স্প্রেড ≤ ০.১% · ধাপ ২: বিরতি +৬ সে., স্প্রেড ≤ ০.০৮%, চলতি ১ মি. ক্যান্ডেল লাল হলে Buy নয় · ধাপ ৩: ৩ মি. বিরতি
  // ধাপ ০ পুরো গতি · ১ ধীর (বিরতি +৩ সে., স্প্রেড ≤ ০.১%) · ২ সাবধানী (বিরতি +৬ সে., স্প্রেড ≤ ০.০৮%, লাল ক্যান্ডেলে Buy নয়) · ৩ বিরতি ১০ মি.
  // মাপা: শেষ ~২০০০ ভলিউমে মোট লস কতটা বাড়ল (প্যানেলের "প্রতি ১০০০" কার্ডের মতোই) — দেরিতে টাকা ফেরা হিসাব উল্টে দেয় না
  let sp = { lvl: 0, snaps: [], lvlVol: 0, per: null };
  const SP_NAME = ["spN0", "spN1", "spN2", "spN3"];
  function costEval() {
    if (!cfg.autoSpeed || state.totalLoss == null) return;
    const v = state.volume, l = state.totalLoss;
    sp.snaps.push({ v, l });
    while (sp.snaps.length > 2 && v - sp.snaps[1].v >= 2000) sp.snaps.shift();
    const a = sp.snaps[0], dv = v - a.v;
    if (dv < 1000) { sp.per = null; return; } // কমপক্ষে ১০০০ ভলিউম দেখে তবেই সিদ্ধান্ত
    const lim = cfg.autoCost, per = ((l - a.l) / dv) * 1000;
    sp.per = per;
    let tgt = per > lim * 4 ? 3 : per > lim * 2 ? 2 : per > lim ? 1 : per < lim * 0.6 ? 0 : sp.lvl;
    if (sp.lvl === 2 && tgt === 2 && v - sp.lvlVol >= 2000) tgt = 3; // সাবধানী হয়েও কমছে না
    if (tgt === sp.lvl || (tgt < sp.lvl && v - sp.lvlVol < 500)) return; // নামতে কমপক্ষে ৫০০ ভলিউম
    const up = tgt > sp.lvl;
    sp.lvl = tgt; sp.lvlVol = v;
    const msg = T(up ? "spSlow" : "spFast", T(SP_NAME[tgt]), per.toFixed(3), lim);
    log((up ? "🐢 " : "🐇 ") + msg);
    if (tgReady() && (up || tgt === 0)) tgSend((up ? "🐢 " : "🐇 ") + msg);
  }
  function costLine() {
    if (!cfg.autoSpeed || !state.running) return "";
    return T("costLine", sp.per != null ? sp.per.toFixed(3) : T("costMeasuring"), cfg.autoCost, T(SP_NAME[sp.lvl] || "spN0"));
  }
  const spDelay = () => (cfg.autoSpeed ? [0, 3, 6, 6][sp.lvl] || 0 : 0);
  function spreadLimit() {
    const l = cfg.autoSpeed ? [null, 0.1, 0.08, 0.08][sp.lvl] : null;
    if (cfg.spreadOn) return l != null ? Math.min(cfg.maxSpread, l) : cfg.maxSpread;
    return l;
  }
  async function speedGate() {
    if (!cfg.autoSpeed || sp.lvl < 2) return false;
    if (sp.lvl >= 3) {
      log("⏸ " + T("spPause"));
      setStatus("wait", T("stSpPause"));
      const until = Date.now() + 600000;
      while (!stopFlag && Date.now() < until) { wd(); await sleep(1000); }
      sp.lvl = 2; sp.lvlVol = state.volume; sp.snaps = []; // বিরতির পর সাবধানী ধাপে, খরচ নতুন করে মাপা
      return true;
    }
    // ধাপ ২: চলতি ১ মিনিটের ক্যান্ডেল লাল থাকলে Buy নয় (সর্বোচ্চ ২ মিনিট অপেক্ষা, তারপর আবার দেখা)
    const k = await klines1m(30);
    const c = k && k[k.length - 1];
    if (!c || Date.now() - c.t > 70000 || !(c.c < c.o)) return false;
    log("🟥 " + T("spRed"));
    setStatus("wait", T("stSpRed"));
    for (let i = 0; i < 12 && !stopFlag; i++) { wd(); await sleep(5000); const k2 = await klines1m(30); const c2 = k2 && k2[k2.length - 1]; if (c2 && !(c2.c < c2.o)) break; }
    return true;
  }

  // ================= liveBuf নিজে ঠিক করা =================
  // অর্ডার সময়ে পূরণ না হলে ছাড় একটু বাড়ে (+০.০২%), পরপর ৬ বার দ্রুত পূরণ হলে একটু কমে (−০.০১%) — সীমা ০.০৩–০.২৫%
  let abuf = null, bufFast = 0, bufLogAt = 0;
  const bufNow = () => (cfg.autoBuf ? (abuf != null ? abuf : cfg.bufAuto > 0 ? cfg.bufAuto : cfg.liveBuf) : cfg.liveBuf);
  function bufFill(ok, ms) {
    if (!cfg.autoBuf || !isLive()) return;
    const b = +bufNow() || 0;
    let nb = b;
    if (!ok) { nb = Math.min(0.25, Math.max(b, 0.03) + 0.02); bufFast = 0; }
    else if (ms < 2500) { if (++bufFast >= 6) { nb = Math.max(0.03, b - 0.01); bufFast = 0; } }
    else bufFast = 0;
    nb = +nb.toFixed(3);
    if (nb === b) return;
    abuf = nb; cfg.bufAuto = nb; save(false);
    if (!ok || Date.now() - bufLogAt > 300000) { log("🎚 " + T("bufAdj", b, nb, T(ok ? "bufWhyFast" : "bufWhySlow"))); bufLogAt = Date.now(); }
  }

  // ================= আটকে গেলে নিজে সারানো =================
  let loopBeat = Date.now(), healing = false;
  const wd = () => { loopBeat = Date.now(); };
  // লগআউট হলে Binance পেজের ওপরে/ফর্মে "Log In" বাটন দেখায় — দৃশ্যমান এমন বাটন/লিংক থাকলে লগআউট
  const LOGIN_RE = /^(log\s*in|login|sign\s*in|লগ\s*ইন|লগইন)$/i;
  function loggedOut() {
    try {
      for (const el of document.querySelectorAll("button, a, [role=button]")) {
        if (host.contains(el) || el.offsetParent === null) continue;
        const t = (el.innerText || el.textContent || "").trim();
        if (t.length < 12 && LOGIN_RE.test(t)) return true;
      }
    } catch (_) {}
    return false;
  }
  const lset = (o) => new Promise((r) => { try { chrome.storage.local.set(o, () => r()); } catch (_) { r(); } });
  async function heal(why) {
    if (healing || !cfg.healOn || unloading) return false;
    healing = true;
    try {
      if (loggedOut()) {
        log("🔒 " + T("healLogout"));
        notify("Alpha Volume Helper", T("healLogout"), { error: true });
        if (tgReady()) tgSend("🔒 " + T("healLogout"));
        return false;
      }
      const h = ((await lget("avhHeal")).avhHeal || []).filter((t) => Date.now() - t < 3600000);
      if (h.length >= 3) {
        log("⛔ " + T("healMax"));
        notify("Alpha Volume Helper", T("healMax"), { error: true });
        if (tgReady()) tgSend("⛔ " + T("healMax") + "\n" + why);
        return false;
      }
      if (!navigator.onLine) {
        log("📡 " + T("healOffline"));
        setStatus("wait", T("healOffline"));
        while (!navigator.onLine) await sleep(5000);
        log("📶 " + T("netBack"));
        await sleep(5000);
      }
      h.push(Date.now());
      // রিলোডের পর যেখান থেকে থেমেছিল সেখান থেকে চালানোর জন্য অবস্থা "চলমান" হিসেবে রাখো
      if (state.running) saveRun(true);
      else if (progSnap && !progSnap.done && progSnap.volume > 0) { progSnap = { ...progSnap, active: true, ts: Date.now() }; await lset({ avhRun: progSnap }); }
      await lset({ avhHeal: h, avhReloadAt: Date.now(), avhHealWhy: String(why).slice(0, 200) });
      log("🔄 " + T("healLog", why));
      if (tgReady()) { try { await tgSend("🔄 " + T("healTg", why)); } catch (_) {} }
      unloading = true; releaseLock();
      try { if (runLockRelease) { runLockRelease(); runLockRelease = null; } } catch (_) {}
      try { chrome.runtime.sendMessage({ type: "avh-wd", on: false }); } catch (_) {}
      await sleep(600);
      location.reload();
      return true;
    } finally { healing = false; }
  }
  // ৮ মিনিট মূল লুপে কোনো অগ্রগতি না হলে (বিরতি/বিপদ-অপেক্ষা বাদে) নিজে রিলোড
  setInterval(() => {
    if (!state.running || paused || healing || !cfg.healOn || !navigator.onLine) { if (!state.running || paused) wd(); return; }
    if (Date.now() - loopBeat > 8 * 60000) heal(T("healStuck", 8));
  }, 30000);
  window.addEventListener("offline", () => { if (state.running) log("📡 " + T("healOffline")); });
  window.addEventListener("online", () => { if (state.running) log("📶 " + T("netBack")); });

  // প্রগ্রেস বার: বাঁয়ে ভলিউম, মাঝে ভরাট, ডানে শতাংশ
  function setBar(vol, pct) {
    $("ringArc").style.strokeDashoffset = String(238.8 * (1 - Math.min(100, Math.max(0, pct)) / 100));
    $("hvVol").textContent = (+vol).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    $("hvTgt").textContent = "/ " + (+cfg.target).toLocaleString("en-US") + " USDT";
    $("barp").textContent = `${Math.floor(pct)}%`;
    $("panel").classList.toggle("running", !!state.running);
    // উপরের ছোট তথ্য: টোকেন, দামের মোড, Sheet/Telegram সংযোগ, ভার্সন
    try {
      hsubSet();
      const g = $("pmTag");
      g.textContent = cfg.dzOn ? "🛡 " + T("pmTagDz") : "⚠ " + T("pmTagOff");
      const at = $("aiTag");
      at.hidden = !(cfg.dzOn && aiK());
      at.textContent = "🤖 AI " + T(cfg.aiOn ? "aiTagOn" : "aiTagOff");
      at.className = "tag " + (cfg.aiOn ? "on" : "off");
      at.title = T("aiTagTip");
      g.className = "tag " + (cfg.dzOn ? "on" : "off");
      g.title = T("pmTagTip");
      $("cnTg").hidden = !(tgReady());
      $("cnSheet").classList.toggle("bad", !!repWarned);
      if (!$("ftVer").textContent) $("ftVer").textContent = "v" + chrome.runtime.getManifest().version;
    } catch (_) {}
  }
  // মোট লাভ/লসের ছোট গ্রাফ (শেষ ২০টা মান)
  let plHist = [], plLast = null;
  function drawSpark(loss) {
    if (loss == null || loss === plLast) return;
    if (plLast != null) { const k = $("ccLoss"); k.classList.add("fl"); setTimeout(() => k.classList.remove("fl"), 700); }
    plLast = loss; plHist = plHist.concat([-loss]).slice(-20);
    const sv = $("plSpark");
    if (plHist.length < 2) { sv.innerHTML = ""; return; }
    const lo = Math.min(...plHist), hi = Math.max(...plHist), sp = hi - lo || 1;
    const d = plHist.map((v, i) => (i ? "L" : "M") + ((i * 44) / (plHist.length - 1)).toFixed(1) + "," + (14 - ((v - lo) / sp) * 12).toFixed(1)).join("");
    sv.innerHTML = `<path d="${d}" fill="none" stroke="${loss < 0 ? "#0ecb81" : "#f6465d"}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>`;
  }
  // হিসাবের ৬টা কার্ড; লস বেশি হলে লাল, কম/লাভ হলে সবুজ
  function setCards(tr, el, eta, loss, per, bal) {
    $("cvTr").textContent = tr || 0;
    $("cvEl").textContent = el || "–";
    $("cvEta").textContent = eta ? "~" + eta : "–";
    // লাভ হলে (লস ঋণাত্মক) "মোট লাভ" লেখা আর সবুজ; লস হলে "মোট লস" লাল
    const gain = loss != null && loss < -1e-9;
    $("clLoss").textContent = T(loss == null || Math.abs(loss) < 1e-9 ? "cLossZ" : gain ? "cGain" : "cLoss");
    $("cvLoss").textContent = loss != null ? (gain ? "+" : "") + fmt(Math.abs(loss)) : "–";
    const pgain = per != null && per < -1e-9;
    $("clPer").textContent = T(pgain ? "cPerGain" : "cPer");
    $("cvPer").textContent = per != null ? (pgain ? "+" : "") + Math.abs(+per).toFixed(3) : "–";
    $("cvBal").textContent = bal != null ? (+bal).toFixed(2) : "–"; // আগের ডিজাইন: শুরুর ব্যালেন্স
    $("ccLoss").className = "cd" + (loss == null || Math.abs(loss) < 1e-9 ? "" : loss > 0 ? " red" : " grn");
    $("ccPer").className = "cd" + (per == null ? "" : per > 0.5 ? " red" : per > 0.2 ? " yel" : " grn");
    $("ccLoss").title = $("ccPer").title = gain ? T("gainTip") : "";
    drawSpark(loss);
  }
  function renderProgress() {
    try { $("ptRow").textContent = infoLine(); } catch (_) {}
    const pct = cfg.target > 0 ? Math.min(100, (state.volume / cfg.target) * 100) : 0;
    const tm = timing();
    if (!state.running && canContinue()) {
      const pv = progSnap.volume, pp = Math.min(100, (pv / cfg.target) * 100);
      $("prog").textContent = T("progSaved2") + (estLine(pv) ? "\n" + estLine(pv) : "");
      setBar(pv, pp);
      setCards(progSnap.trades, "", "", progSnap.totalLoss, pv > 0 && progSnap.totalLoss != null ? (progSnap.totalLoss / pv) * 1000 : null, progSnap.startBal, progSnap.lastBal);
      $("miniProg").textContent = T("miniSaved", pv.toFixed(0), cfg.target);
      $("tgBadge").hidden = !(tgReady());
      return;
    }
    const per = state.volume > 0 && state.totalLoss != null ? (state.totalLoss / state.volume) * 1000 : null;
    setCards(state.trades, tm.el, tm.eta, state.totalLoss, per, state.startBal, state.lastBal);
    let txt = paused ? T("pausedNow") : "";
    if (!state.running && state.volume === 0) txt = estLine(0);
    $("prog").textContent = txt;
    setBar(state.volume, pct);
    $("miniProg").textContent = (paused ? T("miniPause") : state.running ? T("miniRun") : "") + `${state.volume.toFixed(0)} / ${cfg.target} (${pct.toFixed(0)}%)` +
      (tm.eta ? ` · ${tm.eta}` : "") + (state.totalLoss != null ? "\n" + plText(state.totalLoss) : "");
    $("tgBadge").hidden = !(tgReady());
  }
  setInterval(() => { if (state.running) renderProgress(); }, 1000); // "চলছে" আর "বাকি" প্রতি সেকেন্ডে

  function renderSelectors() {
    const box = $("sels");
    box.innerHTML = "";
    for (const k of KEYS) {
      const has = !!cfg.selectors[k];
      const row = document.createElement("div");
      row.className = "sel";
      const mark = has ? '<b class="ok">✓</b>' : OPTIONAL.has(k) ? '<b class="opt">–</b>' : '<b class="no">✗</b>';
      row.innerHTML = `${mark}<span></span>`;
      row.querySelector("span").textContent = LBL(k);
      const pickBtn = document.createElement("button");
      pickBtn.textContent = pickingKey === k ? T("picking") : T("pick");
      pickBtn.onclick = () => startPick(k);
      row.appendChild(pickBtn);
      if (has) {
        const test = document.createElement("button");
        test.textContent = T("show");
        test.onclick = () => flash(find(k), k);
        row.appendChild(test);
      }
      box.appendChild(row);
    }
  }

  let forceLive = false; // প্রফিট মোড + "লাইভ সেল": শুধু Sell-এর সময় লাইভ মার্কেট মোডের নিয়ম
  const isLive = () => forceLive || cfg.priceMode === "live";
  function renderInputs() {
    $("priceMode").value = cfg.priceMode === "live" ? "live" : "suggest";
    $("heldMode").value = cfg.heldMode === "keep" ? "keep" : "sell";
    $("liveWait").disabled = $("liveBuf").disabled = cfg.priceMode !== "live";
    for (const f of fields) $(f).value = cfg[f];
    for (const c of checks) $(c).checked = !!cfg[c];
    $("lang").value = cfg.lang;
    $("stopAt").value = /^\d{2}:\d{2}$/.test(cfg.stopAt || "") ? cfg.stopAt : "";
    $("aiProv").value = aiP();
    $("aiKey").value = aiK();
    $("aiKey").placeholder = { groq: "gsk_…", openrouter: "sk-or-…" }[aiP()];
    $("aiModel").placeholder = aiP() === "openrouter" ? T("orAuto") : "";
    $("orPaid").disabled = !cfg.dzOn || aiP() !== "openrouter" || cfg.orMode === "paid";
    $("orMode").value = cfg.orMode; $("orMode").disabled = !cfg.dzOn || aiP() !== "openrouter";
    $("aiEvery").value = String([15, 30, 60, 90, 120].includes(+cfg.aiEvery) ? +cfg.aiEvery : 30); $("aiEvery").disabled = !cfg.dzOn;
    $("aiModel").value = aiP() === "openrouter" ? cfg.aiModelOr || "" : aiM();
    $("aiModels").innerHTML = aiList().map((m) => `<option value="${m}">`).join("");
    $("aiProv").disabled = $("aiKey").disabled = $("aiModel").disabled = $("aiConf").disabled = $("aiWant").disabled = !cfg.dzOn;
    $("obOn").disabled = !cfg.dzOn; $("makerAuto").disabled = !cfg.makerSell;
    $("entryMode").value = cfg.entryMode;
    $("maxLoss").disabled = !cfg.lossOn;
    $("ptMult").value = String([1, 2, 4].includes(+cfg.ptMult) ? +cfg.ptMult : 1);
    $("ptMult").disabled = !cfg.ptOn;
    $("autoCost").disabled = !cfg.autoSpeed;
    $("makerWait").disabled = !cfg.makerSell;
    $("maxSpread").disabled = !cfg.spreadOn;
    $("minDepth").disabled = !cfg.depthOn;
    $("retryMax").disabled = $("retryWait").disabled = !cfg.retryOn;
    $("spreadWait").disabled = !cfg.spreadOn && !cfg.depthOn;
    renderProgress();
  }

  for (const f of fields) {
    $(f).addEventListener("change", () => {
      const v = clampVal(f, parseFloat($(f).value));
      if (v != null && !isNaN(v)) cfg[f] = v;
      if (f === "liveBuf") { cfg.bufAuto = 0; abuf = null; } // নিজে বদলালে স্বয়ংক্রিয় ছাড় আবার এখান থেকে শুরু
      $(f).value = cfg[f]; // সীমার বাইরে দিলে ঠিক করা মানটা দেখাও
      save();
      renderProgress();
    });
  }
  for (const c of checks) {
    $(c).addEventListener("change", () => {
      cfg[c] = $(c).checked;
      if (c === "dzOn" || c === "aiWant") aiSync();
      if (c === "aiWant") log("🤖 " + T("aiWantLog", cfg.aiOn));
      if (c === "airOn") { if (cfg.airOn) airCheck(true); else airRender(); }
      if (c === "airTg" && cfg.tgSChat && cfg.tgId) srv("/api/newspref", { on: !!cfg.airTg }); // Telegram-এ খবর এখন সার্ভার পাঠায়
      save();
      renderInputs();
    });
  }
  $("aiKey").addEventListener("change", () => { cfg[AI_KEYF[aiP()]] = $("aiKey").value.trim(); aiSync(); save(); renderProgress(); });
  $("aiProv").addEventListener("change", () => { cfg.aiProv = ["openrouter", "groq"].includes($("aiProv").value) ? $("aiProv").value : "openrouter"; aiSync(); save(); renderInputs(); if (aiP() === "openrouter") orLoad(true); });
  $("aiModel").addEventListener("change", () => {
    const v = $("aiModel").value.trim();
    if (aiP() === "openrouter") { cfg.aiModelOr = v; save(); return; } // ফাঁকা = ফ্রি মডেল নিজে বাছাই
    setAiM(v || aiList()[0]); $("aiModel").value = aiM(); save();
  });
  $("airCheck").addEventListener("click", async () => { $("airSt").textContent = T("airChecking"); await airCheck(true); });
  $("pCheck").addEventListener("click", async () => {
    const s = await profitSignal();
    if (!s || !s.closes) return log("⚠ " + T("pNoData"));
    const why = dzRule(s);
    log((why.length ? "⚠ " : "✅ ") + T("mkCheck", s.score, why.length ? why.join(" · ") : T("dzSafe"), s.why));
    if (cfg.aiOn && aiK()) { await dzAi(s, true); log("🤖 " + (dz.ai ? T("aiDz", dz.ai.danger ? T("aiDzYes") : T("aiDzNo"), dz.ai.conf, dz.ai.reason) : T("aiFail", aiLastErr))); }
  });
  $("aiTest").addEventListener("click", async () => {
    if (!aiK()) return log("⚠ " + T("aiNoKey"));
    log("🤖 " + T("aiTesting"));
    const r = await aiCall('Reply with JSON {"ok":true}');
    log(r && r.ok ? "✅ " + T("aiOk", AI_NAME[aiP()] + " · " + (r.model || aiM())) + (r.ms ? ` · ${(r.ms / 1000).toFixed(1)} সে.` : "") : "❌ " + T("aiFail", (r && r.error) || "timeout"));
  });
  // ---------- নাম (বাধ্যতামূলক, প্যানেলে) ----------
  // উপরের ছোট লাইন: Telegram username · টোকেন (যুক্ত না থাকলে শুধু টোকেন)
  function hsubSet() { try { $("hsub").textContent = (uName() ? uName() + " · " : "") + tokenName(); } catch (_) {} }
  function renderWho() {
    const has = !!uName(), n = uName().replace(/^@/, "");
    $("whoName").textContent = has ? "" : T("whoTgNone"); $("whoName").hidden = has;
    $("who").classList.toggle("solo", has); hsubSet();
    $("whoAv").textContent = has ? [...n][0].toUpperCase() : "✈";
    $("who").classList.toggle("none", !has);
    $("who").title = has ? T("whoTgTip") : T("whoTgNoneTip");
  }
  $("who").onclick = () => tgOpenBot(); // যুক্ত না থাকলে এক চাপে যুক্ত করার লিংক, থাকলে বট খোলে
  $("updGo").onclick = () => { if (verInfo && /^https:\/\//.test(verInfo.url)) window.open(verInfo.url, "_blank", "noopener"); };
  $("lang").addEventListener("change", () => { cfg.lang = $("lang").value; save(); applyI18n(); if (tgReady()) tgMenuSync(false); });
  $("entryMode").addEventListener("change", () => { cfg.entryMode = $("entryMode").value; clampCfg(); bullCache = null; bullLog = ""; save(); renderInputs(); log("✅ " + T("emSet", T(EM_LBL[cfg.entryMode]))); });
  // ব্যাজ চাপলে বিপদে থামো এক চাপে চালু/বন্ধ
  $("pmTag").addEventListener("click", () => {
    cfg.dzOn = !cfg.dzOn; aiSync(); save(); renderInputs();
    log((cfg.dzOn ? "🛡 " : "⚠ ") + T(cfg.dzOn ? "guardOnLog" : "guardOffLog", cfg.aiOn ? " + AI" : ""));
  });
  $("orMode").addEventListener("change", () => { cfg.orMode = $("orMode").value === "paid" ? "paid" : "free"; save(); renderInputs(); try { $("aiModels").innerHTML = aiList().map((m) => `<option value="${m}">`).join(""); } catch (_) {} log("🤖 " + T("orModeSet", T(cfg.orMode === "paid" ? "orModePaid" : "orModeFree"))); });
  $("aiEvery").addEventListener("change", () => { cfg.aiEvery = clampVal("aiEvery", +$("aiEvery").value) || 30; save(); log("🤖 " + T("aiEverySet", cfg.aiEvery)); });
  // AI আলাদা সুইচ: বিপদে থামার নিয়ম চালু থাকে, শুধু AI বন্ধ/চালু
  $("aiTag").addEventListener("click", () => {
    if (!aiK()) return log("⚠ " + T("aiNoKey"));
    cfg.aiWant = !cfg.aiOn; if (cfg.aiWant) cfg.dzOn = true; aiSync(); save(); renderInputs();
    log("🤖 " + T("aiWantLog", cfg.aiOn));
  });
  $("ptMult").addEventListener("change", () => { cfg.ptMult = +$("ptMult").value || 1; ptPlan = null; save(); renderProgress(); });
  $("heldMode").addEventListener("change", () => { cfg.heldMode = $("heldMode").value; save(); });
  $("priceMode").addEventListener("change", () => {
    if (state.running) { $("priceMode").value = cfg.priceMode; return log(T("cfgRunning")); }
    cfg.priceMode = $("priceMode").value; save(); renderInputs();
    log(isLive() ? T("pmLiveLog") : T("pmSuggestLog"));
  });

  $("testNotify").onclick = () => {
    if (!cfg.notifyOn) return log(T("notifyOff"));
    bg({ type: "avh-notify", title: "Alpha Volume Helper", message: T("notifyTest") });
    log(T("notifySent"));
  };
  $("testSound").onclick = () => {
    bg({ type: "avh-beep", kind: "done" });
    setTimeout(() => bg({ type: "avh-beep", kind: "error" }), 1800);
    log(T("soundSent"));
  };

  // ---------- এক বট: সার্ভারের সাথে যুক্ত করা ----------
  let tgLinking = false;
  const rnd = (n) => { const A = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"; return [...crypto.getRandomValues(new Uint8Array(n))].map((x) => A[x % A.length]).join(""); };
  const srv = (path, body = {}) => bg({ type: "avh-srv", url: tgSrvUrl() + path, body: Object.assign({ id: cfg.tgId, sec: cfg.tgSec }, body) }, 30000);
  async function tgSrvCheck() {
    if (!tgShared() || !tgSrvUrl() || !cfg.tgId) return;
    const r = await srv("/api/status", { rname: uName(), ver: MY_VER, lb: cfg.lbShow !== false });
    if (!r || r.ok !== true) return;
    if (r.bot && r.bot !== cfg.tgBot) { cfg.tgBot = r.bot; save(false); }
    if (cfg.selAuto !== false && r.selVer > (cfg.selVer || 0)) selPull(false);
    srvUpd = !!r.updSrv; srvNews = !!r.newsSrv;
    if (typeof r.newsOn === "boolean" && r.newsOn !== !!cfg.airTg) { cfg.airTg = r.newsOn; save(false); renderInputs(); } // বটে /news on|off দিলে এখানেও
    const chat = r.linked && r.chat ? String(r.chat) : "";
    if (chat !== (cfg.tgSChat || "") || (chat && r.name && r.name !== cfg.tgSName)) { cfg.tgSChat = chat; cfg.tgSName = r.name || ""; if (!chat) log("⏹ " + T("tgUnlinked")); save(); renderInputs(); renderProgress(); renderWho(); nameSync(); }
    if (chat && cfg.srvCfgChat !== chat) cfgSrvPull(chat);
  }
  // ---------- ☁ সেটিংস সার্ভারে (Telegram ধরে): নতুন কম্পিউটারে যুক্ত করলেই আগের সেটিংস ফেরত ----------
  // API key, Telegram-এর গোপন তথ্য আর পেজের বাটন যায় না (NO_SYNC)
  const CFG_SRV_SKIP = ["srvCfgChat", "repNameSent", "tgBot"];
  let cfgSrvTimer = null, cfgSrvBusy = false, srvUpd = false, srvNews = false;
  function cfgSrvData() { const d = {}; for (const k of Object.keys(cfg)) if (!NO_SYNC.includes(k) && !CFG_SRV_SKIP.includes(k)) d[k] = cfg[k]; return d; }
  function cfgSrvSched() {
    if (!cfg.tgSChat || !cfg.tgId || cfg.srvCfgChat !== cfg.tgSChat) return; // প্রথমবার আগে সার্ভারেরটা দেখে নেওয়া
    clearTimeout(cfgSrvTimer);
    cfgSrvTimer = setTimeout(() => { srv("/api/cfgpush", { cfg: cfgSrvData(), ts: cfg.updatedAt || Date.now() }); }, 60000);
  }
  async function cfgSrvPull(chat) {
    if (cfgSrvBusy || !chat || cfg.srvCfgChat === chat) return;
    cfgSrvBusy = true;
    try {
      const r = await srv("/api/cfgget");
      if (!r || r.ok !== true) return; // পরে আবার চেষ্টা
      if (r.cfg && typeof r.cfg === "object") {
        if (state.running) return; // চলার সময় সেটিং বদলানো নয় — থামার পর পরের বার
        const keep = {}; for (const k of NO_SYNC.concat(CFG_SRV_SKIP)) keep[k] = cfg[k];
        cfg = { ...cfg, ...r.cfg, ...keep }; clampCfg();
        cfg.srvCfgChat = chat; save(false); renderInputs(); applyI18n(); renderProgress();
        log("☁ " + T("cfgSrvGot", new Date(r.ts || Date.now()).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })));
      } else {
        cfg.srvCfgChat = chat; save(false);
        const p = await srv("/api/cfgpush", { cfg: cfgSrvData(), ts: cfg.updatedAt || Date.now() });
        if (p && p.ok) log("☁ " + T("cfgSrvSaved"));
      }
    } finally { cfgSrvBusy = false; }
  }
  // Sheet-এর নাম বদলালে (প্রথম যুক্ত বা অন্য Telegram) একটা join/rename সারি
  function nameSync() {
    const n = uName();
    if (!n || n === cfg.repNameSent) return;
    const first = !cfg.repNameSent, old = cfg.repNameSent;
    cfg.repNameSent = n; save(false);
    reportPush({ type: first ? "join" : "rename", vol: 0, trades: 0 });
    if (!first) log("👤 " + T("whoRenamed", old, n));
  }
  $("stopAt").addEventListener("change", () => { cfg.stopAt = /^\d{2}:\d{2}$/.test($("stopAt").value) ? $("stopAt").value : ""; save(); if (state.running) state.stopAtTs = stopAtTs(); log("⏰ " + (cfg.stopAt ? T("stopAtSet", cfg.stopAt) : T("stopAtOff"))); });
  let tgLinkRaw = "";
  // বট খোলা: কোড থাকলে t.me/বট?start=link_কোড — Telegram-এ "Start" চাপলেই যুক্ত, কিছু লিখতে হয় না
  async function tgOpenBot() {
    // বটের নাম না জানলে সার্ভার থেকে আনা; যুক্ত না থাকলে সাথে নতুন কোড — t.me লিংকে "Start" চাপলেই যুক্ত
    if (!cfg.tgId || !cfg.tgSec) { cfg.tgId = rnd(20); cfg.tgSec = rnd(40); save(false); }
    if (!cfg.tgBot) await tgSrvCheck();
    if ((!cfg.tgBot || (!cfg.tgSChat && !tgLinkRaw)) && tgSrvUrl()) {
      const r = await srv("/api/code");
      if (r && r.ok && r.code) { tgLinkRaw = r.code; if (r.bot) { cfg.tgBot = r.bot; save(false); } if (!cfg.tgSChat && !tgLinking) tgWaitLink(); }
    }
    if (!cfg.tgBot) return log("⚠ " + T("tgOpenNeed"));
    const url = `https://t.me/${cfg.tgBot}` + (tgLinkRaw && !cfg.tgSChat ? `?start=link_${tgLinkRaw}` : "");
    // নতুন ট্যাব খোলে Chrome নিজে (background) — পপআপ-ব্লকে আটকায় না
    const r = await bg({ type: "avh-open", url }, 5000);
    if (!r || !r.ok) { try { window.open(url, "_blank"); } catch (_) {} }
    log("📱 " + T("tgOpened", "@" + cfg.tgBot));
  }
  async function tgWaitLink() {
    tgLinking = true;
    const until = Date.now() + 10 * 60000;
    try {
      while (Date.now() < until && tgShared()) {
        await sleep(3000);
        const s = await srv("/api/status");
        if (s && s.ok && s.linked && s.chat) {
          cfg.tgSChat = String(s.chat); cfg.tgSName = s.name || ""; save();
          log(T("tgLinked", cfg.tgSName || cfg.tgSChat));
          nameSync(); renderWho(); cfgSrvPull(cfg.tgSChat); setTimeout(() => checkUpdate(), 3000); // যুক্ত হওয়ার আগে নতুন ভার্সন এসে থাকলে এখনই Telegram-এ
          tgLinking = false; tgLinkRaw = ""; renderInputs(); renderProgress();
          return;
        }
      }
      log("⌛ " + T("tgLinkExpired"));
    } finally { tgLinking = false; renderInputs(); }
  }
  $("cnTg").addEventListener("click", () => tgOpenBot());
  // ১০) বড় খবর (এরর/লগআউটে থামা) বটের মালিককে (admin) — সেটিংসে বন্ধ করা যায়
  function evSend(text) { if (cfg.evOn && cfg.tgSChat && cfg.tgId) srv("/api/event", { rname: uName(), text: String(text).slice(0, 400) }); }

  $("close").onclick = () => setVisible(false);
  function toggleMin() {
    const m = !$("panel").classList.contains("min");
    $("panel").classList.toggle("min", m);
    $("min").textContent = m ? "+" : "–";
    chrome.storage.local.set({ avhMin: m });
    keepInView();
  }
  $("min").onclick = toggleMin;

  // পেজ থেকে ফাইল নামানো
  function downloadFile(name, text, type) {
    const url = URL.createObjectURL(new Blob([text], { type }));
    const a = document.createElement("a");
    a.href = url; a.download = name;
    document.documentElement.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }
  const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };

  $("exportCfg").onclick = () => {
    const data = { app: "alpha-volume-helper", version: 3, savedAt: new Date().toISOString(), cfg: { ...cfg, tgId: "", tgSec: "", tgSChat: "", tgSName: "" },
      run: progSnap && !progSnap.done && progSnap.volume > 0 ? { ...progSnap, active: false } : null };
    downloadFile(`alpha-volume-settings-${today()}.json`, JSON.stringify(data, null, 2), "application/json");
    log(T("cfgSaved"));
  };
  $("importCfg").onclick = () => { if (state.running || otherTabRunning()) return log(T("cfgRunning")); $("importFile").click(); };
  $("importFile").addEventListener("change", async () => {
    const f = $("importFile").files[0];
    $("importFile").value = "";
    if (!f) return;
    try {
      const data = JSON.parse(await f.text());
      if (!data || data.app !== "alpha-volume-helper" || typeof data.cfg !== "object") throw new Error(T("cfgBadFile"));
      const keep = { tgId: cfg.tgId, tgSec: cfg.tgSec, tgSChat: cfg.tgSChat, tgSName: cfg.tgSName };
      cfg = { ...cfg, ...data.cfg, selectors: { ...(data.cfg.selectors || {}) }, ...keep };
      clampCfg();
      save(); renderInputs(); applyI18n();
      log(T("cfgLoaded", f.name));
      // ফাইলে চলমান ভলিউমের হিসাব থাকলে সেটাও ফেরত আনো
      if (data.run && data.run.volume > 0 && !data.run.done) {
        progSnap = { ...data.run, active: false };
        chrome.storage.local.set({ avhRun: progSnap });
        renderProgress();
        log(T("runLoaded", (+data.run.volume).toFixed(2)));
      }
    } catch (e) { log(T("cfgLoadFail", e.message)); }
  });

  $("pickAll").onclick = () => {
    if (state.running) return log(T("pickRunning"));
    pickQueue = KEYS.slice(1);
    startPick(KEYS[0]);
  };
  $("skip").onclick = () => { log(T("pickSkip", LBL(pickingKey))); nextPick(); };
  $("cancel").onclick = () => { pickQueue = []; log(T("pickCancel")); endPick(); };

  // ---------- প্যানেল টেনে সরানো ----------
  function placeAt(x, y) {
    const w = host.offsetWidth || 340;
    x = Math.max(0, Math.min(x, window.innerWidth - w));
    y = Math.max(0, Math.min(y, window.innerHeight - 40));
    Object.assign(host.style, { left: x + "px", top: y + "px", right: "auto", bottom: "auto" });
  }
  function keepInView() {
    if (host.style.left) { const r = host.getBoundingClientRect(); placeAt(r.left, r.top); }
  }
  window.addEventListener("resize", keepInView);
  $("drag").addEventListener("pointerdown", (e) => {
    if (e.target.closest("button")) return;
    e.preventDefault();
    const r = host.getBoundingClientRect();
    const dx = e.clientX - r.left, dy = e.clientY - r.top;
    const move = (ev) => placeAt(ev.clientX - dx, ev.clientY - dy);
    const up = () => {
      window.removeEventListener("pointermove", move, true);
      window.removeEventListener("pointerup", up, true);
      const p = host.getBoundingClientRect();
      chrome.storage.local.set({ avhPos: { x: p.left, y: p.top } });
    };
    window.addEventListener("pointermove", move, true);
    window.addEventListener("pointerup", up, true);
  });
  // চালুর আগে একবার সতর্কতা: বিপদে থামো বা লস-লিমিট বন্ধ থাকলে — ১৫ সে.-এর মধ্যে আবার ▶ চাপলে চালু
  let startWarnAt = 0;
  function startRisks() {
    const r = [];
    if (!cfg.dzOn) r.push(T("riskDz"));
    if (!(cfg.lossOn && cfg.maxLoss > 0)) r.push(T("riskLoss"));
    return r;
  }
  $("start").onclick = () => {
    const r = startRisks();
    if (r.length && !state.running && Date.now() - startWarnAt > 15000) {
      startWarnAt = Date.now();
      const msg = T("startWarn", r.join(", "));
      log("⚠ " + msg); setStatus("wait", msg);
      return;
    }
    startWarnAt = 0;
    run();
  };
  function requestStop() {
    if (!state.running) return false;
    stopFlag = true;
    log(T("stopReq"));
    return true;
  }
  $("stop").onclick = () => requestStop();
  function resetProgress() {
    if (state.running || otherTabRunning()) { log(T("resetRunning")); return false; }
    progSnap = null;
    chrome.storage.local.set({ avhRun: { active: false } });
    state = { ...state, volume: 0, trades: 0, startBal: null, lastBal: null, totalLoss: null, lossOffset: 0, t0: 0, v0: 0 };
    renderProgress();
    log(T("resetDone"));
    return true;
  }
  $("reset").onclick = () => resetProgress();

  // বিরতি: চলতি রাউন্ড (Buy + Sell) শেষ করে থামে, আবার চাপলে সেখান থেকে চলে
  function renderPause() {
    $("pause").textContent = paused ? T("resume") : T("pause");
    $("pause").disabled = !state.running;
    $("start").textContent = state.running ? T("runningBtn") : T("start");
    $("panel").classList.toggle("running", !!state.running);
    if (state.running && paused) setStatus("wait", T("stPaused"));
    else if (state.running && stKind === "wait" && stText === T("stPaused")) setStatus("run", T("stResumed"));
  }
  // উপরের অবস্থা লাইন: run = 🟢 চলছে, wait = 🟡 অপেক্ষা (কারণসহ), idle = ⚪ থামা, err / done
  function setStatus(kind, text) {
    stKind = kind; stText = text || "";
    const box = $("stl"); if (!box) return;
    box.className = "stl " + kind;
    $("stlA").textContent = T(kind === "run" ? "stRun" : kind === "wait" ? "stWait" : kind === "err" ? "stErr" : kind === "done" ? "stDone" : "stIdle");
    $("stlB").textContent = stText ? "· " + stText : "";
    box.title = stText;
  }
  function setPaused(v) {
    if (!state.running || v === paused) return false;
    paused = v;
    if (v) { pauseStart = Date.now(); log(T("pauseLog")); }
    else { pausedMs += Date.now() - pauseStart; log(T("resumeLog")); }
    renderPause(); renderProgress();
    return true;
  }
  $("pause").onclick = () => setPaused(!paused);
  function curPrice() {
    let v = NaN;
    if (cfg.selectors.livePrice) v = parseFloat(firstNumText(find("livePrice")));
    if (!(v > 0) && (cfg.selectors.bookAsk || cfg.selectors.bookBid)) {
      const lb = liveBook();
      if (lb && lb.ask && lb.bid) v = (parseFloat(lb.ask) + parseFloat(lb.bid)) / 2;
      else if (lb && lb.mid > 0) v = lb.mid;
    }
    if (!(v > 0) && cfg.selectors.suggestPrice) v = readNum(find("suggestPrice"));
    return v > 0 ? v : null;
  }

  // ================= বাজারের বাক্সে Binance-এর ১ মি. ও ১৫ সে. ক্যান্ডেল =================
  // বুলিশ-যাচাই যে ক্যান্ডেল দেখে, ঠিক সেগুলোই — সাথে EMA9 (হলুদ) / EMA21 (বেগুনি), চলতি দাম, আর উপরের চিপে এখনকার সিদ্ধান্ত
  let kCache = { k1: null, k15: null, at: 0 };
  async function kFetch(force) {
    if (!force && Date.now() - kCache.at < 3000 && kCache.k1) return kCache;
    const [k1, k15] = await Promise.all([klines1m(40), klines15s(30)]);
    kCache = { k1, k15, at: Date.now() };
    return kCache;
  }
  function drawK(svg, list, H, emas) {
    if (!svg) return;
    if (!list || !list.length) { svg.innerHTML = `<text x="110" y="${H / 2 + 4}" text-anchor="middle" font-size="10" fill="#5e6673">${T("kNoData")}</text>`; return; }
    const W = 220, n = list.length, slot = (W - 46) / n, pad = 4;
    let hi = Math.max(...list.map((c) => c.h)), lo = Math.min(...list.map((c) => c.l));
    for (const e of emas || []) for (const v of e.v) { if (v > hi) hi = v; if (v < lo) lo = v; }
    const span = hi - lo || hi * 0.001, y = (v) => pad + (H - 2 * pad) * (1 - (v - lo) / span);
    let out = "";
    for (let g = 1; g < 3; g++) out += `<line x1="0" x2="${W}" y1="${(g * H) / 3}" y2="${(g * H) / 3}" stroke="rgba(255,255,255,.045)"/>`;
    list.forEach((c, i) => {
      const x = i * slot + slot / 2, col = c.c > c.o ? "#0ecb81" : c.c < c.o ? "#f6465d" : "#848e9c";
      const op = i === n - 1 ? 0.75 : 1, top = y(Math.max(c.o, c.c)), bot = y(Math.min(c.o, c.c));
      out += `<line x1="${x.toFixed(1)}" x2="${x.toFixed(1)}" y1="${y(c.h).toFixed(1)}" y2="${y(c.l).toFixed(1)}" stroke="${col}" stroke-width="1" opacity="${op}"/>`;
      out += `<rect x="${(x - slot * 0.32).toFixed(1)}" y="${top.toFixed(1)}" width="${(slot * 0.64).toFixed(1)}" height="${Math.max(1.2, bot - top).toFixed(1)}" fill="${col}" opacity="${op}" rx="1"/>`;
    });
    for (const e of emas || []) out += `<polyline fill="none" stroke="${e.c}" stroke-width="1.1" opacity=".85" points="${e.v.map((v, i) => (i * slot + slot / 2).toFixed(1) + "," + y(v).toFixed(1)).join(" ")}"/>`;
    const lc = list[n - 1].c, ly = Math.min(H - 7, Math.max(7, y(lc)));
    const lt = lc >= 1 ? lc.toFixed(4) : lc.toPrecision(5).replace(/0+$/, "").replace(/\.$/, "");
    out += `<line x1="0" x2="${W - 46}" y1="${y(lc).toFixed(1)}" y2="${y(lc).toFixed(1)}" stroke="rgba(240,185,11,.5)" stroke-dasharray="3 3"/>`;
    out += `<rect x="${W - 45}" y="${(ly - 7).toFixed(1)}" width="45" height="14" rx="4" fill="#f0b90b"/><text x="${W - 22.5}" y="${(ly + 3.5).toFixed(1)}" font-size="9" font-weight="700" text-anchor="middle" fill="#1a1400" style="font-family:Inter,'Segoe UI',sans-serif">${lt}</text>`;
    svg.innerHTML = out;
  }
  function kState(r) {
    const chip = $("cstate");
    let k = "wait", t = T("kWait");
    const st = cfg.entryMode === "stable";
    if (cfg.dzOn && dz.danger && Date.now() - dz.at < 30000) { k = "off"; t = T("kDanger"); }
    else if (!r) { k = "on"; t = T("kFree"); } // যাচাই বন্ধ — বট অপেক্ষা করে না
    else if (r.ok) { k = "on"; t = T(st ? "kStable" : "kBull"); }
    else { k = "wait"; t = T(st ? "kStWait" : "kWait"); }
    chip.className = "cstate " + k; chip.textContent = t;
    chip.title = r && r.why ? r.why : dz.why || "";
  }
  async function chartLoop() {
    for (;;) {
      try {
        const vis = isLive() && !document.hidden && $("panel") && !$("panel").classList.contains("min");
        $("kbox").hidden = !isLive();
        if (vis) {
          const { k1, k15 } = await kFetch(false);
          const a = k1 ? k1.slice(-24) : null;
          let emas = [];
          if (k1 && k1.length >= 22) {
            const cl = k1.map((x) => x.c), e9 = ema(cl, 9), e21 = ema(cl, 21), off = k1.length - a.length;
            emas = [{ v: e21.slice(off), c: "#a78bfa" }, { v: e9.slice(off), c: "#fcd535" }];
            const up = e9[e9.length - 1] >= e21[e21.length - 1];
            $("k1i").className = up ? "up" : "dn";
            const rv = rsi(cl, 14);
            $("k1i").textContent = "EMA9 " + (up ? "≥" : "<") + " 21 " + (up ? "↑" : "↓") + " · RSI " + rv.toFixed(0);
            if (rv > BULL_RSI_MAX && up) $("k1i").className = "fl";
          } else { $("k1i").className = "fl"; $("k1i").textContent = ""; }
          drawK($("k1svg"), a, 62, emas);
          const b = k15 ? k15.slice(-28).map((x) => ({ o: x[0], h: x[1], l: x[2], c: x[3] })) : null;
          drawK($("k15svg"), b, 40, null);
          if (b && b.length >= 2) {
            const l2 = b.slice(-2), dot = (c) => (c.c > c.o ? "▲" : c.c < c.o ? "▼" : "•");
            const red = l2.some((c) => c.c < c.o);
            $("k15i").className = red ? "dn" : "up";
            $("k15i").textContent = T("k15Last") + " " + l2.map(dot).join(" ");
          } else { $("k15i").className = "fl"; $("k15i").textContent = ""; }
          const px = curPrice();
          $("kpx").textContent = px ? (px >= 1 ? px.toFixed(4) : String(+px.toPrecision(6))) : "";
          if (!k1) { const st = $("cstate"); st.className = "cstate wait"; st.textContent = T("kNoChip"); st.title = ""; }
          else kState(cfg.entryMode !== "off" ? await bullCheck() : null);
        }
      } catch (_) {}
      await sleep(state.running ? 4000 : 5000);
    }
  }

  // ---------- লাইভ স্প্রেড গেজ (শুধু লাইভ দাম মোডে) ----------
  async function spreadGauge() {
    for (;;) {
      try {
        const box = $("sgbox"), show = isLive();
        box.hidden = !show;
        $("mk").classList.toggle("solo", $("kbox").hidden);
        if (show) {
          const lb = liveBook();
          const a = lb && lb.ask ? parseFloat(lb.ask) : NaN, b = lb && lb.bid ? parseFloat(lb.bid) : NaN;
          const ok = a > 0 && b > 0 && a >= b;
          const sp = ok ? ((a - b) / ((a + b) / 2)) * 100 : null;
          const k = sp == null ? "n" : sp < 0.1 ? "g" : sp < 0.3 ? "y" : "r";
          $("sgVal").className = "sv " + k;
          $("sgVal").textContent = sp == null ? "–" : sp.toFixed(3) + "%";
          $("sgWord").textContent = T("sgLbl") + " · " + T(sp == null ? "sgNone" : k === "g" ? "sgGood" : k === "y" ? "sgMid" : "sgBad");
          $("sgAsk").textContent = ok ? lb.ask : "–";
          box.title = ok ? `Sell ${lb.ask} · Buy ${lb.bid}` : "";
          $("sgBid").textContent = ok ? lb.bid : "–";
          // কাঁটা: ০% বাঁয়ে, ০.৫% বা বেশি ডানে
          const f = sp == null ? 0 : Math.min(1, sp / 0.5), ang = Math.PI * (1 - f), nd = $("sgNeedle");
          nd.setAttribute("x2", (48 + 32.8 * Math.cos(ang)).toFixed(1));
          nd.setAttribute("y2", (50 - 32.8 * Math.sin(ang)).toFixed(1));
        }
      } catch (_) {}
      await sleep(1000);
    }
  }
  // ---------- Binance-এর নিজের ক্যান্ডেল (Alpha klines) — Binance চার্টের সাথে হুবহু, UTC সময়ে ----------
  const BN_API = "/bapi/defi/v1/public";
  let alphaSym = null, alphaAddr = null, alphaTried = 0;
  const pageAddr = () => { const m = location.pathname.match(/0x[0-9a-fA-F]{40}/); return m ? m[0].toLowerCase() : null; };
  async function getAlphaSymbol() {
    const addr = pageAddr();
    if (!addr) return null;
    if (alphaSym && alphaAddr === addr) return alphaSym;
    if (alphaAddr === addr && Date.now() - alphaTried < 5 * 60000) return null; // খুঁজে না পেলে ৫ মিনিট পর আবার
    alphaAddr = addr; alphaTried = Date.now(); alphaSym = null;
    const r = await fetch(BN_API + "/wallet-direct/buw/wallet/cex/alpha/all/token/list", { credentials: "include" });
    const j = await r.json();
    const list = Array.isArray(j && j.data) ? j.data : (j && j.data && Array.isArray(j.data.list) ? j.data.list : []);
    const t = list.find((x) => String((x && x.contractAddress) || "").toLowerCase() === addr);
    if (!t || t.alphaId == null || t.alphaId === "") return null;
    const id = String(t.alphaId);
    alphaSym = (/^ALPHA_/i.test(id) ? id.toUpperCase() : "ALPHA_" + id) + "USDT";
    return alphaSym;
  }
  async function waitWhilePaused() {
    while (paused && !stopFlag) { wd(); await sleep(1000); }
  }

  function setVisible(v) {
    if (v && !host.isConnected) document.documentElement.appendChild(host);
    if (!v && host.isConnected) host.remove();
    chrome.storage.local.set({ avhVisible: v });
  }

  chrome.runtime.onMessage.addListener((m) => {
    if (m && m.type === "avh-toggle") setVisible(!host.isConnected);
  });

  // কীবোর্ড শর্টকাট
  document.addEventListener("keydown", (e) => {
    if (!e.altKey || e.ctrlKey || e.metaKey || !e.isTrusted || pickingKey) return;
    const c = e.code, k = (e.key || "").toLowerCase();
    if (c === "KeyS" || k === "s") { e.preventDefault(); if (state.running) requestStop(); else run(); }
    else if (c === "KeyM" || k === "m") { e.preventDefault(); if (!host.isConnected) setVisible(true); toggleMin(); }
    else if (c === "KeyH" || k === "h") { e.preventDefault(); setVisible(!host.isConnected); }
  }, true);

  // ---------- এলিমেন্ট সিলেক্ট (পিকার) ----------
  const hl = document.createElement("div");
  hl.style.cssText = "position:fixed;pointer-events:none;border:2px solid #f0b90b;background:#f0b90b22;z-index:2147483646;border-radius:4px;display:none";
  let pickQueue = [];
  let listening = false;
  const PICK_HINT = {
    sellAvailable: "H_sellSide", sellAmountInput: "H_sellSide", orderType: "H_orderType", suggestPrice: "H_suggest", livePrice: "H_live",
    confirmButton: "H_popup", cancelConfirm: "H_popup", openOrders: "H_openOrders", cancelAll: "H_cancelAll",
    bookAsk: "H_book", bookBid: "H_book",
  };

  function startPick(key) {
    if (state.running) return log(T("pickRunning"));
    pickingKey = key;
    host.classList.add("picking");
    const step = KEYS.indexOf(key) + 1;
    const extra = PICK_HINT[key] ? T(PICK_HINT[key]) : "";
    $("hintText").textContent = pickQueue.length || step > 1 ? T("hintStep", step, KEYS.length, LBL(key), extra) : T("hintOne", LBL(key), extra);
    $("skip").style.display = pickQueue.length || OPTIONAL.has(key) ? "" : "none";
    renderSelectors();
    if (!listening) {
      listening = true;
      document.documentElement.appendChild(hl);
      ["pointerdown", "mousedown", "mouseup", "pointerup", "click"].forEach((ev) => document.addEventListener(ev, onPickEvent, true));
      document.addEventListener("mousemove", onPickMove, true);
      document.addEventListener("keydown", onPickKey, true);
    }
  }
  function nextPick() {
    if (pickQueue.length) startPick(pickQueue.shift());
    else { endPick(); log(T("pickDone")); }
  }
  function endPick() {
    listening = false;
    host.classList.remove("picking");
    pickingKey = null;
    hl.style.display = "none";
    hl.remove();
    ["pointerdown", "mousedown", "mouseup", "pointerup", "click"].forEach((ev) => document.removeEventListener(ev, onPickEvent, true));
    document.removeEventListener("mousemove", onPickMove, true);
    document.removeEventListener("keydown", onPickKey, true);
    renderSelectors();
  }

  // অর্ডারবুকের সারি: দাম ও পরিমাণ দুটো সংখ্যা আছে এমন সবচেয়ে কাছের উপরের এলিমেন্ট
  function bookRowOf(el) {
    for (let e = el, i = 0; e && i < 6; e = e.parentElement, i++) {
      if (parseNums(e.innerText).length >= 2 && e.getBoundingClientRect().width < 700) return e;
    }
    return el;
  }

  function targetOf(e) {
    const el = e.target;
    if (el === host) return null;
    const k = pickingKey;
    if (k === "amountInput" || k === "sellAmountInput" || k === "priceInput") return el.closest("input") || el.querySelector?.("input") || el;
    if (k === "balanceText" || k === "sellAvailable") return el;
    if (k === "bookAsk" || k === "bookBid") return bookRowOf(el);
    return el.closest('button,[role="button"],[role="tab"],a,label') || el;
  }
  function onPickMove(e) {
    if (!e.isTrusted) return;
    const el = targetOf(e);
    if (!el) { hl.style.display = "none"; return; }
    const r = el.getBoundingClientRect();
    Object.assign(hl.style, { display: "block", left: r.left + "px", top: r.top + "px", width: r.width + "px", height: r.height + "px" });
  }
  function onPickEvent(e) {
    if (e.target === host) return;
    if (!e.isTrusted) return; // এক্সটেনশনের নিজের ক্লিক সিলেকশন হিসেবে ধরবে না
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    if (e.type !== "click") return;
    const el = targetOf(e);
    if (!el) return;
    const key = pickingKey;
    const rr = el.getBoundingClientRect();
    cfg.selectors[key] = { css: cssPath(el), text: (el.innerText || "").trim().slice(0, 60), tag: el.tagName.toLowerCase(), x: rr.left + rr.width / 2, y: rr.top + rr.height / 2 };
    save();
    const savedText = cfg.selectors[key].text.replace(/\s+/g, " ").slice(0, 30);
    log(T("pickSaved", LBL(key), ["bookAsk", "bookBid"].includes(key) ? "" : savedText));
    const nt = norm(savedText);
    if ((key === "sellButton" || key === "sellTab") && !startsWithAny(nt, WORDS.sell)) log(T("warnNotSell"));
    if ((key === "buyButton" || key === "buyTab") && !startsWithAny(nt, WORDS.buy)) log(T("warnNotBuy"));
    if (key === "openOrders") { const n = readOpenCount(); log(n == null ? T("openNotFound") : T("openFound", n)); }
    if (key === "sellAvailable") { const n = readNum(el); log(n == null ? T("availNone") : T("availRead", n)); }
    if (key === "bookAsk" || key === "bookBid") {
      const r = readRow(el);
      log(r ? T("bookRead", r.price, r.amount, r.usdt.toFixed(2)) : T("bookNone"));
    }
    hl.style.display = "none";
    if (["buyTab", "sellTab", "orderType", "suggestPrice", "openOrders"].includes(key)) setTimeout(() => realClick(el), 50);
    if (pickQueue.length) setTimeout(nextPick, 300);
    else endPick();
  }
  function onPickKey(e) {
    if (e.key === "Escape") { pickQueue = []; log(T("pickCancel")); endPick(); }
  }

  function cssPath(el) {
    const parts = [];
    let reachedAnchor = false;
    while (el && el.nodeType === 1 && el !== document.body && el !== document.documentElement) {
      if (el.id && !/\d{4,}|:|^_/.test(el.id)) { parts.unshift("#" + CSS.escape(el.id)); reachedAnchor = true; break; }
      const tid = el.getAttribute("data-testid");
      let s = el.tagName.toLowerCase();
      if (tid) s += `[data-testid="${tid.replace(/"/g, '\\"')}"]`;
      const p = el.parentElement;
      if (p) {
        const same = [...p.children].filter((c) => c.tagName === el.tagName);
        if (same.length > 1) s += `:nth-of-type(${same.indexOf(el) + 1})`;
      }
      parts.unshift(s);
      el = p;
    }
    return (reachedAnchor ? "" : "body > ") + parts.join(" > ");
  }

  // ---------- পেজের এলিমেন্ট খোঁজা ----------
  const isVisible = (el) => !!el && el.isConnected && el.getClientRects().length > 0;
  const norm = (t) => (t || "").replace(/\s+/g, " ").trim().toLowerCase();
  const TEXT_KEYS = new Set(["buyTab", "sellTab", "orderType", "buyButton", "sellButton", "confirmButton", "cancelAll", "cancelConfirm"]);
  const PREFIX_KEYS = {
    suggestPrice: { re: /^(suggest|সাজেস্ট)/i, ok: /suggest|সাজেস্ট|\$/i },
    openOrders: { re: /^(open orders?|খোলা অর্ডার|ওপেন অর্ডার)/i, ok: /open order|খোলা অর্ডার|ওপেন অর্ডার/i },
  };
  function nearest(cands, s) {
    if (s.x == null) return cands[0];
    let best = null, bd = Infinity;
    for (const c of cands) {
      const r = c.getBoundingClientRect();
      const d = Math.hypot(r.left + r.width / 2 - s.x, r.top + r.height / 2 - s.y);
      if (d < bd) { bd = d; best = c; }
    }
    return best;
  }
  const INPUT_KEYS = new Set(["priceInput", "amountInput", "sellAmountInput"]);
  function asInput(el) {
    if (!el) return null;
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) return el;
    return (el.querySelector && el.querySelector("input,textarea")) || (el.closest && el.closest("input,textarea")) || null;
  }
  // সেভ করা পথে ইনপুট না পেলে আগের জায়গার সবচেয়ে কাছের দৃশ্যমান ইনপুট (১২০px-এর মধ্যে)
  function findInput(s) {
    let el = null;
    try { el = asInput(document.querySelector(s.css)); } catch (_) {}
    if (isVisible(el) && !el.disabled) return el;
    if (s.x == null) return null;
    const cands = [...document.querySelectorAll("input,textarea")].filter((e) => !host.contains(e) && isVisible(e) && !e.disabled &&
      !/^(checkbox|radio|hidden|range|button|submit)$/i.test(e.type || ""));
    const best = nearest(cands, s);
    if (!best) return null;
    const r = best.getBoundingClientRect();
    return Math.hypot(r.left + r.width / 2 - s.x, r.top + r.height / 2 - s.y) < 120 ? best : null;
  }
  function find(key) {
    const s = cfg.selectors[key];
    if (!s) return null;
    if (INPUT_KEYS.has(key)) {
      // আগে আগের জায়গার কাছের ঘর; না পেলে সিলেক্ট করা বাক্সের ভেতরে/আশেপাশে খোঁজো
      const fi = findInput(s);
      if (fi) return fi;
      let raw = null;
      try { raw = document.querySelector(s.css); } catch (_) {}
      return isVisible(raw) ? realInput(raw, key) : null;
    }
    let el = null;
    try { el = document.querySelector(s.css); } catch (_) {}
    const useText = TEXT_KEYS.has(key) && s.text;
    if (isVisible(el) && (!useText || norm(el.innerText) === norm(s.text))) {
      if (!PREFIX_KEYS[key] || PREFIX_KEYS[key].ok.test(el.innerText || "")) return el;
    }
    if (useText) {
      const want = norm(s.text);
      const cands = [...document.querySelectorAll('button,[role="button"],[role="tab"],a,label,div,span,li')]
        .filter((e) => !host.contains(e) && isVisible(e) && norm(e.innerText) === want)
        .filter((e, _, arr) => !arr.some((o) => o !== e && e.contains(o)));
      if (cands.length) return nearest(cands, s);
    }
    if (PREFIX_KEYS[key]) {
      const { re } = PREFIX_KEYS[key];
      const c = [...document.querySelectorAll('div,span,a,button,p,label,li,[role="tab"]')]
        .filter((e) => !host.contains(e) && isVisible(e) && re.test(norm(e.innerText)) && norm(e.innerText).length < 40)
        .filter((e, _, arr) => !arr.some((o) => o !== e && e.contains(o)));
      return c.length ? nearest(c, s) : null;
    }
    return isVisible(el) ? el : null;
  }
  function flash(el, key) {
    if (!el) return log(T("notFoundNow", LBL(key)));
    el.scrollIntoView({ block: "center" });
    const old = el.style.outline;
    el.style.outline = "3px solid #f0b90b";
    setTimeout(() => (el.style.outline = old), 1200);
  }

  const randDelay = () => {
    const a = Math.min(cfg.minDelay, cfg.maxDelay), b = Math.max(cfg.minDelay, cfg.maxDelay);
    return sleep((a + Math.random() * (b - a) + spDelay()) * 1000);
  };
  async function waitFor(key, timeout = 8000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      const el = find(key);
      if (el) return el;
      await sleep(200);
    }
    return null;
  }
  const isDisabled = (el) => el.disabled || el.getAttribute("aria-disabled") === "true" || /disabled/i.test(el.className || "");

  function realClick(el, method = 0) {
    el.scrollIntoView({ block: "nearest" });
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    let target = el;
    if (method !== 1) {
      const atPt = document.elementFromPoint(cx, cy);
      if (atPt && (el.contains(atPt) || atPt.contains(el))) target = atPt;
    }
    if (method === 2) { el.click(); return; }
    const base = { bubbles: true, cancelable: true, composed: true, clientX: cx, clientY: cy, button: 0, view: window };
    const pbase = { ...base, pointerId: 1, pointerType: "mouse", isPrimary: true };
    target.dispatchEvent(new PointerEvent("pointerover", pbase));
    target.dispatchEvent(new MouseEvent("mouseover", base));
    target.dispatchEvent(new PointerEvent("pointerdown", { ...pbase, buttons: 1 }));
    target.dispatchEvent(new MouseEvent("mousedown", { ...base, buttons: 1 }));
    if (target.focus) target.focus({ preventScroll: true });
    target.dispatchEvent(new PointerEvent("pointerup", pbase));
    target.dispatchEvent(new MouseEvent("mouseup", base));
    target.dispatchEvent(new MouseEvent("click", { ...base, detail: 1 }));
  }
  async function clickKey(key, { retries = 10 } = {}) {
    for (let i = 0; i < retries; i++) {
      const el = await waitFor(key);
      if (!el) throw new Error(T("errNotFound", LBL(key)));
      if (!isDisabled(el)) { realClick(el); return; }
      await sleep(700);
    }
    throw new Error(T("errDisabled", LBL(key)));
  }

  const WORDS = { buy: ["buy", "ক্রয়", "কিনুন", "কিনো"], sell: ["sell", "বিক্রি", "বিক্রয়"] };
  const startsWithAny = (t, list) => list.some((w) => t.startsWith(w));
  function tabLooksActive(tab) {
    for (let el = tab, i = 0; el && i < 3; el = el.parentElement, i++) {
      if (el.getAttribute("aria-selected") === "true" || el.getAttribute("aria-checked") === "true" ||
          el.getAttribute("data-state") === "active" || el.getAttribute("aria-pressed") === "true") return true;
      if (/(^|[\s_-])(active|selected|checked|current)([\s_-]|$)/i.test(el.className || "")) return true;
    }
    return false;
  }
  function visibleOrderSide() {
    const btns = [...document.querySelectorAll('button,[role="button"]')].filter((b) => !host.contains(b) && isVisible(b) && !b.matches('[role="tab"]'));
    let buy = false, sell = false;
    for (const b of btns) {
      const t = norm(b.innerText);
      if (t.length > 40) continue;
      if (startsWithAny(t, WORDS.buy)) buy = true;
      if (startsWithAny(t, WORDS.sell)) sell = true;
    }
    return { buy, sell };
  }
  function switched(dir, tab) {
    const other = dir === "buy" ? "sell" : "buy";
    const ob = find(dir === "buy" ? "buyButton" : "sellButton");
    if (ob && startsWithAny(norm(ob.innerText), WORDS[dir])) return true;
    const side = visibleOrderSide();
    if (side[dir] && !side[other]) return true;
    const otherTab = find(other === "buy" ? "buyTab" : "sellTab");
    return !!(tab && tabLooksActive(tab) && !(otherTab && otherTab !== tab && tabLooksActive(otherTab)));
  }
  let curSide = "buy";
  async function switchTab(tabKey, dir) {
    curSide = dir;
    for (let attempt = 0; attempt < 6; attempt++) {
      let tab = await waitFor(tabKey, 5000);
      if (!tab) throw new Error(T("errNotFound", LBL(tabKey)));
      if (switched(dir, tab)) return;
      realClick(tab, attempt % 3);
      const t0 = Date.now();
      while (Date.now() - t0 < 2000) {
        await sleep(200);
        tab = find(tabKey) || tab;
        if (switched(dir, tab)) return;
      }
      const ob = find(dir === "buy" ? "buyButton" : "sellButton");
      const side = visibleOrderSide();
      log(T("tabRetry", LBL(tabKey), attempt + 1, ob ? (ob.innerText || "").trim().slice(0, 30) : T("notFoundShort"), side.buy ? "✓" : "✗", side.sell ? "✓" : "✗"));
      document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true }));
      await sleep(500);
    }
    throw new Error(T("errTab", LBL(tabKey)));
  }
  // সিলেক্ট করা জিনিস input না হলে (ঘরের চারপাশের বাক্স) ভেতরের/পাশের আসল input খুঁজে নাও
  const INPUT_KEY_LIST = ["priceInput", "amountInput", "sellAmountInput"];
  function realInput(el, key) {
    if (!el) return null;
    // অন্য কাজের জন্য সিলেক্ট করা ঘর কখনো নেবে না (দামের বদলে অ্যামাউন্টে লেখা এড়াতে)
    const others = INPUT_KEY_LIST.filter((k) => k !== key && cfg.selectors[k]).map((k) => findInput(cfg.selectors[k])) // find() নয় — চক্র এড়াতে
      .filter((x) => x instanceof HTMLInputElement || x instanceof HTMLTextAreaElement);
    const ok = (x) => !host.contains(x) && isVisible(x) && !others.includes(x);
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) return el;
    const inner = el.querySelector && el.querySelector("input:not([type=hidden]):not([type=checkbox]):not([type=radio]),textarea");
    if (inner) return inner;
    const r = el.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const Q = "input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=range]),textarea";
    const dist = (x) => { const q = x.getBoundingClientRect(); return Math.hypot(q.left + q.width / 2 - cx, q.top + q.height / 2 - cy); };
    let p = el.parentElement;
    for (let i = 0; i < 6 && p; i++, p = p.parentElement) {
      const list = [...p.querySelectorAll(Q)].filter(ok);
      if (list.length) return list.sort((a, b) => dist(a) - dist(b))[0];
    }
    // শেষ চেষ্টা: পুরো পেজে সবচেয়ে কাছের লেখার ঘর (২৫০px-এর মধ্যে)
    const all = [...document.querySelectorAll(Q)].filter(ok).sort((a, b) => dist(a) - dist(b));
    return all.length && dist(all[0]) < 250 ? all[0] : null;
  }
  const describe = (el) => el ? `<${el.tagName.toLowerCase()}> "${(el.innerText || el.value || "").trim().replace(/\s+/g, " ").slice(0, 30)}"` : "–";
  function setInput(target, value, key) {
    const el = realInput(target, key);
    if (!el) throw new Error(T("errNotInput", key ? LBL(key) : "?", describe(target)));
    el.focus();
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    setter.call(el, "");
    el.dispatchEvent(new Event("input", { bubbles: true }));
    setter.call(el, String(value));
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.blur();
  }
  async function confirmIfAny() {
    if (!cfg.selectors.confirmButton) return;
    const el = await waitFor("confirmButton", 3000);
    if (el && !isDisabled(el)) { realClick(el); await sleep(500); }
  }

  // ---------- Binance পেজের এরর/সতর্কবার্তা ধরা ----------
  const ERR_FATAL = /insufficient|not enough|exceed|suspend|maintenance|unavailable|not available|restricted|risk control|forbidden|log ?in again|session (has )?expired|verify your identity|kyc|account (is )?(frozen|locked)/i;
  const ERR_WAIT = /too many|too frequent|frequently|try again later|network|timeout|timed out|server busy|system busy|rate limit/i;
  const ERR_BOX = /toast|notification|notice|message|snackbar|alert|error|tips?\b|popup|modal|dialog/i;
  let pageErrors = [];
  function looksLikeNotice(el) {
    for (let e = el, i = 0; e && i < 6; e = e.parentElement, i++) {
      const role = e.getAttribute && e.getAttribute("role");
      if (role === "alert" || role === "status" || role === "dialog") return true;
      if (ERR_BOX.test(typeof e.className === "string" ? e.className : "")) return true;
    }
    return false;
  }
  new MutationObserver((muts) => {
    for (const m of muts) for (const n of m.addedNodes) {
      if (n.nodeType !== 1 || n === host || host.contains(n)) continue;
      const t = (n.innerText || "").replace(/\s+/g, " ").trim();
      if (t.length < 3 || t.length > 220) continue;
      const kind = ERR_FATAL.test(t) ? "fatal" : ERR_WAIT.test(t) ? "wait" : null;
      if (kind && looksLikeNotice(n)) pageErrors.push({ t, kind, ts: Date.now() });
    }
    if (pageErrors.length > 20) pageErrors = pageErrors.slice(-20);
  }).observe(document.documentElement, { childList: true, subtree: true });
  // কোনো কাজের পর পেজে এরর এসেছে কিনা: fatal হলে থামো, wait হলে অপেক্ষা করে আবার চেষ্টা
  async function pageErrorSince(ts) {
    await sleep(700);
    const e = pageErrors.filter((x) => x.ts >= ts).pop();
    if (!e) return null;
    if (e.kind === "fatal") throw new Error(T("binanceErr", e.t));
    log(T("binanceWait", e.t));
    await sleep(30000);
    return e;
  }

  // ---------- সংখ্যা পড়া ----------
  function readNum(el) {
    if (!el) return null;
    const m = (el.innerText || el.value || "").replace(/,/g, "").match(/\d+(\.\d+)?/);
    return m ? parseFloat(m[0]) : null;
  }
  // "1.76K" → 1760 ইত্যাদি
  function parseNums(text) {
    const out = [];
    const re = /(\d[\d,]*\.?\d*)\s*([KMB])?/gi;
    let m;
    while ((m = re.exec(text || ""))) {
      let v = parseFloat(m[1].replace(/,/g, ""));
      if (isNaN(v)) continue;
      const suf = (m[2] || "").toUpperCase();
      if (suf === "K") v *= 1e3; else if (suf === "M") v *= 1e6; else if (suf === "B") v *= 1e9;
      out.push(v);
    }
    return out;
  }
  function readRow(el) {
    if (!el) return null;
    const n = parseNums(el.innerText);
    if (n.length < 2) return null;
    return { price: n[0], amount: n[1], usdt: n[0] * n[1] };
  }
  // খোলা অর্ডার কয়টা: ট্যাবে "Open Orders(2)" থাকলে সেটা, নইলে তালিকার সারি গুনে
  // (পাশের "Holdings (6)"-এর মতো অন্য সংখ্যা ভুল করে পড়বে না)
  const ORDER_STATUS = /^(new|partially filled|partial fill(ed)?|নতুন|আংশিক পূরণ|新订单|部分成交|未成交)$/i;
  // Open Orders তালিকার বাক্স: ট্যাব থেকে উপরে উঠো, কিন্তু Buy/Sell ফর্ম বা অর্ডারবুক যে বাক্সে আছে তার আগেই থামো
  function ordersPanel(tab) {
    const avoid = ["buyButton", "sellButton", "amountInput", "bookAsk", "bookBid"].map((k) => (cfg.selectors[k] ? find(k) : null)).filter(Boolean);
    let r = tab, good = null, last = null;
    for (let i = 0; i < 8 && r && r.parentElement; i++) {
      r = r.parentElement;
      if (avoid.some((e) => r.contains(e))) break;
      if (r.getBoundingClientRect().height > 60) last = r;
      const t = r.innerText || "";
      if (r.getBoundingClientRect().height > 60 && (/direction|status/i.test(t) || /no records|no data|no open orders|কোনো খোলা অর্ডার নেই/i.test(t))) good = r;
    }
    return good || last;
  }
  function readOpenCount() {
    const el = find("openOrders");
    if (!el) return null;
    const own = (el.innerText || "").match(/open\s*orders?\s*\(?\s*(\d+)\s*\)?/i);
    if (own) return parseInt(own[1], 10);
    const panel = ordersPanel(el);
    if (!panel) return null; // তালিকা খুঁজে না পেলে "জানি না", "০" নয়
    const tabBottom = el.getBoundingClientRect().bottom;
    const w = document.createTreeWalker(panel, NodeFilter.SHOW_TEXT);
    let n, count = 0;
    while ((n = w.nextNode())) {
      const t = (n.nodeValue || "").trim();
      if (!ORDER_STATUS.test(t)) continue;
      const e = n.parentElement;
      if (!e || host.contains(e) || e.offsetParent === null) continue;
      if (e.getBoundingClientRect().top < tabBottom) continue; // তালিকার সারি ট্যাবের নিচে থাকে
      count++;
    }
    if (count) return count;
    // সারি গোনা যায়নি অথচ Cancel All দেখা যাচ্ছে (অর্ডার না থাকলে Binance এটা লুকায়) — অন্য ভাষা/লেআউট, তাই "জানি না"
    const ca = cfg.selectors.cancelAll ? find("cancelAll") : null;
    if (ca && !isDisabled(ca)) return null;
    return 0;
  }
  // Open Orders ট্যাব খোলা না থাকলে (যেমন Order History দেখানো) তালিকা পড়া যায় না — আগে ট্যাবটা খোলো
  async function showOrders() {
    const t = find("openOrders");
    if (t && !tabLooksActive(t)) { realClick(t); await sleep(400); }
  }
  // ব্যালেন্স স্থির হওয়া পর্যন্ত পড়ো (পরপর দুবার একই, সর্বোচ্চ ms) — শুরুর ব্যালেন্সে আটকে থাকা টাকা যেন বাদ না পড়ে
  async function stableUsdt(ms = 12000) {
    let a = await readUsdt();
    const t0 = Date.now();
    while (a != null && Date.now() - t0 < ms) {
      await sleep(1500);
      const b = await readUsdt();
      if (b == null) break;
      if (Math.abs(b - a) < 1e-6) return b;
      a = b;
    }
    return a;
  }
  async function readUsdt() {
    for (let i = 0; i < 6; i++) {
      const el = find("balanceText");
      const t = el ? el.innerText || "" : "";
      const n = readNum(el);
      const hasOtherCoin = /[A-Za-z]{2,}/.test(t.replace(/usdt|available|balance|avbl/gi, ""));
      if (n != null && !hasOtherCoin) return n;
      await sleep(300);
    }
    log(T("balFail"));
    return null;
  }
  function floorTo(n, d) {
    const f = Math.pow(10, d);
    return (Math.floor(n * f + 1e-9) / f).toFixed(d);
  }
  async function clickOrderType() {
    if (!cfg.selectors.orderType) return;
    const el = await waitFor("orderType", 3000);
    if (el) { realClick(el); await sleep(400); }
  }
  // লাইভ বাজার দাম: Buy = অর্ডারবুকের সবচেয়ে কম Sell দাম, Sell = সবচেয়ে বেশি Buy দাম
  // (তাই Limit অর্ডার সাথে সাথে পূরণ হয়); অর্ডারবুক সিলেক্ট না থাকলে বড় করে লেখা চলতি দাম
  function firstNumText(el) {
    const m = ((el && (el.innerText || el.textContent)) || "").replace(/,/g, "").match(/\d+(\.\d+)?/);
    return m ? m[0] : null;
  }
  let liveWarned = false;
  // অর্ডারবুকের সব দাম পড়ে চলতি দামের ঠিক উপরের (সবচেয়ে কম Sell) আর ঠিক নিচের (সবচেয়ে বেশি Buy) দাম বের করো —
  // নির্দিষ্ট সারির জায়গা সরে গেলেও ঠিক থাকে
  function liveBook() {
    const els = ["bookAsk", "bookBid", "livePrice"].map((k) => (cfg.selectors[k] ? find(k) : null));
    const [askEl, bidEl, midEl] = els;
    const have = els.filter(Boolean);
    if (!have.length) return null;
    // সবগুলোর সাধারণ পূর্বপুরুষ = অর্ডারবুক
    let root = have[0];
    if (have.length > 1) {
      while (root && !have.every((e) => root.contains(e))) root = root.parentElement;
    } else {
      for (let i = 0; i < 4 && root.parentElement; i++) root = root.parentElement;
    }
    if (!root) return null;
    // কোন উচ্চতায় ভাগ: উপরে Sell (লাল), নিচে Buy (সবুজ)
    const cy = (e) => { const r = e.getBoundingClientRect(); return r.top + r.height / 2; };
    let splitY = midEl ? cy(midEl) : askEl && bidEl ? (cy(askEl) + cy(bidEl)) / 2 : NaN;
    let ref = midEl ? parseFloat(firstNumText(midEl)) : NaN;
    if (!(ref > 0)) {
      const a = askEl ? parseFloat(firstNumText(askEl)) : NaN, b = bidEl ? parseFloat(firstNumText(bidEl)) : NaN;
      ref = a > 0 && b > 0 ? (a + b) / 2 : a > 0 ? a : b;
    }
    if (!(ref > 0) || isNaN(splitY)) return null;
    const midTxt = midEl ? String(firstNumText(midEl) || "").replace(/,/g, "") : "";
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n, ask = null, bid = null;
    while ((n = w.nextNode())) {
      const el = n.parentElement;
      if (!el || (midEl && midEl.contains(el))) continue; // চলতি দামের লেখা নিজে বাদ
      const t = (n.nodeValue || "").trim().replace(/,/g, "");
      if (midTxt && t === midTxt) continue; // চলতি দামের আরেকটা কপি (অর্ডারবুকের সারি নয়) — বাদ, নইলে Sell = Buy দেখায়
      if (!/^\d+(\.\d+)?$/.test(t)) continue;
      const v = parseFloat(t);
      if (!(v >= ref * 0.95 && v <= ref * 1.05)) continue; // অ্যামাউন্টের সংখ্যা বাদ
      const r = el.getBoundingClientRect();
      if (!r.height) continue;
      if (r.top + r.height / 2 < splitY) { if (!ask || v < parseFloat(ask)) ask = t; }
      else if (!bid || v > parseFloat(bid)) bid = t;
    }
    // উপর-নিচ উল্টো লেআউট হলে অদলবদল
    if (ask && bid && parseFloat(ask) < parseFloat(bid)) [ask, bid] = [bid, ask];
    const m = ref;
    return { ask, bid, mid: m };
  }
  // লাইভ দামে দ্রুত পূরণ: Sell সেরা Buy দামের সামান্য নিচে, Buy সেরা Sell দামের সামান্য উপরে Limit —
  // Binance তবু অর্ডারবুকের সেরা দামেই মেলায়, কিন্তু দাম এক টিক সরলেও অর্ডার ঝুলে থাকে না (ঝুললে পরে নিচে বিক্রিতে বেশি লস)
  function pushPx(txt) {
    const b = +bufNow() || 0;
    if (!(b > 0) || !(parseFloat(txt) > 0)) return txt;
    const dec = (String(txt).split(".")[1] || "").length;
    return (parseFloat(txt) * (curSide === "sell" ? 1 - b / 100 : 1 + b / 100)).toFixed(dec);
  }
  async function setLivePrice(quiet) {
    const lb = liveBook();
    if (lb && (curSide === "sell" ? lb.bid : lb.ask)) {
      if (!cfg.selectors.livePrice && !liveWarned) { log(T("pmNeedMid")); liveWarned = true; }
      const book = curSide === "sell" ? lb.bid : lb.ask, txt = curSide === "sell" && sellOverride ? sellOverride : pushPx(book);
      const pin = await waitFor("priceInput", 3000);
      if (!pin) throw new Error(T("errNotFound", LBL("priceInput")));
      setInput(pin, txt, "priceInput");
      await sleep(300);
      if (!quiet) log(curSide === "sell" && sellOverride ? T("mkPlaced", txt, lb.bid) : T("pmLiveSet", txt, T(curSide === "sell" ? "pmBid" : "pmAsk")) + (txt !== book ? ` (${book})` : ""));
      return parseFloat(book);
    }
    return setLivePriceRow(quiet);
  }
  async function setLivePriceRow(quiet) {
    // দুই সারিই পড়ো: Sell সারির দাম Buy সারির চেয়ে কম হলে সারি দুটো উল্টো সিলেক্ট হয়েছে — নিজে ঠিক করো
    let ask = cfg.selectors.bookAsk ? firstNumText(find("bookAsk")) : null;
    let bid = cfg.selectors.bookBid ? firstNumText(find("bookBid")) : null;
    if (ask && bid && parseFloat(ask) < parseFloat(bid)) {
      [ask, bid] = [bid, ask];
      if (!liveWarned) { log(T("pmSwapped")); liveWarned = true; }
    }
    let txt = curSide === "sell" ? bid : ask, src = "book";
    if (!txt && cfg.selectors.livePrice) { txt = firstNumText(find("livePrice")); src = "last"; }
    // Buy দাম Suggest দামের চেয়ে অনেক কম হলে ভুল সারি — সতর্ক করো
    if (txt && curSide !== "sell" && cfg.selectors.suggestPrice && !liveWarned) {
      const sg = readNum(find("suggestPrice"));
      if (sg > 0 && parseFloat(txt) < sg * 0.995) { log(T("pmLowWarn", txt, sg)); liveWarned = true; }
    }
    if (!txt || !(parseFloat(txt) > 0)) throw new Error(T("errLive"));
    const book = txt; txt = pushPx(txt);
    const pin = await waitFor("priceInput", 3000);
    if (!pin) throw new Error(T("errNotFound", LBL("priceInput")));
    setInput(pin, txt, "priceInput");
    await sleep(300);
    if (!quiet) log(T("pmLiveSet", txt, src === "book" ? T(curSide === "sell" ? "pmBid" : "pmAsk") : T("pmLast")) + (txt !== book ? ` (${book})` : ""));
    return parseFloat(book);
  }
  async function clickSuggest(quiet) {
    if (isLive()) return setLivePrice(quiet);
    if (!cfg.selectors.suggestPrice) return null;
    const el = await waitFor("suggestPrice", 3000);
    if (!el) { log(T("suggestMiss")); return null; }
    realClick(el);
    await sleep(400);
    const p = readNum(el);
    if (!quiet) log(T("priceSet", p));
    return p;
  }
  async function readSuggest() { return readNum(await waitFor("suggestPrice", 3000)); }
  // কেনা নতুন টোকেন আছে কিনা: হাতে রাখা (keep) আর আগের অবশিষ্ট (dust) বাদ দিয়ে
  function hasNew(avail) {
    const base = (state.keep || 0) + (state.dust || 0);
    return avail - base > Math.max(1e-9, base * 0.001);
  }
  async function readSellAvailable() { const n = readNum(find("sellAvailable")); return n == null ? 0 : n; }
  // "Available" পরপর দুবার একই না দেখানো পর্যন্ত পড়ো (সর্বোচ্চ ms)
  async function stableAvail(ms) {
    const t0 = Date.now();
    let prev = await readSellAvailable(), same = 0;
    while (Date.now() - t0 < ms) {
      await sleep(400);
      const v = await readSellAvailable();
      if (Math.abs(v - prev) < 1e-9) { if (++same >= 3) return v; } else same = 0;
      prev = v;
    }
    return prev;
  }

  // ---------- লস হিসাব ----------
  // ১) অজানা বড় বদল: লসে না ধরলেও হিসাব রাখা — পরে টাকা ফিরলে বাদ, ৬০ সে. পরেও না ফিরলে সতর্কতা আর লস-লিমিটে ধরা
  function unkNote(drop) {
    if (!state.running || !isFinite(drop)) return;
    if (drop > 0) { state.unk = (state.unk || 0) + drop; state.unkAt = Date.now(); }
    else if (state.unk > 0) state.unk = Math.max(0, state.unk + drop); // টাকা ফিরেছে
  }
  function unkCheck() {
    const u = state.unk || 0, amt = state.lastAmt || cfg.amount || 0;
    if (!(u > Math.max(1, amt * 0.5)) || Date.now() - (state.unkAt || 0) < 60000) return;
    if (u - (state.unkTold || 0) < Math.max(1, amt * 0.5)) return;
    state.unkTold = u;
    const msg = T("unkMsg", u.toFixed(4), fmt(state.totalLoss));
    log("⚠ " + msg); bg({ type: "avh-notify", title: "⚠ Alpha Volume Helper", message: msg });
    if (tgReady()) tgSend("⚠️ " + msg);
  }
  const effLoss = () => (state.totalLoss || 0) + (Date.now() - (state.unkAt || 0) >= 60000 ? Math.max(0, state.unk || 0) : 0);
  async function updateBalance(label) {
    if (!cfg.selectors.balanceText) return null;
    let b = await readUsdt();
    if (b == null) return null;
    // শুরুর বা থামার পর প্রথম পড়া: খোলা অর্ডার শেষ, আর ব্যালেন্স স্থির হওয়া পর্যন্ত অপেক্ষা
    if (state.startBal == null || state.lastBal == null) {
      if (state.resumed && cfg.selectors.openOrders && cfg.selectors.cancelAll && readOpenCount() > 0) { log(T("startCancel")); try { await cancelOpenOrders(); } catch (_) {} } // রিলোডের পর: নিজের আটকে থাকা অর্ডার
      const s2 = await stableUsdt(); if (s2 != null) b = s2;
    }
    if (state.startBal == null) {
      state.startBal = b; state.lastBal = b;
      if (state.lossOffset) state.totalLoss = state.lossOffset;
      log(T("startBal", b)); renderProgress(); return b;
    }
    if (state.lastBal == null) {
      // থামার পর আবার শুরু: শুরুর ব্যালেন্স আগেরটাই, এখনকার ব্যালেন্স থেকে মোট লস
      // থামার পর আবার শুরু: মাঝের সময়ে ব্যালেন্সের বদল (টাকা তোলা/জমা, নিজে কেনা) ট্রেডের লস না — আগের মোট লস ঠিক রেখে এখান থেকে মাপো
      const prev = state.totalLoss != null ? state.totalLoss : 0;
      state.lossOffset = prev - (state.startBal - b);
      state.totalLoss = prev;
      state.l0 = prev;
      state.lastBal = b;
      log(T("contBal2", b, fmt(prev)));
      renderProgress(); return b;
    }
    if (Math.abs(b - state.lastBal) > Math.max(cfg.amount * 3, 5)) {
      unkNote(state.lastBal - b);
      // এক রাউন্ডে এত বদল ট্রেড থেকে হয় না (deposit/withdraw বা ভুল পড়া) — লসে না ধরে এখান থেকে নতুন করে মাপো,
      // নইলে পরের সব রাউন্ডেও একই লাফ দেখে লসের হিসাব আর লস-লিমিট চিরদিন থেমে থাকে
      state.lossOffset = (state.lossOffset || 0) + (b - state.lastBal);
      log(T("balJump", state.lastBal, b));
      state.lastBal = b;
      return null;
    }
    // এক রাউন্ডে ট্রেডের অর্ধেকের বেশি লস/লাভ বাস্তবে হয় না — সাধারণত Sell-এর টাকা ব্যালেন্সে দেরিতে ফেরে।
    // ১৫ সে. পর্যন্ত আবার পড়ো; তাও না মিললে এই বদল লস/লাভে ধরো না (ভুল বড় লস, ভুল লস-লিমিটে থামা, ভুল Telegram সতর্কতা বন্ধ)
    const amt0 = state.lastAmt || cfg.amount || 0;
    // রাউন্ডের পরের পড়া ছাড়াও (অপেক্ষার সময়ের পড়াতেও) — সেখানে তো কোনো ট্রেডই হয়নি
    const odd = (x) => amt0 > 0 && Math.abs(state.lastBal - x) >= Math.max(1, amt0 * 0.5);
    if (odd(b)) {
      log(T("balWait", (state.lastBal - b).toFixed(4)));
      for (let i = 0; i < 10 && odd(b); i++) {
        await sleep(1500);
        const b2 = await readUsdt();
        if (b2 != null) b = b2;
      }
      if (odd(b)) {
        unkNote(state.lastBal - b);
        state.lossOffset = (state.lossOffset || 0) + (b - state.lastBal);
        log(T("balOdd", state.lastBal, b));
        state.lastBal = b;
        renderProgress();
        return null;
      }
    }
    unkCheck();
    const roundLoss = state.lastBal - b;
    state.totalLoss = (state.lossOffset || 0) + (state.startBal - b);
    const maxGain = Math.max(2, Math.max(state.volume, 0) * 0.0015); // প্রতি ১০০০ ভলিউমে ১.৫ USDT-এর বেশি লাভ ভলিউম-ট্রেডে বাস্তবে হয় না
    if (state.totalLoss < -maxGain) {
      const fix = -state.totalLoss;
      state.lossOffset = (state.lossOffset || 0) + fix;
      state.totalLoss = state.lossOffset + (state.startBal - b);
      // ভুল লাভ আগের সেশন থেকে এসে থাকলে রান শেষে Sheet-এ উল্টো "লস" সারি পাঠিয়ো না
      if ((state.l0 || 0) < 0) state.l0 = Math.min(0, state.l0 + fix);
      sp.snaps = []; // হিসাব ঠিক করায় লাফ — খরচের মাপ নতুন করে
      log("⚠ " + T("balGainFix", fix.toFixed(2)));
    }
    // ব্যালেন্স সতর্কতা: শুরুর তুলনায় প্রতি balAlert% কমলে একবার করে জরুরি খবর
    if (cfg.balAlert > 0 && state.startBal > 0 && state.totalLoss > 0) {
      const pct = (state.totalLoss / state.startBal) * 100, step = Math.floor(pct / cfg.balAlert);
      if (step >= 1 && step > (state.balStep || 0)) {
        state.balStep = step;
        const msg = T("balAlertMsg", pct.toFixed(2), fmt(state.totalLoss), (+state.startBal).toFixed(2), (+b).toFixed(2));
        log("🚨 " + msg);
        bg({ type: "avh-notify", title: "🚨 Alpha Volume Helper", message: msg });
        if (cfg.soundOn) bg({ type: "avh-beep", kind: "error" });
        if (tgReady()) tgSend("🚨 " + msg);
      }
    }
    // খরচ-রক্ষার জন্য সাম্প্রতিক রাউন্ডের লস মনে রাখো (শেষ ১০টা)
    if (label && state.lastAmt > 0) {
      state.recent = (state.recent || []).concat([{ vol: state.lastAmt * (cfg.countSell ? 2 : 1), loss: roundLoss }]).slice(-10);
      statRound(state.lastAmt * (cfg.countSell ? 2 : 1), roundLoss);
    }
    if (label) {
      log(roundLoss < -1e-9 || state.totalLoss < -1e-9 ? T("roundPL", label, roundLoss, state.totalLoss) : T("roundLoss", label, fmt(roundLoss), fmt(state.totalLoss)));
      // ০ হলে Sheet-এ পাঠাবে না; লাভ হলে ধরন "profit", লস হলে "loss" (লস কলামে লাভ ঋণাত্মক — যোগফল ঠিক থাকে)
      const rl = +roundLoss.toFixed(6);
      if (Math.abs(rl) >= 0.000001) {
        reportPush({ type: rl < 0 ? "profit" : "loss", vol: 0, trades: 0, loss: rl });
        state.lossSent = (state.lossSent || 0) + rl;
        // বড় লসের সতর্কতা: এক রাউন্ডে ট্রেড অ্যামাউন্টের ২%-এর বেশি (কমপক্ষে ১ USDT)
        const amt = state.lastAmt || cfg.amount || 0;
        if (rl >= Math.max(1, amt * 0.02) && tgReady()) {
          const same = amt > 0 && Math.abs(rl - amt) / amt < 0.05;
          tgSend("⚠️ " + T("tgBigLoss", label, rl.toFixed(4), amt.toFixed(2), plText(state.totalLoss, true)) + (same ? "\n" + T("tgBigLossSame") : ""));
        }
      }
    }
    state.lastBal = b;
    renderProgress();
    return b;
  }

  // ---------- ব্যালেন্স পড়ার আগে ঝুলে থাকা অর্ডার শেষ হওয়ার অপেক্ষা ----------
  // Sell দেরিতে পূরণ হলে টাকা তখনো ব্যালেন্সে ফেরেনি — তখন পড়লে ভুল করে বড় লস দেখায়
  async function settleOrders(maxMs) {
    if (!cfg.selectors.openOrders) { await sleep(1500); return true; }
    const limit = maxMs || Math.max(cfg.fillTimeout, 10) * 2000;
    const t0 = Date.now();
    let told = false;
    await showOrders();
    while (Date.now() - t0 < limit) {
      const n = readOpenCount();
      if (n === 0) { if (told) await sleep(1000); return true; }
      if (!told) { log(T("waitOpen", n == null ? "?" : n)); told = true; }
      await sleep(1000);
    }
    return readOpenCount() === 0;
  }

  // লস-লিমিটে থামার আগে নিশ্চিত হও: খোলা অর্ডার নেই, হাতে না-বিক্রি টোকেন নেই, আবার পড়েও লস একই
  async function lossConfirmed() {
    log(T("lossCheck", fmt(state.totalLoss)));
    if (!(await settleOrders(60000)) && cfg.selectors.cancelAll) await cancelOpenOrders();
    await switchTab("sellTab", "sell");
    await clickOrderType();
    const held = await readSellAvailable();
    if (hasNew(held)) {
      log(T("lossHeld", +(held - (state.keep || 0)).toFixed(6)));
      await doSell();
      await settleOrders();
    }
    await switchTab("buyTab", "buy");
    // Sell দেরিতে পূরণ হলে টাকা ফিরতে সময় লাগে — ৩০ সেকেন্ড ধরে কয়েকবার পড়ে দেখো
    const t0 = Date.now();
    let still = true;
    while (Date.now() - t0 < 30000) {
      await sleep(3000);
      await updateBalance("");
      still = state.totalLoss != null && effLoss() >= cfg.maxLoss;
      if (!still) break;
    }
    if (!still) log(T("lossFalse", fmt(state.totalLoss)));
    return still;
  }

  // ---------- ট্রেডের আগে বাজার চেক: অর্ডারবুকের গভীরতা ও স্প্রেড ----------
  async function marketOk(amt) {
    if (cfg.depthOn && (cfg.selectors.bookAsk || cfg.selectors.bookBid)) {
      const need = amt * cfg.minDepth;
      for (const [key, side] of [["bookAsk", T("sideSell")], ["bookBid", T("sideBuy")]]) {
        if (!cfg.selectors[key]) continue;
        const r = readRow(find(key));
        if (!r) { log(T("depthMiss")); break; }
        if (r.usdt < need) {
          log(T("depthWait", side, r.usdt.toFixed(2), need.toFixed(2), cfg.spreadWait));
          setStatus("wait", T("stDepth"));
          await sleep(cfg.spreadWait * 1000);
          return false;
        }
      }
    }
    // লাইভ বাজার মোডে: অর্ডারবুকের সবচেয়ে নিচের Sell (লাল) আর সবচেয়ে উপরের Buy (সবুজ) দাম দিয়ে — গেজের সাথে একই হিসাব
    const spLim = spreadLimit();
    if (spLim != null && isLive()) {
      const lb = liveBook();
      const a = lb && lb.ask ? parseFloat(lb.ask) : NaN, b = lb && lb.bid ? parseFloat(lb.bid) : NaN;
      if (a > 0 && b > 0 && a >= b) {
        const spread = ((a - b) / ((a + b) / 2)) * 100;
        if (spread > spLim) {
          log(T("spreadLiveLog", spread.toFixed(3), lb.ask, lb.bid, spLim, cfg.spreadWait));
          setStatus("wait", T("stSpread", spread.toFixed(3)));
          await sleep(cfg.spreadWait * 1000);
          return false;
        }
        return true;
      }
      if (!cfg.selectors.suggestPrice) { log(T("spreadMiss")); return true; }
    }
    if (cfg.spreadOn && !isLive() && cfg.selectors.suggestPrice) {
      await switchTab("sellTab", "sell");
      await clickOrderType();
      const sp = await readSuggest();
      await switchTab("buyTab", "buy");
      await clickOrderType();
      const bp = await readSuggest();
      if (!sp || !bp) { log(T("spreadMiss")); return true; }
      const spread = (Math.abs(bp - sp) / Math.max(bp, sp)) * 100;
      if (spread > cfg.maxSpread) {
        log(T("spreadWaitLog", spread.toFixed(3), bp, sp, cfg.maxSpread, cfg.spreadWait));
        setStatus("wait", T("stSpread", spread.toFixed(3)));
        await sleep(cfg.spreadWait * 1000);
        return false;
      }
    }
    return true;
  }

  // ---------- অর্ডার পূরণ যাচাই ও বাতিল ----------
  async function waitFilled(sec, abort) {
    if (!cfg.selectors.openOrders) return null;
    await showOrders();
    await sleep(800);
    const t0 = Date.now();
    while (Date.now() - t0 < (sec || cfg.fillTimeout) * 1000) {
      if (readOpenCount() === 0) return true;
      if (abort && abort()) { await sleep(300); return readOpenCount() === 0; }
      await sleep(500);
    }
    return readOpenCount() === 0;
  }
  async function cancelOpenOrders() {
    if (!cfg.selectors.cancelAll) throw new Error(T("errNoCancel"));
    const tab = find("openOrders");
    if (tab) { realClick(tab); await sleep(500); }
    // অর্ডার না থাকলে Binance "Cancel All" বাটন দেখায় না — তখন বাতিলের কিছু নেই
    if (!(await waitFor("cancelAll", 2500))) {
      await sleep(800);
      if (!readOpenCount()) { log(T("noOpenNow")); return; }
    }
    await clickKey("cancelAll", { retries: 5 });
    if (cfg.selectors.cancelConfirm) {
      const el = await waitFor("cancelConfirm", 3000);
      if (el && !isDisabled(el)) realClick(el);
    }
    // বাতিল হলো কিনা দেখো; না হলে আরেকবার Cancel All চাপো
    for (let round = 0; round < 2; round++) {
      const t0 = Date.now();
      while (Date.now() - t0 < 8000) {
        if (readOpenCount() === 0) { log(T("cancelled")); await sleep(800); return; }
        await sleep(500);
      }
      if (round === 0) {
        log(T("cancelRetry", readOpenCount() ?? "?"));
        const t = find("openOrders");
        if (t) { realClick(t); await sleep(500); }
        await clickKey("cancelAll", { retries: 3 });
        if (cfg.selectors.cancelConfirm) {
          const el = await waitFor("cancelConfirm", 3000);
          if (el && !isDisabled(el)) realClick(el);
        }
      }
    }
    throw new Error(T("errCancel"));
  }

  // ---------- অ্যামাউন্ট ----------
  function pickAmount() {
    const j = Math.min(50, Math.max(0, cfg.amountJitter || 0)) / 100;
    let amt = j ? +(cfg.amount * (1 - j + Math.random() * 2 * j)).toFixed(2) : cfg.amount;
    // টার্গেটের কাছে এলে শুধু যতটুকু বাকি ততটুকুই
    const per = cfg.countSell ? 2 : 1;
    const left = (cfg.target - state.volume) / per;
    if (left > 0 && left < amt) {
      amt = Math.max(MIN_ORDER, Math.ceil(left * 100) / 100);
      log(T("lastAmount", amt));
    }
    // পয়েন্টের ধাপের কাছে এলে ধাপ পূরণে যতটুকু Buy লাগে ততটুকুই
    if (cfg.ptOn && ptPlan && !ptPlan.none && ptPlan.d === utcDay()) {
      const lb = ptPlan.stopBuy - ptBuy();
      if (lb > 0 && lb < amt) { amt = Math.max(MIN_ORDER, Math.ceil(lb * 100) / 100); log(T("lastAmount", amt)); }
    }
    return amt;
  }

  // ---------- এক রাউন্ড: Buy ----------
  // ফর্মে "Exceeds available" বা বন্ধ Buy বাটন — অ্যামাউন্ট আবার বসিয়ে দেখো, না হলে থামো
  // শুধু এরর বার্তায় দেখানোর জন্য — ফর্মের সতর্কলেখা (সর্বনিম্ন/সর্বোচ্চ/দশমিক ইত্যাদি)
  function formHint() {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      const t = (n.nodeValue || "").trim();
      if (t.length > 3 && t.length < 90 && /exceed|insufficient|minimum|maximum|at least|min\.? (order|amount|total)|invalid|precision|too (small|low|high)|not enough/i.test(t)) {
        const el = n.parentElement;
        if (el && !host.contains(el) && el.offsetParent !== null) return t;
      }
    }
    return null;
  }
  function formError() {
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = w.nextNode())) {
      const t = (n.nodeValue || "").trim();
      if (t.length > 3 && t.length < 80 && /exceeds? available|insufficient|exceed/i.test(t)) {
        const el = n.parentElement;
        if (el && !host.contains(el) && el.offsetParent !== null) return t;
      }
    }
    return null;
  }
  function buyBlocked() {
    const b = find("buyButton");
    return formError() || (b && isDisabled(b) ? T("pmBtnOff") : null);
  }
  async function fixBuyForm(inp, amt) {
    let why = buyBlocked();
    for (let i = 0; why && i < 2; i++) {
      log(T("pmRetype", why));
      setInput(inp, "", "amountInput");
      await sleep(300);
      setInput(inp, amt, "amountInput");
      await sleep(700);
      why = buyBlocked();
    }
    if (why) throw new Error(T("pmFormErr", why));
  }
  // কেনা পূরণের মুহূর্তের সেরা Buy দাম — মেকার Sell-এর স্টপ এটাই (এর নিচে এক ঘর নামলেই বেচে দেওয়া)
  function buyBidNow() { try { const lb = liveBook(); const b = lb && lb.bid ? parseFloat(lb.bid) : NaN; return b > 0 ? b : 0; } catch (_) { return 0; } }
  async function doBuy(amt) {
    state.buyRef = 0; state.buyBid = 0;
    setStatus("run", T("stBuy", amt));
    // লাইভ দামে: অল্প অপেক্ষা, পূরণ না হলে বাতিল করে নতুন লাইভ দামে আবার
    const live = isLive();
    const tries = live ? Math.max(cfg.retries, 5) : cfg.retries;
    const wait = live ? cfg.liveWait : cfg.fillTimeout;
    let px = null;
    for (let attempt = 0; attempt <= tries; attempt++) {
      await clickOrderType();
      const p0 = await clickSuggest();
      if (p0 > 0) px = p0;
      const inp = await waitFor("amountInput");
      if (!inp) throw new Error(T("errNoAmount"));
      setInput(inp, amt, "amountInput");
      await sleep(400);
      if (isLive()) await fixBuyForm(inp, amt); // লাইভ দামে অ্যামাউন্টের পরে আর দাম বদলাবে না
      else { const p1 = await clickSuggest(true); if (p1 > 0) px = p1; }
      const tb = Date.now();
      state.buyPx = orderPx(curPrice);
      await clickKey("buyButton");
      await confirmIfAny();
      if (await pageErrorSince(tb)) continue; // সাময়িক সমস্যা — আবার চেষ্টা
      log(T("buyLog", amt, attempt ? attempt + 1 : 0));
      const tf = Date.now();
      const f = await waitFilled(wait);
      if (f != null) bufFill(f, Date.now() - tf);
      if (f !== false) { if (f) log(T("buyFilled")); state.buyRef = px > 0 ? px : 0; state.buyBid = buyBidNow(); return amt; }
      log(T("buyNotFilled", wait));
      await cancelOpenOrders();
      await switchTab("sellTab", "sell");
      await clickOrderType();
      const part = await readSellAvailable();
      if (hasNew(part)) {
        // আংশিক পূরণ: যতটুকু কেনা হয়েছে শুধু ততটুকুই ভলিউমে গোনো
        const got = part - (state.keep || 0) - (state.dust || 0);
        const usdt = px > 0 ? Math.min(amt, +(got * px).toFixed(2)) : amt;
        log(T("partial", +(part - (state.keep || 0)).toFixed(6)) + (usdt < amt ? ` (≈ ${usdt} USDT)` : ""));
        state.buyRef = px > 0 ? px : 0; state.buyBid = buyBidNow();
        return usdt;
      }
      if (attempt < tries) { log(T("buyAgain", attempt + 2, tries + 1)); await switchTab("buyTab", "buy"); }
    }
    throw new Error(T("errBuyFail", tries + 1));
  }

  // ---------- এক রাউন্ড: Sell ----------
  async function sellButtonReady(ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      const b = find("sellButton");
      if (b && !isDisabled(b)) return b;
      await sleep(250);
    }
    return null;
  }
  // Sell-এর আনুমানিক দাম — বাটনে না চেপে (লাইভ অর্ডারবুক / Suggest / চলতি দাম)
  function sellRefPrice() {
    try {
      if (isLive()) { const lb = liveBook(); const b = lb && lb.bid ? parseFloat(lb.bid) : NaN; if (b > 0) return b; }
      if (cfg.selectors.suggestPrice) { const v = readNum(find("suggestPrice")); if (v > 0) return v; }
      return curPrice();
    } catch (_) { return null; }
  }
  // হাতে থাকা টোকেনের মূল্য সর্বনিম্ন Sell-এর চেয়ে কম হলে বিক্রি না করে অবশিষ্ট (dust) হিসেবে রাখো — থামবে না
  function tinyLeft(avail, px) {
    const left = avail - (state.keep || 0);
    const p = px > 0 ? px : sellRefPrice();
    if (!(left > 0) || !(p > 0) || left * p >= MIN_SELL_USDT) return false;
    log(T("dustSkip", +left.toFixed(6), (left * p).toFixed(4)));
    state.dust = Math.max(0, left);
    return true;
  }
  async function doSell(opts = {}) {
    try { return await doSellIn(opts); } finally { sellOverride = null; }
  }
  async function doSellIn(opts) {
    setStatus("run", T("stSell"));
    await switchTab("sellTab", "sell");
    await clickOrderType();
    let avail = 0;
    const tw = Date.now();
    while (Date.now() - tw < 20000) {
      avail = await readSellAvailable();
      if (hasNew(avail)) break;
      await sleep(500);
    }
    if (!hasNew(avail)) throw new Error(T("errNoTokens"));
    // Binance "Available" কখনো কয়েক ধাপে বাড়ে — স্থির হওয়া পর্যন্ত অপেক্ষা, নইলে কম বিক্রি হয়
    avail = (await stableAvail(6000)) || avail;
    let restPasses = 0;

    const live = isLive();
    const fast = !live && cfg.sellStep > 0 && !!cfg.selectors.priceInput && !!cfg.selectors.openOrders;
    const tries = fast || live ? Math.max(cfg.retries, 5) : cfg.retries;
    const wait = live ? cfg.liveWait : fast ? cfg.sellFastWait : cfg.fillTimeout;
    const mk = opts.maker ? makerPlan() : null;
    if (mk) mkStat.try++;
    else if (opts.maker && mkSkipWhy) log("⚡ " + T("mkSkip", mkSkipWhy));
    for (let attempt = 0; attempt <= tries; attempt++) {
      sellOverride = mk && attempt === 0 ? mk.txt : null;
      if (tinyLeft(avail)) return; // খুব কম টোকেন (আংশিক পূরণের পর বাকি) — Binance নেবে না
      const sInp = await waitFor("sellAmountInput");
      if (!sInp) throw new Error(T("errNoSellInput"));
      let placed = false, qty = 0, lastSp = null;
      for (const d of [Math.max(0, cfg.sellDecimals), 2, 1, 0].filter((v, i, a) => a.indexOf(v) === i)) {
        qty = floorTo(avail - (state.keep || 0), d); // আগে থেকে থাকা টোকেন বিক্রি হবে না
        if (!(parseFloat(qty) > 0)) continue;
        const sp = await clickSuggest();
        if (sp > 0) lastSp = sp;
        // Sell দ্রুত পূরণ: প্রতিবার আবার চেষ্টায় দাম একটু করে কমাও (মোট সর্বোচ্চ ১০%)
        if (fast && attempt > 0 && sp) {
          const pin = find("priceInput");
          const dec = (String(sp).split(".")[1] || "").length || 6;
          const drop = Math.min(cfg.sellStep * attempt, MAX_SELL_DROP);
          const np = (sp * (1 - drop / 100)).toFixed(dec);
          if (pin) { setInput(pin, np, "priceInput"); await sleep(300); log(T("sellStepLog", np, drop.toFixed(2))); }
        }
        setInput(sInp, qty, "sellAmountInput");
        await sleep(500);
        // Binance যাচাই করতে সময় নেয় — ৩ সে. পর্যন্ত বাটন চালু হওয়ার অপেক্ষা; না হলে অ্যামাউন্ট মুছে আবার বসিয়ে আরেকবার দেখো
        let sb = await sellButtonReady(3000);
        if (!sb) {
          setInput(sInp, "", "sellAmountInput"); await sleep(300);
          setInput(sInp, qty, "sellAmountInput"); await sleep(500);
          sb = await sellButtonReady(3000);
        }
        if (sb) {
          const ts = Date.now();
          state.sellPx = orderPx(() => (lastSp > 0 ? lastSp : sellRefPrice()));
          realClick(sb); await confirmIfAny();
          if (await pageErrorSince(ts)) { placed = "retry"; break; }
          placed = true; break;
        }
      }
      if (!placed) {
        // সর্বনিম্ন অর্ডারের চেয়ে কম টোকেন: Binance Sell বাটন বন্ধ রাখে — এটা অবশিষ্ট গুঁড়া, থামার কারণ নয়
        const left = avail - (state.keep || 0), px = lastSp > 0 ? lastSp : sellRefPrice();
        if (px > 0 && left * px < MIN_ORDER) {
          log(T("dustSkip", +left.toFixed(6), (left * px).toFixed(4)));
          state.dust = Math.max(0, left);
          return;
        }
        const fe = formHint();
        throw new Error(T("errSellDisabled") + " · " + T("sellDiag", qty, +avail.toFixed(6), lastSp != null ? lastSp : "–", fe || "–"));
      }
      if (placed === "retry") { avail = (await readSellAvailable()) || avail; continue; }
      log(T("sellLog", qty, avail, attempt ? attempt + 1 : 0));
      const tf = Date.now(), isMk = !!(mk && attempt === 0);
      const f = isMk
        ? await waitFilled(cfg.makerWait, () => {
          const lb = liveBook(); const b = lb && lb.bid ? parseFloat(lb.bid) : NaN;
          if (b > 0 && b < mk.stop) { mk.why = T("mkWhyFall"); return true; }
          if (cfg.dzOn && dz.danger && Date.now() - dz.at < 10000) { mk.why = T("mkWhyDanger"); return true; }
          return false;
        })
        : await waitFilled(wait);
      if (isMk) {
        if (f) { mkStat.hit++; log("🎯 " + T("mkHit", mk.txt, ((Date.now() - tf) / 1000).toFixed(1), mkStat.hit, mkStat.try)); }
        else log("↘ " + T("mkMiss2", mk.why || T("mkWhyTime", cfg.makerWait)));
        makerResult(!!f);
        makerTune(!!f, (Date.now() - tf) / 1000, !f && !mk.why);
      }
      else if (f != null && !restPasses) bufFill(f, Date.now() - tf);
      if (f !== false) {
        if (f) log(T("sellFilled"));
        await sleep(600);
        // পূরণের পর হাতে কিছু রয়ে গেলে: মূল্য সর্বনিম্ন Sell-এর বেশি হলে বাকিটাও বিক্রি (সর্বোচ্চ ৩ বার), কম হলে অবশিষ্ট
        const rest = await stableAvail(3000);
        const left = rest - (state.keep || 0);
        const rp = lastSp > 0 ? lastSp : sellRefPrice();
        const worth = rp > 0 ? left * rp : null;
        const big = worth != null ? worth >= MIN_SELL_USDT : left > (parseFloat(qty) || 0) * 0.02;
        if (left > 0 && big && restPasses < 3) {
          restPasses++;
          log(T("sellRest", +left.toFixed(6), worth != null ? worth.toFixed(2) : "?"));
          avail = rest;
          attempt--; // বাকি বিক্রি আলাদা চেষ্টা হিসেবে গোনা হবে না
          continue;
        }
        state.dust = Math.max(0, left);
        return;
      }
      if (!(mk && attempt === 0)) log(T("sellNotFilled", wait));
      await cancelOpenOrders();
      await switchTab("sellTab", "sell");
      await clickOrderType();
      avail = await readSellAvailable();
      if (!hasNew(avail)) { log(T("allSold")); state.dust = Math.max(0, avail - (state.keep || 0)); return; }
    }
    throw new Error(T("errSellFail", tries + 1));
  }

  // ================= বাজারের সূচক (বিপদ-ফিল্টার আর বাজার যাচাইয়ের জন্য) =================
  // Binance-এর ১ মিনিটের ক্যান্ডেল থেকে EMA ৯/২১, RSI ১৪, ATR%, ঢাল, স্প্রেড — ০–১০০ স্কোর
  async function klines1m(limit) {
    try {
      const sym = await getAlphaSymbol();
      if (sym) {
        const r = await fetch(`${BN_API}/alpha-trade/klines?symbol=${encodeURIComponent(sym)}&interval=1m&limit=${limit}`, { credentials: "include" });
        const j = await r.json();
        const rows = Array.isArray(j && j.data) ? j.data : [];
        const out = [];
        for (const x of rows) {
          const a = Array.isArray(x) ? x : [x.openTime ?? x.t, x.open ?? x.o, x.high ?? x.h, x.low ?? x.l, x.close ?? x.c, x.volume ?? x.v];
          let t = +a[0]; if (t > 0 && t < 1e12) t *= 1000;
          const o = +a[1], h = +a[2], l = +a[3], c = +a[4];
          if (t > 0 && o > 0 && h > 0 && l > 0 && c > 0) out.push({ t, o, h, l, c, v: +a[5] || 0 });
        }
        if (out.length >= 25) return out.sort((p, q) => p.t - q.t);
      }
    } catch (_) {}
    return null;
  }
  const ema = (arr, n) => { const k = 2 / (n + 1); let e = arr[0]; const out = [e]; for (let i = 1; i < arr.length; i++) { e = arr[i] * k + e * (1 - k); out.push(e); } return out; };
  function rsi(cl, n = 14) {
    let g = 0, l = 0;
    for (let i = cl.length - n; i < cl.length; i++) { const d = cl[i] - cl[i - 1]; if (d > 0) g += d; else l -= d; }
    if (g + l === 0) return 50;
    return 100 - 100 / (1 + g / Math.max(l, 1e-12));
  }
  const P_TAKE = 0.2; // সংকেত-স্কোরের মাপকাঠি (আগের প্রফিট মোডের লক্ষ্য %) — শুধু বাজার বিচারের জন্য
  async function profitSignal() {
    const k = await klines1m(60);
    const sp = (() => { const lb = liveBook(); const a = lb && lb.ask ? +lb.ask : NaN, b = lb && lb.bid ? +lb.bid : NaN; return a > 0 && b > 0 && a >= b ? ((a - b) / ((a + b) / 2)) * 100 : null; })();
    if (!k) return { score: 0, why: T("pNoData"), ok: false, spread: sp };
    const cl = k.map((x) => x.c), e9 = ema(cl, 9), e21 = ema(cl, 21), n = cl.length - 1;
    const r = rsi(cl, 14);
    const atr = k.slice(-14).reduce((s, x, i, a) => s + (Math.max(x.h, i ? a[i - 1].c : x.o) - Math.min(x.l, i ? a[i - 1].c : x.o)), 0) / 14 / cl[n] * 100;
    const slope = ((e9[n] - e9[n - 3]) / e9[n - 3]) * 100;
    const last = k[n], lastBody = ((last.c - last.o) / last.o) * 100;
    const hi20 = Math.max(...k.slice(-20).map((x) => x.h)), lo20 = Math.min(...k.slice(-20).map((x) => x.l));
    const pos = hi20 > lo20 ? (cl[n] - lo20) / (hi20 - lo20) : 0.5; // ২০ মিনিটের সীমার মধ্যে কোথায়
    let s = 0; const why = [];
    if (e9[n] > e21[n]) { s += 25; why.push("EMA9>21"); } else why.push("EMA9<21");
    if (cl[n] > e9[n]) { s += 10; why.push(T("pAboveEma")); }
    if (slope > 0) { s += 15; why.push(T("pSlopeUp")); } else why.push(T("pSlopeDn"));
    if (r >= 45 && r <= 65) { s += 20; } else if (r >= 38 && r <= 72) s += 10;
    why.push("RSI " + r.toFixed(0));
    if (atr >= P_TAKE * 0.6 && atr <= P_TAKE * 4) { s += 15; } else if (atr < P_TAKE * 0.6) why.push(T("pLowVol"));
    else why.push(T("pHighVol"));
    if (pos < 0.85) s += 10; else why.push(T("pTop"));
    if (lastBody < -P_TAKE) { s -= 20; why.push(T("pBigRed")); }
    if (sp != null) { if (sp > P_TAKE / 2) { s -= 30; why.push(T("pWideSpread", sp.toFixed(3))); } else s += 5; }
    s = Math.max(0, Math.min(100, Math.round(s)));
    return ({ score: s, why: why.join(" · "), ok: s >= 60, lastBody: +lastBody.toFixed(3), k: k.slice(-12), rsi: +r.toFixed(1), atr: +atr.toFixed(3), slope: +slope.toFixed(3), e9: e9[n], e21: e21[n], pos: +pos.toFixed(2), spread: sp, price: cl[n],
      closes: cl.slice(-30).map((v) => +v.toPrecision(6)) });
  }
  let aiLastErr = "";
  // AI কোম্পানি: OpenRouter (ডিফল্ট) বা Groq — প্রতিটার আলাদা key আর মডেল
  const AI_LISTS = {
    // ১৬ আগস্ট ২০২৬ থেকে ফ্রি key-তে Llama মডেল বন্ধ। বাকিগুলো দিনে ১,০০০ অনুরোধ, মিনিটে ৮,০০০ টোকেন;
    // টোকেন/দিন: qwen3.8-27b ২০ লাখ (সবচেয়ে বেশি — তাই আগে), বাকিগুলো ২ লাখ
    groq: ["qwen/qwen3.8-27b", "openai/gpt-oss-20b", "openai/gpt-oss-120b", "qwen/qwen3.6-27b"] };
  const AI_KEYF = { groq: "aiKeyGroq", openrouter: "aiKeyOr" };
  const AI_MODF = { groq: "aiModelGroq", openrouter: "aiModelOr" };
  const AI_NAME = { groq: "Groq", openrouter: "OpenRouter" };
  const aiP = () => (AI_KEYF[cfg.aiProv] ? cfg.aiProv : "openrouter");
  // OpenRouter: ফ্রি মডেলের তালিকা OpenRouter থেকেই নেওয়া (প্রায়ই বদলায়); ফ্রি শেষ হলে (চাইলে) সস্তা পেইড gpt-oss-20b
  const OR_FREE0 = ["google/gemma-4-31b-it:free", "nvidia/nemotron-3-super-120b-a12b:free", "minimax/minimax-m3.1-flash:free", "google/gemma-4-26b-a4b-it:free", "nvidia/nemotron-3.5-lightning:free"];
  const OR_PAID = ["openai/gpt-oss-20b", "openai/gpt-oss-120b"]; // সস্তা আগে; প্রথমটা না চললে দ্বিতীয়টা
  let orFree = OR_FREE0.slice();
  async function orLoad(tell) {
    const r = await bg({ type: "avh-or-models" }, 20000);
    if (r && r.ok && Array.isArray(r.models) && r.models.length) { orFree = r.models.slice(0, 8); try { $("aiModels").innerHTML = aiList().map((m) => `<option value="${m}">`).join(""); } catch (_) {} }
    if (tell) log("🤖 " + T("orModels", orFree.length, orFree.slice(0, 3).join(", ")));
  }
  // শুধু পেইড: ফ্রি মডেলের ধীরগতি/সীমা ছাড়া — দ্রুত ও নির্ভরযোগ্য (প্রতি ডাকে খুব সামান্য খরচ)
  const orList = () => (cfg.orMode === "paid" ? OR_PAID.slice() : orFree.concat(cfg.orPaid ? OR_PAID : []));
  const aiK = () => cfg[AI_KEYF[aiP()]] || "";
  // AI চলে শুধু বিপদে থামো চালু থাকলে, key থাকলে আর AI সুইচ চালু থাকলে
  function aiSync() { cfg.aiOn = !!(cfg.dzOn && cfg.aiWant !== false && aiK()); }
  const aiList = () => (aiP() === "openrouter" ? orList() : AI_LISTS[aiP()]);
  const aiM = () => (aiP() === "openrouter" ? cfg.aiModelOr || aiList()[0] : cfg[AI_MODF[aiP()]] || aiList()[0]);
  const setAiM = (m) => { if (aiP() !== "openrouter") cfg[AI_MODF[aiP()]] = m; }; // OpenRouter-এ সবসময় ফ্রি থেকে শুরু
  // Google মডেল বন্ধ/বদলালে নিজে থেকে পরের মডেলে চেষ্টা, কাজ করলে সেটাই সেভ
  // কোটা শেষ হওয়া মডেল দিনের বাকি সময় (UTC রাত ১২টা পর্যন্ত) বাদ — পরের মডেলে চলে যায়; সব শেষ হলে AI বিশ্রাম, বট নিয়মে চলে
  const aiOut = {}; // model → কখন আবার চেষ্টা
  const utcMidnight = () => { const d = new Date(); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + 1) + 60000; };
  let aiQuotaTold = 0, aiPaidTold = 0;
  async function aiCall(prompt) {
    const cur = aiM(), list = [cur].concat(aiList().filter((m) => m !== cur)).filter((m) => m && !(aiOut[m] > Date.now()));
    if (!list.length) return { ok: false, error: T("aiAllQuota") };
    let r = null;
    for (const m of list) {
      if (aiOut[m] > Date.now()) continue; // এই ঘুরেই বাদ পড়েছে (যেমন OpenRouter-এর ফ্রি সীমা সব মডেলে একসাথে)
      r = (await bg({ type: "avh-ai", prov: aiP(), key: aiK(), model: m, prompt }, 125000)) || { ok: false, error: T("aiNoBg") };
      if (r && r.ok) {
        r.model = m;
        if (aiP() === "openrouter") { if (OR_PAID.includes(m) && cfg.orMode !== "paid" && Date.now() - (aiPaidTold || 0) > 3600000) { aiPaidTold = Date.now(); log("🤖 " + T("orPaidUse", m)); } return r; }
        if (m !== cur) { log("🤖 " + T("aiSwitched", cur, m)); setAiM(m); save(); try { $("aiModel").value = m; } catch (_) {} }
        return r;
      }
      const err = (r && r.error) || "";
      // কোটা/সীমা: দিনের সীমা হলে রাত ১২টা (UTC) পর্যন্ত, মিনিটের সীমা হলে ১ মিনিট এই মডেল বাদ
      // টাকা নেই (OpenRouter 402) — এই মডেল ১ ঘণ্টা বাদ
      if (/402|insufficient credits|credits/i.test(err) && !/free-models/i.test(err)) { aiOut[m] = Date.now() + 3600000; log("🤖 " + T("orNoCredit")); continue; }
      if (/rate.?limit|quota|429|too many|exhausted|tokens per day|requests per day|RPD|TPD/i.test(err)) {
        aiOut[m] = /per.?day|RPD|TPD|daily|quota/i.test(err) ? utcMidnight() : Date.now() + 60000;
        // OpenRouter-এর ফ্রি দৈনিক সীমা সব ফ্রি মডেলে একসাথে — তাই সব ফ্রি মডেল বাদ
        if (aiP() === "openrouter" && /free-models-per-day/i.test(err)) for (const x of orFree) aiOut[x] = utcMidnight();
        if (Date.now() - aiQuotaTold > 600000) { aiQuotaTold = Date.now(); log("🤖 " + T("aiQuota", m)); }
        continue;
      }
      // মডেল বন্ধ/নেই হলে পরের মডেল; key ভুল ইত্যাদি হলে থামো
      if (!/no longer available|not found|is not supported|does not exist|deprecated|decommissioned|unknown model|model_not_found|404/i.test(err)) return r;
      aiOut[m] = Date.now() + 24 * 3600000; // বন্ধ মডেল — আজ আর চেষ্টা নয়
      log("🤖 " + T("aiGone", m));
    }
    return r;
  }
  // ================= দ্রুত বিপদ-ফিল্টার (ভলিউম মোডে) =================
  // পেছনে আলাদাভাবে প্রতি ৪ সে. বাজার দেখে (আর AI চালু থাকলে বাছা সময় পরপর AI-কে জিজ্ঞেস করে) ফল জমিয়ে রাখে;
  // ট্রেডের সময় শুধু জমানো ফল দেখে — AI-র জন্য অপেক্ষা নেই; বিপদ থাকলে তবেই থামে।
  const dz = { danger: false, why: "", at: 0, ai: null, aiAt: 0, aiBusy: false, logged: null, until: 0 };
  const OB_RATIO = 0.25; // কেনার ভাগ এর কম = বিক্রির চাপ
  function dzRule(s) {
    const why = [];
    if (s.e9 < s.e21 && s.slope < 0) why.push(T("dzDown"));
    if (s.lastBody != null && s.lastBody <= -0.1) why.push(T("dzRed", Math.abs(s.lastBody).toFixed(2)));
    if (s.rsi < 35 && s.slope < 0) why.push(T("dzFall", s.rsi));
    if (s.spread != null && s.spread > 0.2) why.push(T("dzSpread", s.spread.toFixed(3)));
    // শেষ ৩টা ১ মি. ক্যান্ডেলের ২টা লাল আর মোট পতন ০.১%-এর বেশি = নামার চাপ
    const k3 = (s.k || []).slice(-3);
    if (k3.length === 3 && k3.filter((x) => x.c < x.o).length >= 2 && (k3[2].c - k3[0].o) / k3[0].o * 100 < -0.1) why.push(T("dzPress"));
    // অর্ডার-বুকের ভারসাম্য: উপরের ৫ ধাপে বিক্রির দিক কেনার ৩ গুণের বেশি, পরপর ২ বার (৮ সে.) = বিক্রির দেয়াল
    if (cfg.obOn !== false) {
      const bd = bookDepth(5);
      dz.ob = bd;
      if (bd && bd.ratio < OB_RATIO && bd.ask >= Math.max(50, (+cfg.amount || 0) * 2)) { dz.obN = (dz.obN || 0) + 1; if (dz.obN >= 2) why.push(T("dzWall", Math.round(bd.ratio * 100))); }
      else dz.obN = 0;
    }
    return why;
  }
  // ১৫ সেকেন্ডের ক্যান্ডেল (খুব কাছের নড়াচড়া দেখতে) — না পেলে null
  async function klines15s(limit) {
    try {
      const sym = await getAlphaSymbol();
      if (!sym) return null;
      const r = await fetch(`${BN_API}/alpha-trade/klines?symbol=${encodeURIComponent(sym)}&interval=15s&limit=${limit}`, { credentials: "include" });
      const j = await r.json();
      const rows = Array.isArray(j && j.data) ? j.data : [];
      const out = rows.map((x) => (Array.isArray(x) ? x : [x.openTime, x.open, x.high, x.low, x.close, x.volume]))
        .map((a) => [+a[1], +a[2], +a[3], +a[4], +a[5] || 0, a[9] != null && isFinite(+a[9]) ? +a[9] : null]).filter((a) => a[3] > 0);
      return out.length >= 8 ? out : null;
    } catch (_) { return null; }
  }

  // অর্ডারবুকের উপরের ৫ ধাপে কেনা বনাম বেচার USDT — Buy দিক বেশি ভারী হলে ratio > 0.5
  function bookDepth(n = 5) {
    try {
      const els = ["bookAsk", "bookBid", "livePrice"].map((k) => (cfg.selectors[k] ? find(k) : null));
      const [askEl, bidEl, midEl] = els, have = els.filter(Boolean);
      if (have.length < 2) return null;
      let root = have[0];
      while (root && !have.every((e) => root.contains(e))) root = root.parentElement;
      if (!root) return null;
      const cy = (e) => { const r = e.getBoundingClientRect(); return r.top + r.height / 2; };
      const splitY = midEl ? cy(midEl) : askEl && bidEl ? (cy(askEl) + cy(bidEl)) / 2 : NaN;
      const lb = liveBook(), ref = lb && lb.mid;
      if (!(ref > 0) || isNaN(splitY)) return null;
      const seen = new Set(), asks = [], bids = [];
      const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = w.nextNode())) {
        const el = node.parentElement;
        if (!el || (midEl && midEl.contains(el))) continue;
        const t = (node.nodeValue || "").trim().replace(/,/g, "");
        if (!/^\d+(\.\d+)?$/.test(t)) continue;
        const v = parseFloat(t);
        if (!(v >= ref * 0.95 && v <= ref * 1.05)) continue;
        // সারি: উপরে উঠে প্রথম যে বাক্সে দাম + পরিমাণ (২–৪টা সংখ্যা) আছে
        let row = null;
        for (let e = el.parentElement, i = 0; e && e !== root && i < 4; e = e.parentElement, i++) { const c = parseNums(e.innerText).length; if (c >= 2 && c <= 4) { row = e; break; } }
        if (!row || seen.has(row)) continue;
        seen.add(row);
        const rr = readRow(row);
        if (!rr || !(rr.usdt > 0)) continue;
        (cy(el) < splitY ? asks : bids).push({ d: Math.abs(v - ref), u: rr.usdt });
      }
      const top = (a) => a.sort((x, y) => x.d - y.d).slice(0, n).reduce((s, x) => s + x.u, 0);
      const a = top(asks), b = top(bids);
      return a + b > 0 ? { ask: Math.round(a), bid: Math.round(b), ratio: +(b / (a + b)).toFixed(2) } : null;
    } catch (_) { return null; }
  }
  // AI বিপদ-বিচার: ১ মি. ও ১৫ সে. ক্যান্ডেল (দাম+ভলিউম), সূচক, স্প্রেড আর বটের নিজের শেষ রাউন্ডগুলোর ফল দিয়ে —
  // উত্তরে বিপদ কিনা, কতটা নিশ্চিত, আর কত সেকেন্ড থামা উচিত
  // ---------- AI-র সঠিকতা: বিপদ বলার পর ৬০ সে.-এ দাম −০.১% নামল কি না (মডেল আর তখনকার সীমা ধরে আলাদা) ----------
  let aiStat = {}, aiPend = [];
  try { chrome.storage.local.get("avhAiStat2", (d) => { if (d && d.avhAiStat2) aiStat = d.avhAiStat2; }); } catch (_) {}
  function aiTrack() {
    const px = +curPrice(), now = Date.now();
    if (!(px > 0)) return;
    let changed = false;
    for (const r of aiPend) { r.min = Math.min(r.min, px); }
    aiPend = aiPend.filter((r) => {
      if (now - r.t < 60000) return true;
      if (now - r.t > 120000) return false;
      const dropped = ((r.min - r.px) / r.px) * 100 <= -0.1, key = r.m + "|" + r.thr;
      const s = aiStat[key] || (aiStat[key] = { n: 0, ok: 0, fa: 0, miss: 0 });
      s.n++; if (r.pred === dropped) s.ok++; else if (r.pred) s.fa++; else s.miss++;
      changed = true; return false;
    });
    if (changed) { try { chrome.storage.local.set({ avhAiStat2: aiStat }); } catch (_) {} }
  }
  function aiLastLine() {
    if (!(cfg.dzOn && cfg.aiOn && aiK()) || !dz.ai || !dz.aiAt || !state.running) return "";
    const ago = Math.round((Date.now() - dz.aiAt) / 1000);
    if (ago > Math.max(120, (+cfg.aiEvery || 15) * 4)) return "";
    return T("aiLast2", ago, dz.ai.danger, dz.ai.conf, dz.ai.reason || "–", String(dz.ai.model || "").split("/").pop());
  }
  function aiStatLine() {
    if (!(cfg.dzOn && cfg.aiOn && aiK())) return "";
    const t = { n: 0, ok: 0, fa: 0, miss: 0 };
    for (const k in aiStat) if (k.endsWith("|" + (+cfg.aiConf))) for (const f in t) t[f] += aiStat[k][f] || 0;
    return t.n >= 5 ? T("aiStatLine", Math.round((t.ok / t.n) * 100), t.n, t.fa, t.miss) : "";
  }
  function aiStatText() {
    const ks = Object.keys(aiStat).filter((k) => aiStat[k].n > 0).sort((a, b) => aiStat[b].n - aiStat[a].n);
    if (!ks.length) return T("aiStatNone");
    return T("aiStatHead3", cfg.aiConf) + "\n" + ks.map((k) => { const s = aiStat[k], [m, thr] = k.split("|"); return T("aiStatRow", m.split("/").pop() + " ≥" + thr + "%", Math.round((s.ok / s.n) * 100), s.n, s.fa, s.miss); }).join("\n");
  }
  async function dzAi(s, now) {
    if (dz.aiBusy) return;
    dz.aiBusy = true; dz.aiTry = Date.now(); dz.aiPx = +curPrice() || null;
    try {
      const k15 = await klines15s(24);
      const rounds = (state.recent || []).slice(-8).map((x) => (x.vol > 0 ? +((x.loss / (x.vol / 2)) * 100).toFixed(3) : 0));
      const f = (v) => +(+v).toPrecision(6);
      const prompt = `You are the risk guard of a bot that does very fast Binance Alpha volume rounds: buy at the best ask, sell ~5-10 s later at the best bid. Each round normally costs ~0.03-0.06% (spread+fees). The bot only loses more when price falls during those seconds.
The bot now buys ONLY when the very short-term trend is up, so also judge if the next 10-60 seconds are BULLISH (price likely flat-to-up right after a buy). A spike that is overextended (RSI very high, far above EMA9, at the top of the range, likely to pull back) is NOT bullish for this purpose.
Decide if the NEXT 30-90 seconds are a DANGER zone (dump, sharp drop, sell pressure, falling knife, liquidity gap) where it should pause. Normal sideways or rising markets are NOT danger — pausing there wastes time.
1-minute candles oldest→newest [open,high,low,close,volume] (last 12): ${JSON.stringify((s.k || []).slice(-12).map((x) => [f(x.o), f(x.h), f(x.l), f(x.c), Math.round(x.v)]))}
15-second candles oldest→newest [open,high,low,close,volume]: ${JSON.stringify((k15 || []).slice(-16).map((a) => [f(a[0]), f(a[1]), f(a[2]), f(a[3]), Math.round(a[4])]))}
Indicators: EMA9=${f(s.e9)} EMA21=${f(s.e21)} RSI14=${s.rsi} ATR14%=${s.atr} EMA9 slope(3m)%=${s.slope} position in 20m range(0-1)=${s.pos} spread%=${s.spread != null ? s.spread.toFixed(4) : "?"} rule-score=${s.score}/100.
Bot's last rounds result in % of trade (positive = loss): ${JSON.stringify(rounds)}.
Answer ONLY JSON: {"danger":true|false,"bullish":true|false,"confidence":0-100,"pause_seconds":0-300,"reason":"short reason in ${cfg.lang === "en" ? "English" : "Bengali"}, max 10 words"}`;
      const r = await aiCall(prompt);
      if (r && r.ok && r.json) {
        const j = r.json;
        dz.ai = { danger: j.danger === true || String(j.danger).toLowerCase() === "true",
          bull: j.bullish == null ? null : j.bullish === true || String(j.bullish).toLowerCase() === "true", conf: Math.max(0, Math.min(100, +j.confidence || 0)),
          pause: Math.max(0, Math.min(300, +j.pause_seconds || 0)), reason: String(j.reason || "").slice(0, 100), model: r.model || aiM() };
        dz.aiAt = Date.now();
        if (dz.aiPx > 0) aiPend.push({ t: Date.now(), px: dz.aiPx, min: dz.aiPx, pred: dz.ai.danger && dz.ai.conf >= cfg.aiConf, thr: +cfg.aiConf, m: dz.ai.model });
        if (dz.ai.danger && dz.ai.conf >= cfg.aiConf) {
          const u = Date.now() + Math.max(20, dz.ai.pause || 45) * 1000;
          if (u > (dz.until || 0)) { dz.until = u; dz.untilWhy = "AI: " + dz.ai.reason; }
        }
      } else if (r && !r.ok) {
        aiLastErr = r.error || "";
        if (Date.now() - (dz.errTold || 0) > 1800000) { dz.errTold = Date.now(); log("🤖 " + T("aiFail", aiLastErr)); }
      }
    } finally { dz.aiBusy = false; }
  }
  // বটের নিজের শেখা: পরপর ৩ রাউন্ডে ট্রেডের ০.১২%-এর বেশি লস হলে ৬০ সে. থামা (বাজার খারাপ যাচ্ছে)
  function lossStreak() {
    const r = (state.recent || []).slice(-3);
    if (r.length < 3) return false;
    return r.every((x) => x.vol > 0 && (x.loss / (x.vol / 2)) * 100 > 0.12);
  }
  let dzSince = 0, dzTold = false;
  async function dangerLoop() {
    for (;;) {
      try {
        if (cfg.dzOn && state.running) {
          const s = await profitSignal();
          if (s && s.closes) {
            const why = dzRule(s);
            aiTrack();
            if (cfg.aiOn && aiK() && Date.now() - (dz.aiTry || 0) > (+cfg.aiEvery || 30) * 1000) dzAi(s); // অপেক্ষা না করে পেছনে
            // আগে থেকে চলা বিরতি (AI বা পরপর লস) — যে কারণে শুরু, সেটাই দেখাও
            if (lossStreak()) { const u = Date.now() + 60000; if (u > (dz.until || 0)) { dz.until = u; dz.untilWhy = T("dzStreak"); } state.recent = []; }
            if (dz.until && Date.now() < dz.until) why.push(dz.untilWhy || T("dzCool"));
            dz.danger = why.length > 0; dz.why = why.join(" · "); dz.at = Date.now();
            const key = dz.danger ? dz.why.split(" · ")[0] : "";
            if (key !== dz.logged) {
              if (dz.danger) log("⚠ " + T("dzOnLog", dz.why));
              else if (dz.logged) log("✅ " + T("dzOffLog"));
              dz.logged = key;
            }
            // অনেকক্ষণ (৩ মি.) বিপদে থেমে থাকলে Telegram-এ একবার খবর
            if (dz.danger) { if (!dzSince) dzSince = Date.now(); if (!dzTold && Date.now() - dzSince > 180000 && tgReady()) { dzTold = true; tgSend("⚠️ " + T("tgDzLong", Math.round((Date.now() - dzSince) / 60000), dz.why)); } }
            else { if (dzTold && tgReady()) tgSend("✅ " + T("dzOffLog")); dzSince = 0; dzTold = false; }
          }
        }
      } catch (_) {}
      await sleep(4000);
    }
  }

  // ================= শুধু বুলিশে Buy =================
  // একসাথে সব শর্ত: চলতি ১ মি. ক্যান্ডেল সবুজ · শেষ বন্ধ ১ মি. লাল নয় · EMA9 ≥ EMA21 ও দাম EMA9-এর উপরে ·
  // শেষ ১৫ সে. ক্যান্ডেল লাল নয় আর তার আগেরটাও লাল নয়
  // ৫.০: "উঠছে, কিন্তু চূড়ায় নয়" — অতিরিক্ত উঠে যাওয়া বাজারে কেনা নয় (প্রফিট মোডের ভালো অংশ)
  const BULL_RSI_MAX = 80;   // RSI এর বেশি = অতিরিক্ত কেনা (একটানা ওঠায় ৭০+ স্বাভাবিক, তাই ৮০)
  const BULL_SPIKE = 0.3;    // চলতি ১ মি. ক্যান্ডেল এর বেশি % সবুজ = হঠাৎ লাফ
  const BULL_EXT = 0.25;     // দাম EMA9-এর এর বেশি % উপরে = গড় থেকে অনেক দূরে
  const BULL_ATR_MAX = 0.6;  // ১ মি. গড় ওঠানামা (ATR%) এর বেশি = খুব অস্থির
  let bullLog = "", bullNoData = false, bullCache = null;
  // শান্ত বাজার: দাম নামছে না, হঠাৎ লাফও নেই, ওঠানামা কম — কেনার পর কয়েক সেকেন্ডে দাম প্রায় একই থাকে
  const ST_RED1 = -0.05;   // চলতি ১ মি. ক্যান্ডেল এর চেয়ে বেশি লাল নয় (%)
  const ST_PREV = -0.1;    // আগের ১ মি. ক্যান্ডেল এর চেয়ে বেশি লাল নয়
  const ST_ATR = 0.35;     // গড় ওঠানামা (ATR%) এর বেশি নয়
  const ST_EXT = 0.25;     // দাম EMA9 থেকে এর বেশি % দূরে নয় (উপরে বা নিচে)
  const ST_RED15 = -0.05;  // শেষ ১৫ সে. ক্যান্ডেল এর চেয়ে বেশি লাল নয়
  async function stableCheck() {
    const why = [];
    const kc = await kFetch(false), k = kc.k1;
    if (!k || k.length < 22) {
      if (!bullNoData) { log("⚠ " + T("bullNoData")); bullNoData = true; }
      return { ok: true, why: "", at: Date.now() };
    }
    bullNoData = false;
    const n = k.length - 1, cur = k[n], prev = k[n - 1], cl = k.map((x) => x.c), e9 = ema(cl, 9), e21 = ema(cl, 21);
    const live = Date.now() - cur.t < 75000, px = +curPrice(), curC = live && px > 0 ? px : cur.c;
    const body = ((curC - cur.o) / cur.o) * 100, pb = ((prev.c - prev.o) / prev.o) * 100;
    if (body < ST_RED1) why.push(T("stFalling", body.toFixed(2)));
    if (body > BULL_SPIKE) why.push(T("bullSpike", body.toFixed(2)));
    if (pb < ST_PREV) why.push(T("bullPrevRed"));
    const slope = ((e9[n] - e9[n - 3]) / e9[n - 3]) * 100;
    if (e9[n] < e21[n] && slope < 0) why.push(T("dzDown"));
    const ext = ((curC - e9[n]) / e9[n]) * 100;
    if (Math.abs(ext) > ST_EXT) why.push(T("stFar", ext.toFixed(2)));
    const r = rsi(cl, 14);
    if (r > BULL_RSI_MAX) why.push(T("bullRsiHigh", r.toFixed(0)));
    if (r < 35) why.push(T("stRsiLow", r.toFixed(0)));
    const atr = (k.slice(-14).reduce((a, x, i, arr) => a + (Math.max(x.h, i ? arr[i - 1].c : x.o) - Math.min(x.l, i ? arr[i - 1].c : x.o)), 0) / 14 / curC) * 100;
    if (atr > ST_ATR) why.push(T("bullWild", atr.toFixed(2)));
    const k15 = kc.k15;
    if (k15 && k15.length >= 2) {
      const a = k15[k15.length - 1], b = k15[k15.length - 2];
      const ab = ((a[3] - a[0]) / a[0]) * 100;
      if (ab < ST_RED15 || (a[3] < a[0] && b[3] < b[0])) why.push(T("bull15Red"));
    }
    return { ok: !why.length, why: why.join(" · "), at: Date.now(), rsi: r };
  }
  async function bullCheck() {
    if (bullCache && Date.now() - bullCache.at < 1500) return bullCache;
    if (cfg.entryMode === "stable") return (bullCache = await stableCheck());
    const why = [];
    const kc = await kFetch(false), k = kc.k1;
    if (!k || k.length < 22) {
      if (!bullNoData) { log("⚠ " + T("bullNoData")); bullNoData = true; }
      return (bullCache = { ok: true, why: "", at: Date.now() });
    }
    bullNoData = false;
    const n = k.length - 1, cur = k[n], prev = k[n - 1], cl = k.map((x) => x.c), e9 = ema(cl, 9), e21 = ema(cl, 21);
    const live = Date.now() - cur.t < 75000, px = +curPrice();
    const curC = live && px > 0 ? px : cur.c; // চলতি ক্যান্ডেলের এখনকার দাম
    if (!live || !(curC > cur.o)) why.push(T("bullCurRed"));
    if (prev.c < prev.o) why.push(T("bullPrevRed"));
    if (e9[n] < e21[n]) why.push("EMA9<21");
    if (curC < e9[n]) why.push(T("bullBelowEma"));
    // অতিরিক্ত উঠে গেছে কি না
    const r = rsi(cl, 14);
    if (r > BULL_RSI_MAX) why.push(T("bullRsiHigh", r.toFixed(0)));
    const body = ((curC - cur.o) / cur.o) * 100;
    if (live && body > BULL_SPIKE) why.push(T("bullSpike", body.toFixed(2)));
    const ext = ((curC - e9[n]) / e9[n]) * 100;
    if (ext > BULL_EXT) why.push(T("bullExt", ext.toFixed(2)));
    const l20 = k.slice(-20), hi20 = Math.max(...l20.map((x) => x.h)), lo20 = Math.min(...l20.map((x) => x.l));
    const pos = hi20 > lo20 ? (curC - lo20) / (hi20 - lo20) : 0.5;
    if (pos > 0.97 && r > 75) why.push(T("bullTop")); // চূড়ায় আর RSI-ও বেশি — শুধু তখন
    const atr = (k.slice(-14).reduce((a, x, i, arr) => a + (Math.max(x.h, i ? arr[i - 1].c : x.o) - Math.min(x.l, i ? arr[i - 1].c : x.o)), 0) / 14 / curC) * 100;
    if (atr > BULL_ATR_MAX) why.push(T("bullWild", atr.toFixed(2)));
    const k15 = kc.k15;
    if (k15 && k15.length >= 2) {
      const a = k15[k15.length - 1], b = k15[k15.length - 2];
      if (a[3] < a[0] || b[3] < b[0]) why.push(T("bull15Red"));
    }
    if (cfg.aiOn && aiK() && dz.ai && dz.ai.bull === false && Date.now() - dz.aiAt < Math.max(45, (+cfg.aiEvery || 30) * 1.5) * 1000 && dz.ai.conf >= cfg.aiConf) why.push("AI: " + (dz.ai.reason || T("bullAiNo")));
    return (bullCache = { ok: !why.length, why: why.join(" · "), at: Date.now(), rsi: r });
  }
  async function bullGate() {
    if (cfg.entryMode === "off") return false;
    const r = await bullCheck(), st = cfg.entryMode === "stable";
    if (r.ok) { if (bullLog) { log("🟢 " + T(st ? "stOkLog" : "bullOkLog")); bullLog = ""; } return false; }
    const key = r.why.split(" · ")[0];
    if (key !== bullLog) { log("⏳ " + T(st ? "stWaitLog" : "bullWaitLog", r.why)); bullLog = key; }
    setStatus("wait", T(st ? "stStWait" : "stBull", r.why));
    // এখানেই প্রতি ২ সে. দেখা (সর্বোচ্চ ৬০ সে.); মিলে গেলে আর বিপদ/বেশি স্প্রেড না থাকলে সাথে সাথে Buy
    const t0 = Date.now();
    while (!stopFlag && !paused && Date.now() - t0 < 60000) {
      wd(); await sleep(2000);
      if (stopFlag || paused || dzNow()) return true;
      const r2 = await bullCheck();
      if (r2.ok) {
        if (!spreadOkNow()) return true;
        log("🟢 " + T(st ? "stOkLog" : "bullOkLog")); bullLog = "";
        return false;
      }
      const k2 = r2.why.split(" · ")[0];
      if (k2 !== bullLog) { log("⏳ " + T(st ? "stWaitLog" : "bullWaitLog", r2.why)); bullLog = k2; setStatus("wait", T(st ? "stStWait" : "stBull", r2.why)); }
    }
    return true;
  }

  // ================= মেকার Sell: স্প্রেড বাঁচানো =================
  // Buy-এর পর সাথে সাথে সেরা Buy দামে (bid) না বেচে সেরা Sell দামে (ask) লিমিট বসিয়ে কয়েক সেকেন্ড অপেক্ষা —
  // অন্য কেউ কিনলেই পূরণ, তাতে স্প্রেডের খরচ লাগে না (দাম উঠলে লাভও)। দাম Buy দামের নিচে স্টপে নামলে বা সময় শেষে বাতিল করে সাধারণ লাইভ Sell।
  // নিয়ম: ১) Sell-এর মুহূর্তে বাজার এখনো বুলিশ, বিপদ নেই, আর স্প্রেড অন্তত ০.০২% (নইলে বাঁচানোর কিছু নেই) — তবেই মেকার
  // ২) অপেক্ষার সময় প্রতি আধা সেকেন্ডে দেখা: সেরা Buy দাম কেনার মুহূর্তের চেয়ে এক ঘরও নামলে, বা বিপদ এলে, সাথে সাথে সাধারণ Sell
  // ৩) শেষ ১০ চেষ্টার মধ্যে (কমপক্ষে ৬টা) ৪০%-এর কম পূরণ হলে ১৫ মিনিট মেকার নিজে বন্ধ, তারপর আবার চেষ্টা
  const MK_MIN_SPREAD = 0.02;
  let sellOverride = null, mkStat = { try: 0, hit: 0 }, mkHist = [], mkPauseUntil = 0, mkSkipWhy = "";
  function makerPlan() {
    mkSkipWhy = "";
    if (!cfg.makerSell || !isLive() || !(state.buyRef > 0)) return null;
    if (mkPauseUntil > Date.now()) return null;
    const lb = liveBook();
    const ask = lb && lb.ask ? parseFloat(lb.ask) : NaN, bid = lb && lb.bid ? parseFloat(lb.bid) : NaN;
    if (!(ask > 0) || !(bid > 0) || ask < bid) return null;
    const sp = ((ask - bid) / ((ask + bid) / 2)) * 100;
    const ref = state.buyBid > 0 ? state.buyBid : bid;
    if (bid < ref) { mkSkipWhy = T("mkSkipFall"); return null; }
    if (sp < MK_MIN_SPREAD) { mkSkipWhy = T("mkSkipSpread", sp.toFixed(3)); return null; }
    if (cfg.dzOn && dz.danger && Date.now() - dz.at < 30000) { mkSkipWhy = T("mkSkipDanger"); return null; }
    if (cfg.entryMode !== "off" && bullCache && Date.now() - bullCache.at < 6000 && !bullCache.ok) { mkSkipWhy = T("mkSkipBull"); return null; }
    const dec = (String(lb.ask).split(".")[1] || "").length;
    const p = Math.max(ask, state.buyRef);
    return { txt: p.toFixed(dec), px: p, stop: ref };
  }
  function makerResult(hit) {
    mkLastRound = !!hit;
    mkHist = mkHist.concat([hit]).slice(-10);
    const h = mkHist.filter(Boolean).length;
    if (mkHist.length >= 6 && h / mkHist.length < 0.4) {
      mkPauseUntil = Date.now() + 15 * 60000;
      const msg = T("mkAutoOff", h, mkHist.length);
      mkHist = [];
      log("⏸ " + msg);
      if (tgReady()) tgSend("⏸ " + msg);
    }
  }

  // মেকারের অপেক্ষার সময় নিজে ঠিক করা: সময় শেষে না-পূরণ বেশি হলে ১ সে. বাড়াও (সর্বোচ্চ ১০),
  // প্রায় সব দ্রুত পূরণ হলে ১ সে. কমাও (সর্বনিম্ন ২) — শেষ ১২টা চেষ্টা দেখে, প্রতি ৪টা নতুন ফলের পর
  let mkT = [], mkTuneN = 0;
  function makerTune(hit, sec, timeout) {
    if (!cfg.makerAuto) return;
    mkT = mkT.concat([{ hit, sec, timeout }]).slice(-12);
    if (mkT.length < 8 || ++mkTuneN < 4) return;
    mkTuneN = 0;
    const nn = mkT.length, hits = mkT.filter((x) => x.hit), to = mkT.filter((x) => x.timeout).length, w = +cfg.makerWait;
    let nw = w;
    if (to / nn >= 0.3 && w < 10) nw = w + 1;
    else if (hits.length / nn >= 0.7 && w > 2) {
      const s = hits.map((x) => x.sec).sort((a, b) => a - b), p80 = s[Math.min(s.length - 1, Math.floor(s.length * 0.8))];
      if (p80 <= w - 1.5) nw = w - 1;
    }
    if (nw === w) return;
    cfg.makerWait = nw; save(false);
    try { $("makerWait").value = nw; } catch (_) {}
    log("⏱ " + T("mkTune", w, nw, hits.length, nn, to));
    mkT = []; mkTuneN = 0; // নতুন সময়ে আবার শুরু থেকে মাপা
  }
  function spreadOkNow() {
    const lim = spreadLimit();
    if (lim == null) return true;
    const lb = liveBook();
    const a = lb && lb.ask ? parseFloat(lb.ask) : NaN, b = lb && lb.bid ? parseFloat(lb.bid) : NaN;
    if (!(a > 0 && b > 0 && a >= b)) return true;
    return ((a - b) / ((a + b) / 2)) * 100 <= lim;
  }
  const dzNow = () => cfg.dzOn && dz.danger && Date.now() - dz.at < 30000;
  // বিপদ চলাকালে এখানেই অপেক্ষা (সর্বোচ্চ ৬০ সে.) — প্রতি ২–৩ সে.-এ ট্যাব বদল/ব্যালেন্স পড়ার পুরো চক্র নয়
  async function dangerWait() {
    if (!dzNow()) return false;
    setStatus("wait", T("stDanger", dz.why));
    const t0 = Date.now();
    while (!stopFlag && !paused && dzNow() && Date.now() - t0 < 60000) { wd(); await sleep(1000); }
    return true; // চক্র আবার শুরু থেকে (ব্যালেন্স, স্প্রেড নতুন করে)
  }

  // ---------- রিলোডের পর আবার চালু করার জন্য চলমান অবস্থা সেভ ----------
  // active=true: চলছে (রিলোড হলে নিজে আবার চালু হবে) · false: থেমেছে, পরের ▶-এ এখান থেকে চলবে · done: টার্গেট শেষ
  function saveRun(active, done = false) {
    const snap = done ? { active: false, done: true } : { active, ts: Date.now(), volume: state.volume, trades: state.trades, startBal: state.startBal,
      lastBal: state.lastBal, totalLoss: state.totalLoss, lossOffset: state.lossOffset, dust: state.dust, keep: state.keep || 0, runStart: state.runStart || Date.now(), unk: state.unk || 0 };
    progSnap = snap;
    chrome.storage.local.set({ avhRun: snap });
  }
  function canContinue() {
    const p = progSnap;
    if (!p || p.done || !(p.volume > 0) || p.volume >= cfg.target - 1e-6) return false;
    return true;
  }

  // ---------- মূল লুপ ----------
  // শুরু করা যাবে কিনা — না গেলে কারণ, গেলে null
  function preflight() {
    if (cfg.dzOn && cfg.aiOn && !aiK()) return "⚠ " + T("aiNoKey");
    if (mustUpdate()) { renderUpd(); return "⛔ " + T("updMust", MY_VER, verInfo.min); }
    if (!cfg.tgSChat) { setTimeout(() => { try { $("who").classList.add("blink"); setTimeout(() => $("who").classList.remove("blink"), 3000); } catch (_) {} }, 0); return "⚠ " + T("tgMust"); }
    const missing = KEYS.filter((k) => !OPTIONAL.has(k) && !cfg.selectors[k]);
    if (missing.length) return T("needSelect", missing.map(LBL).join(", "));
    if (!(cfg.amount > 0) || !(cfg.target > 0)) return T("needAmount");
    if (isLive() && !cfg.selectors.priceInput) return T("needLivePrice");
    if (isLive() && !(cfg.selectors.openOrders && cfg.selectors.cancelAll)) return T("needLiveOrders");
    if (isLive() && !cfg.selectors.bookAsk && !cfg.selectors.bookBid && !cfg.selectors.livePrice) return T("needLiveSrc");
    return null;
  }
  async function recoverAfterError() {
    for (let t = 0; t < cfg.retryWait * 4 && !stopFlag; t++) await sleep(250);
    if (stopFlag) return null;
    try {
      if (cfg.selectors.openOrders && cfg.selectors.cancelAll && readOpenCount() !== 0) { log(T("retryCancel")); await cancelOpenOrders(); }
      await switchTab("sellTab", "sell");
      await clickOrderType();
      const held = await readSellAvailable();
      if (hasNew(held)) {
        log(T("retrySellHeld", +(held - (state.keep || 0)).toFixed(6)));
        await doSell();
        await settleOrders();
        if (state.pendingSell) {
          if (cfg.countSell) state.volume += state.pendingSell;
          state.trades++;
          reportPush({ type: "sell", vol: cfg.countSell ? state.pendingSell : 0, trades: 1, price: state.sellPx || "" });
        }
      }
      state.pendingSell = 0;
      saveRun(true);
      renderProgress();
      log(T("retryGo"));
      return null;
    } catch (e2) {
      return e2;
    }
  }
  let runLockRelease = null;
  // পেছনের/মিনিমাইজ ট্যাবে চললে একবার জানাও
  document.addEventListener("visibilitychange", () => { if (document.hidden && state.running) log("🌙 " + T("bgMode")); });
  // সময় ধরে থামা: stopAt "HH:MM" — আজ পেরিয়ে গেলে কালকের সেই সময়
  function stopAtTs() {
    if (!/^\d{2}:\d{2}$/.test(cfg.stopAt || "")) return 0;
    const [h, m] = cfg.stopAt.split(":").map(Number), d = new Date();
    d.setHours(h, m, 0, 0);
    if (d.getTime() <= Date.now() + 30000) d.setDate(d.getDate() + 1);
    return d.getTime();
  }
  let openAskAt = 0;
  async function run(opts = {}) {
    if (state.running || starting) return;
    const why = preflight();
    if (why) return log(why);
    starting = true;
    let got;
    try { got = await acquireLock(); } finally { starting = false; }
    if (!got || state.running) return log(T("otherTab"));
    if (cfg.lossOn && cfg.maxLoss > 0 && !cfg.selectors.balanceText) log(T("warnNoBal"));
    if (cfg.selectors.openOrders && !cfg.selectors.cancelAll) log(T("warnNoCancel"));

    const rs = opts.resume;
    const cont = !rs && canContinue() ? progSnap : null;
    if (rs) {
      state = { running: true, volume: rs.volume, trades: rs.trades, startBal: rs.startBal, lastBal: rs.lastBal, totalLoss: rs.totalLoss,
        lossOffset: rs.lossOffset || 0, dust: rs.dust || 0, keep: rs.keep || 0, t0: Date.now(), v0: rs.volume, runStart: rs.runStart || Date.now(), resumed: true, unk: rs.unk || 0, unkAt: rs.unk ? Date.now() - 60000 : 0 };
    } else if (cont) {
      // আগের থামা জায়গা থেকে: ভলিউম চলবে, আর প্রথমবারের শুরুর ব্যালেন্স থেকেই মোট লস হিসাব হবে
      // (পুরনো ভার্সনের সেভে lossOffset থাকলে আসল শুরুর ব্যালেন্স = startBal + lossOffset)
      const firstBal = cont.startBal != null ? +(cont.startBal + (cont.lossOffset || 0)).toFixed(6) : null;
      state = { running: true, volume: cont.volume, trades: cont.trades, startBal: firstBal, lastBal: null,
        totalLoss: cont.totalLoss != null ? cont.totalLoss : null, lossOffset: firstBal != null ? 0 : (cont.totalLoss || 0), dust: 0,
        t0: Date.now(), v0: cont.volume };
    } else {
      state = { running: true, volume: 0, trades: 0, startBal: null, lastBal: null, totalLoss: null, lossOffset: 0, dust: 0,
        t0: Date.now(), v0: 0 };
    }
    stopFlag = false;
    paused = false; pausedMs = 0;
    // মিনিমাইজ/পেছনের ট্যাবে Chrome যেন পেজ "ফ্রিজ" না করে — চলার সময় একটা Web Lock ধরে রাখো
    try { if (navigator.locks && !runLockRelease) navigator.locks.request("avh-running", () => new Promise((res) => { runLockRelease = res; })); } catch (_) {}
    state.recent = []; state.lastAmt = 0; liveWarned = false; state.lossSent = 0;
    sp = { lvl: 0, snaps: [], lvlVol: 0, per: null }; ptPlan = null; wd(); mkStat = { try: 0, hit: 0 }; mkHist = []; mkPauseUntil = 0; bullLog = ""; mkT = []; mkTuneN = 0; dz.obN = 0;
    state.l0 = state.totalLoss || 0;
    if (!state.runStart) state.runStart = Date.now();
    state.balStep = 0; state.stopAtTs = stopAtTs();
    if (cfg.stopAfter > 0 || state.stopAtTs) log("⏰ " + T("timeStopPlan", cfg.stopAfter > 0 ? cfg.stopAfter : 0, state.stopAtTs ? cfg.stopAt : ""));
    $("start").disabled = true;
    $("reset").disabled = true;
    renderPause();
    setTimeout(() => statePush(true), 3000);
    log(rs ? T("resumeFrom", state.volume.toFixed(2), cfg.target)
      : cont ? T("continueFrom", state.volume.toFixed(2), cfg.target)
      : T("startLog", cfg.amount, cfg.amountJitter, cfg.target));
    const est = estLine(state.volume);
    if (est) log(est);
    if (tgReady()) tgSend(T("tgStartMsg", state.volume.toFixed(0), cfg.target, cfg.amount, cfg.amountJitter) + (est ? "\n" + est : ""));
    renderProgress();
    saveRun(true);
    setStatus("run", T("stStart"));

    let endReason = "", isError = false, targetReached = false, ptHit = false, healWhy = "";
    try {
      if (rs) {
        if (cfg.selectors.openOrders && readOpenCount() !== 0) { log(T("resumeOpen")); await cancelOpenOrders(); }
        await switchTab("sellTab", "sell");
        await clickOrderType();
        const held = await readSellAvailable();
        if (hasNew(held)) {
          log(T("resumeHeld", +(held - (state.keep || 0)).toFixed(6)));
          await doSell();
          state.trades++;
          renderProgress();
          saveRun(true);
        }
      } else {
        await switchTab("sellTab", "sell");
        await clickOrderType();
        const initial = await readSellAvailable();
        state.keep = 0; state.dust = 0;
        if (cfg.heldMode === "keep") {
          // আগের রান থেকে চালিয়ে গেলে আগের "রাখা" পরিমাণ, নতুন শুরুতে এখন হাতে যা আছে সব রাখা হবে
          state.keep = cont && cont.keep != null ? Math.min(cont.keep, initial) : initial;
          state.dust = Math.max(0, initial - state.keep);
          if (state.keep > 0) log(T("keepLog", state.keep));
        } else if (initial > 0) {
          // শুরুর আগে হাতে থাকা টোকেন বিক্রি — মূল্য ১ USDT-র কম হলে (অবশিষ্ট গুঁড়া) বাদ
          let px = null;
          if (isLive()) { const lb = liveBook(); px = lb && lb.bid ? parseFloat(lb.bid) : null; }
          else if (cfg.selectors.suggestPrice) px = readNum(find("suggestPrice"));
          if (px > 0 && initial * px < 1) {
            state.dust = initial;
            log(T("heldTiny", initial));
          } else {
            log(T("heldSellLog", initial));
            try {
              await doSell();
              await settleOrders();
              log(T("heldSold"));
            } catch (e) {
              log(T("heldSellFail", e.message));
              if (cfg.selectors.openOrders && readOpenCount() !== 0 && cfg.selectors.cancelAll) await cancelOpenOrders();
              await switchTab("sellTab", "sell");
              state.dust = await readSellAvailable();
            }
          }
        }
        saveRun(true);
      }

      // ২) শুরুতে অন্য খোলা অর্ডার (হয়তো নিজে হাতে দেওয়া) — না জিজ্ঞেস করে বাতিল নয়; ২ মিনিটের মধ্যে আবার ▶ চাপলে বাতিল করে চালু
      if (!rs && cfg.selectors.openOrders && readOpenCount() > 0) {
        await settleOrders(8000);
        const n = readOpenCount();
        if (n > 0) {
          if (Date.now() - openAskAt < 120000 && cfg.selectors.cancelAll) { openAskAt = 0; log(T("openCancelOk", n)); await cancelOpenOrders(); }
          else { openAskAt = Date.now(); const e = new Error(T("openAsk", n)); e.fatal = true; throw e; }
        }
      }
      let errStreak = 0;
      state.pendingSell = 0;
      while (!stopFlag && state.volume < cfg.target - 1e-6) {
        wd();
        if (paused) { await waitWhilePaused(); if (stopFlag) break; }
        if ((cfg.stopAfter > 0 && Date.now() - state.runStart >= cfg.stopAfter * 60000) || (state.stopAtTs && Date.now() >= state.stopAtTs)) {
          endReason = T("timeStop", cfg.stopAfter > 0 && Date.now() - state.runStart >= cfg.stopAfter * 60000 ? T("timeStopAfter", cfg.stopAfter) : T("timeStopAt", cfg.stopAt));
          log("⏰ " + endReason);
          if (tgReady()) tgSend("⏰ " + endReason);
          break;
        }
        // পয়েন্টের ধাপ: পরিকল্পনা (দিন/টার্গেট বদলালে নতুন করে), ধাপ পূর্ণ হলে থামো
        if (cfg.ptOn) {
          if (!ptPlan || ptPlan.d !== utcDay() || ptPlan.tgt !== cfg.target || ptPlan.m !== (+cfg.ptMult || 1)) {
            const p = makePtPlan();
            if (p && !p.none) log("🏅 " + T("ptPlanLog", p.top, fmtK(Math.max(0, (p.stopBuy - ptBuy()) * 2)), p.skip >= 1 ? fmtK(p.skip) : ""));
          }
          if (ptPlan && (ptPlan.none || ptBuy() >= ptPlan.stopBuy - 1e-6)) {
            const i = ptInfo();
            ptHit = true;
            endReason = ptPlan.none ? T("ptNone", i.pts, i.next, fmtK(i.needVol)) : T("ptDone", ptPlan.top);
            log("🏅 " + endReason);
            break;
          }
        } else ptPlan = null;
        try {
          const amt = pickAmount();
          if (!(await marketOk(amt))) continue;

          await switchTab("buyTab", "buy");
          await sleep(300);
          await settleOrders();
          // একই রাউন্ডের লস একবারই দেখাও/পাঠাও (অপেক্ষার সময় লুপ ঘুরলে "রাউন্ড N লস 0" বারবার নয়)
          const rl = state.trades && state.balAt !== state.trades ? T("roundN", state.trades) : "";
          await updateBalance(rl);
          if (rl) { state.balAt = state.trades; costEval(); if (state.trades % 10 === 0) statePush(true); }
          if (cfg.lossOn && cfg.maxLoss > 0 && state.totalLoss != null && effLoss() >= cfg.maxLoss && await lossConfirmed()) {
            endReason = T("lossLimit", fmt(effLoss())) + (state.unk > 0 ? " · " + T("unkPart", state.unk.toFixed(4)) : "");
            isError = true;
            log("🛑 " + endReason);
            break;
          }
          if (await speedGate()) continue;
          if (cfg.dzOn && (await dangerWait())) continue;
          if (await bullGate()) continue;

          // USDT ব্যালেন্স অ্যামাউন্টের চেয়ে কম হলে Buy না দিয়ে পরিষ্কার কারণ দেখিয়ে থামো
          if (state.lastBal != null && amt > state.lastBal) { const e = new Error(T("errLowBal", amt, state.lastBal)); e.fatal = true; throw e; }
          const got = await doBuy(amt);
          state.lastAmt = got;
          state.volume += got;
          state.pendingSell = got;
          reportPush({ type: "buy", vol: got, trades: 0, price: state.buyPx || "" });
          renderProgress();
          saveRun(true);

          await doSell({ maker: true }); // Buy-এর পর বিরতি ছাড়াই; থামানোর অনুরোধ এলেও বিক্রি করে তবেই থামবে
          if (cfg.countSell) state.volume += got;
          reportPush({ type: "sell", vol: cfg.countSell ? got : 0, trades: 1, price: state.sellPx || "" });
          lastTradeAt = Date.now(); idleWarned = false;
          state.pendingSell = 0;
          state.trades++;
          errStreak = 0;
          saveRun(true);
          log(T("totalVol", state.volume.toFixed(2)));
          renderProgress();
          if (state.volume < cfg.target - 1e-6 && !stopFlag) { setStatus("run", T("stDelay")); await randDelay(); }
        } catch (e) {
          // এররের পর নিজে আবার চেষ্টা: খোলা অর্ডার বাতিল, হাতে থাকা টোকেন বিক্রি, তারপর আবার রাউন্ড
          // গুছিয়ে নেওয়া (বিক্রি) ব্যর্থ হলে নতুন Buy নয় — আগে হাতের টোকেন বিক্রি হতে হবে
          if (e.fatal || stopFlag || !cfg.retryOn) throw e;
          let lastErr = e;
          while (!stopFlag) {
            wd();
            if (errStreak >= cfg.retryMax) throw lastErr;
            errStreak++;
            log("⚠️ " + T("retryLog", lastErr.message, errStreak, cfg.retryMax, cfg.retryWait));
            setStatus("wait", T("stRetry", errStreak, cfg.retryMax));
            const r = await recoverAfterError();
            if (!r) break;
            lastErr = r;
          }
        }
      }
      if (state.volume >= cfg.target - 1e-6) {
        targetReached = true;
        endReason = T("targetDone", cfg.target);
        log("✅ " + endReason);
      } else if (ptHit) {
        targetReached = true;
      } else if (stopFlag && !endReason) {
        endReason = T("stopped");
        log("■ " + endReason);
      }
    } catch (err) {
      isError = true;
      endReason = T("errPrefix") + err.message;
      if (cfg.selAuto !== false && /খুঁজে|not found|পাওয়া যায়নি/i.test(String(err.message))) selPull(true); // বাটন না পেলে সবার জন্য রাখা সর্বশেষ তথ্য
      // এরর হলেও (কম ব্যালেন্সের মতো আসল কারণ ছাড়া) পেজ রিলোড করে নিজে আবার চালানো
      if (!stopFlag && !unloading && loggedOut()) {
        // লগআউট: রিলোডে লাভ নেই — পরিষ্কার কারণ দেখিয়ে থামো, ফোনে জানাও
        endReason = T("healLogout"); evSend("🔒 " + endReason);
        log("🔒 " + endReason);
        if (tgReady()) tgSend("🔒 " + endReason);
      } else if (cfg.healOn && !err.fatal && !stopFlag && !unloading) { healWhy = err.message; log("⚠️ " + T("healErr", err.message)); }
      else log("❌ " + endReason + T("errSuffix"));
    } finally {
      if (cfg.selectors.balanceText && state.startBal != null) {
        try {
          await sleep(1500);
          await settleOrders();
          await switchTab("buyTab", "buy");
          // শেষ Sell দেরিতে পূরণ হলে টাকা ফেরা পর্যন্ত (সর্বোচ্চ ৩০ সে.) অপেক্ষা করে তারপর শেষ হিসাব
          const before = state.lastBal;
          for (let i = 0; i < 10; i++) {
            await sleep(3000);
            const b = await readUsdt();
            if (b != null && before != null && before - b < cfg.amount * 0.5) break;
          }
          await updateBalance(T("lastRound"));
          log(T("endBal", state.lastBal, fmt(-(state.totalLoss || 0))));
        } catch (_) {}
      }
      // এই রানের গড় লস শিখে রাখো (পরের বার আনুমানিক খরচ দেখানোর জন্য)
      const sv = state.volume - state.v0, sl = state.totalLoss != null ? state.totalLoss - (state.l0 || 0) : null;
      if (sv >= cfg.amount && sl != null && sl >= 0 && sl < sv * 0.05) {
        cfg.histVol += sv; cfg.histLoss += sl;
        if (cfg.histVol > 500000) { cfg.histVol /= 2; cfg.histLoss /= 2; }
        save(false);
      }
      state.running = false;
      try { chrome.runtime.sendMessage({ type: "avh-wd", on: false }, () => void chrome.runtime.lastError); } catch (_) {}
      releaseLock();
      try { if (runLockRelease) { runLockRelease(); runLockRelease = null; } } catch (_) {}
      if (paused) { paused = false; }
      $("start").disabled = false;
      $("reset").disabled = false;
      renderPause();
      if (!unloading) saveRun(false, targetReached);
      setStatus(targetReached ? "done" : isError ? "err" : "idle", targetReached ? (ptHit ? endReason : T("targetDone", cfg.target)) : isError ? endReason : "");
      renderProgress();
      if (!targetReached && state.volume > 0) log(T("savedForNext", state.volume.toFixed(2), cfg.target));
      setTimeout(() => statePush(true), 2000);
      const lossTxt = plText(state.totalLoss);
      // রাউন্ডের লস আগেই গেছে — রান শেষে শুধু বাকিটুকু (যদি থাকে)
      if (state.volume - state.v0 > 0) {
        // রাউন্ডের লস/লাভ আগেই গেছে — বাকি কিছু থাকলে শুধু সেটুকু (profit/loss), না থাকলে কোনো সারি না
        const rest = state.totalLoss != null ? +(state.totalLoss - (state.l0 || 0) - (state.lossSent || 0)).toFixed(6) : 0;
        if (Math.abs(rest) >= 0.000001) reportPush({ type: rest < 0 ? "profit" : "loss", vol: 0, trades: 0, loss: rest });
      }
      if (healWhy && !unloading) {
        // নিজে সারানো: রিলোড; না পারলে (লগআউট/ঘণ্টায় ৩ বার) সাধারণ এরর বার্তা
        heal(healWhy).then((ok) => { if (!ok) { notify(T("notifTitleErr"), T("notifEnd", endReason, state.volume.toFixed(0), cfg.target, lossTxt), { error: true }); evSend("❌ " + endReason); } });
      } else notify(isError ? T("notifTitleErr") : "Alpha Volume Helper",
        T("notifEnd", endReason || T("done"), state.volume.toFixed(0), cfg.target, lossTxt), { error: isError, done: targetReached });
      if (isError && !unloading && !healWhy && endReason !== T("healLogout")) evSend("❌ " + endReason);
    }
  }

  // ================= 📰 Alpha News =================
  // শুধু Binance-এর নিজের উৎস: ১) Binance ঘোষণা (এয়ারড্রপ, TGE, Alpha, Wallet, Booster, HODLer…) ২) Binance Alpha-র টোকেন তালিকায় নতুন টোকেন
  // Binance ট্যাব খোলা থাকলে প্রতি ৫ মিনিটে দেখে (একাধিক ট্যাব খোলা থাকলেও একবারই); প্রথমবার শুধু তালিকা ভরে, পুরনো খবরে সতর্ক করে না
  const AIR_RE = /airdrop|\btge\b|pre-tge|booster|binance alpha|alpha points|binance wallet|web3 wallet|agentic|hodler|launchpool|megadrop|launchpad/i;
  const AIR_EVERY = 5 * 60000;
  const AIR_CMS = ["/bapi/apex/v1/public/apex/cms/article/list/query?type=1&pageNo=1&pageSize=20", "/bapi/composite/v1/public/cms/article/list/query?type=1&pageNo=1&pageSize=20"];
  let air = { list: [], at: 0, err: "", unread: 0, busy: false };
  async function airCms() {
    for (const u of AIR_CMS) {
      try {
        const r = await fetch(u, { credentials: "include" });
        if (!r.ok) continue;
        const j = await r.json();
        const cats = (j && j.data && (j.data.catalogs || j.data.list)) || [];
        if (!Array.isArray(cats) || !cats.length) continue;
        const out = [];
        for (const ct of cats) for (const a of ct.articles || []) {
          if (!a || !a.title || !AIR_RE.test(a.title)) continue;
          out.push({ id: "a" + (a.id || a.code), t: String(a.title).slice(0, 200), ts: +a.releaseDate || +a.publishDate || 0, src: ct.catalogName || "Binance",
            url: a.code ? `https://www.binance.com/en/support/announcement/detail/${encodeURIComponent(a.code)}` : `https://www.binance.com/en/support/announcement` });
        }
        return out;
      } catch (_) {}
    }
    return null;
  }
  async function airToks() {
    try {
      const r = await fetch(BN_API + "/wallet-direct/buw/wallet/cex/alpha/all/token/list", { credentials: "include" });
      const j = await r.json();
      const list = Array.isArray(j && j.data) ? j.data : (j && j.data && Array.isArray(j.data.list) ? j.data.list : []);
      return list.filter((t) => t && t.alphaId != null && t.alphaId !== "").map((t) => ({ id: String(t.alphaId), sym: t.symbol || t.tokenSymbol || t.name || String(t.alphaId), name: t.name || "", chain: t.chainName || t.chainId || "" }));
    } catch (_) { return null; }
  }
  function airRender() {
    try {
      $("airBadge").hidden = $("mdot").hidden = !(air.unread > 0);
      $("airBadge").textContent = air.unread > 9 ? "9+" : String(air.unread || "");
      $("airSt").textContent = !cfg.airOn ? T("airOff") : air.err ? "⚠ " + air.err : air.at ? T("airLast", new Date(air.at).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }), air.list.length) : T("airWait");
      $("airList").innerHTML = air.list.length ? air.list.slice(0, 40).map((x) =>
        `<a class="air${x.isNew ? " new" : ""}" href="${x.url}" target="_blank" rel="noopener noreferrer"><b></b><small></small></a>`).join("") : `<div class="note">${T("airNone")}</div>`;
      [...$("airList").querySelectorAll("a.air")].forEach((a, i) => { const x = air.list[i]; a.querySelector("b").textContent = x.t; a.querySelector("small").textContent = (x.src || "") + (x.ts ? " · " + new Date(x.ts).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }) : ""); });
    } catch (_) {}
  }
  // পাতা খুললে লাল সংখ্যা মোছে; "নতুন" চিহ্ন থাকে পাতা বন্ধ করা পর্যন্ত
  function airSeenAll(clearNew) {
    if (!air.unread && !(clearNew && air.list.some((x) => x.isNew))) return;
    air.unread = 0; if (clearNew) air.list.forEach((x) => { x.isNew = false; });
    chrome.storage.local.get("avhAir", (d) => { const s = d.avhAir || {}; s.list = air.list; s.unread = 0; chrome.storage.local.set({ avhAir: s }); });
    airRender();
  }
  async function airCheck(force) {
    if (air.busy || (!cfg.airOn && !force)) return;
    air.busy = true;
    try {
      const s = (await lget("avhAir")).avhAir || {};
      if (!force && s.at && Date.now() - s.at < AIR_EVERY - 15000) { air.list = s.list || []; air.at = s.at; air.unread = s.unread || 0; air.err = s.err || ""; return; } // অন্য ট্যাব একটু আগেই দেখেছে
      const [news, toks] = await Promise.all([airCms(), airToks()]);
      const first = !s.seen;
      const seen = new Set(s.seen || []), known = new Set(s.toks || []);
      const fresh = [];
      if (news) for (const n of news) if (!seen.has(n.id)) { seen.add(n.id); if (!first) fresh.push(n); else (s.list = s.list || []).push(n); }
      if (toks) {
        for (const t of toks) if (!known.has(t.id)) {
          known.add(t.id);
          if (s.toks) fresh.push({ id: "t" + t.id, t: T("airNewTok", t.sym, t.name && t.name !== t.sym ? t.name : "", t.chain), ts: Date.now(), src: "Binance Alpha", url: "https://www.binance.com/en/alpha" });
        }
      }
      let list = (s.list || []).concat([]);
      const shown = fresh.slice(0, 8);
      for (const f of shown) f.isNew = true;
      list = shown.concat(list).sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0) || (b.ts || 0) - (a.ts || 0)).slice(0, 60);
      air.list = list; air.at = Date.now(); air.unread = (s.unread || 0) + shown.length;
      air.err = !news && !toks ? T("airErr") : !news ? T("airErrCms") : "";
      chrome.storage.local.set({ avhAir: { seen: [...seen].slice(-600), toks: [...known], list, at: air.at, unread: air.unread, err: air.err } });
      // নতুন খবর সার্ভারে — সার্ভার সবাইকে Telegram-এ পাঠায় (Binance সার্ভারকে আটকালেও খবর পৌঁছায়)
      if (fresh.length && cfg.tgSChat && cfg.tgId) { const pr = await srv("/api/newspush", { items: fresh.slice(0, 20).map((f) => ({ id: f.id, t: f.t, url: f.url, src: f.src, ts: f.ts })) }); if (pr && pr.ok) srvNews = !!pr.newsSrv; }
      for (const f of shown) {
        log("📰 " + f.t);
        if (cfg.notifyOn) bg({ type: "avh-notify", title: "📰 " + T("airTitle"), message: f.t }); // শুধু ডেস্কটপ — Telegram নিচে আলাদা (চাইলে)
        if (cfg.airTg && tgReady() && !srvNews) await tgSend("📰 " + f.t + "\n" + f.url); // পুরনো সার্ভার (Cron ছাড়া) হলে নিজে
      }
      if (fresh.length > shown.length) log("📰 " + T("airMore", fresh.length - shown.length));
    } finally { air.busy = false; airRender(); }
  }
  async function airLoop() {
    try { const s = (await lget("avhAir")).avhAir; if (s) { air.list = s.list || []; air.at = s.at || 0; air.unread = s.unread || 0; air.err = s.err || ""; } } catch (_) {}
    airRender();
    await sleep(8000);
    for (;;) {
      try { if (cfg.airOn) await airCheck(false); } catch (_) {}
      await sleep(AIR_EVERY);
    }
  }
  try { chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.avhAir && ch.avhAir.newValue && !air.busy) { const s = ch.avhAir.newValue; air.list = s.list || []; air.at = s.at || 0; air.unread = s.unread || 0; air.err = s.err || ""; airRender(); } }); } catch (_) {}

  // ================= 📊 হিসাব ও টোকেন =================
  const p1k = (l, v) => (v > 0 ? (l / v) * 1000 : null);
  // ৪) ১৫ দিনের পয়েন্ট পরিকল্পনা: Alpha পয়েন্ট = শেষ ১৫ দিনের যোগফল; রোজ = ব্যালেন্সের পয়েন্ট + ভলিউমের পয়েন্ট (floor(log2(Buy ভলিউম × গুণক)))
  function planText(goal, bal) {
    goal = +goal || 0; bal = +bal || 0;
    if (!(goal > 0)) return T("plNeed");
    const m = [1, 2, 4].includes(+cfg.ptMult) ? +cfg.ptMult : 1;
    const perDay = Math.ceil(goal / 15), volPts = Math.max(0, perDay - bal);
    if (volPts === 0) return T("plFree", goal, perDay, bal);
    const buy = Math.pow(2, volPts) / (m * PT_SAFE), vol = buy * 2, p = per1000Hist();
    return T("plOut", goal, perDay, bal, volPts, fmtK(buy), fmtK(vol), m, p != null ? (vol * p / 1000).toFixed(2) : "–", p != null ? (vol * p * 15 / 1000).toFixed(2) : "–");
  }
  async function statsText(kind) {
    const g = await lget(["avhHourStat", "avhTokStat", "avhDayHist", "avhDay"]);
    const out = [];
    if (!kind || kind === "h") {
      const hs = (Array.isArray(g.avhHourStat) ? g.avhHourStat : []).map((x, h) => ({ h, ...x, p: p1k(x.l, x.v) })).filter((x) => x.v >= 500 && x.p != null).sort((a, b) => a.p - b.p);
      const hl = (x) => T("hsRow", String(x.h).padStart(2, "0") + ":00", x.p.toFixed(3), fmtK(x.v), x.mt ? Math.round((x.mh / x.mt) * 100) + "%" : "–");
      out.push(hs.length ? T("hsBest") + "\n" + hs.slice(0, 3).map(hl).join("\n") + (hs.length > 3 ? "\n" + T("hsWorst") + "\n" + hs.slice(-2).reverse().map(hl).join("\n") : "") : T("hsNone"));
    }
    if (!kind || kind === "t") {
      const ts = Object.entries(g.avhTokStat || {}).map(([k, x]) => ({ k, ...x, p: p1k(x.l, x.v) })).filter((x) => x.v >= 500 && x.p != null).sort((a, b) => a.p - b.p);
      out.push(ts.length ? ts.slice(0, 8).map((x) => T("tsRow", x.k, x.p.toFixed(3), fmtK(x.v), x.n)).join("\n") : T("tsNone"));
    }
    if (!kind || kind === "d") {
      const dh = (Array.isArray(g.avhDayHist) ? g.avhDayHist : []).concat(g.avhDay && g.avhDay.vol > 0 ? [g.avhDay] : []).slice(-7).reverse();
      out.push(dh.length ? dh.map((x) => T("dhRow", x.d, fmtK(x.vol), fmt(x.loss || 0), x.vol > 0 ? p1k(x.loss || 0, x.vol).toFixed(3) : "–")).join("\n") : T("dhNone"));
    }
    return out;
  }
  async function renderStats() {
    try {
      $("plOut").textContent = planText(cfg.ptGoal, cfg.ptBalPts);
      const [h, t, d] = await statsText();
      $("hsOut").textContent = h; $("tsOut").textContent = t; $("dhOut").textContent = d;
    } catch (_) {}
  }
  for (const f of ["ptGoal", "ptBalPts"]) $(f).addEventListener("change", () => setTimeout(renderStats, 50));
  $("stReset").addEventListener("click", () => { chrome.storage.local.remove(["avhHourStat", "avhTokStat"]); log("🗑 " + T("stResetDone")); renderStats(); });

  // ---------- 🔧 সবার জন্য পেজের বাটন (admin পাঠায়, সবাই নেয়) ----------
  let selPullAt = 0;
  async function selPull(force) {
    if (!tgSrvUrl() || !cfg.tgId || !cfg.tgSChat) { if (force) log("⚠ " + T("tgLinkNeed")); return false; }
    if (!force && Date.now() - selPullAt < 60000) return false;
    selPullAt = Date.now();
    if (force) log("🔄 " + T("selPulling"));
    const r = await srv("/api/selget");
    if (!r || r.ok !== true) { if (force) log("⚠ " + T("selPullFail", (r && r.description) || "no response")); return false; }
    if (!r.sel || !(r.ver > 0)) { if (force) log("🔧 " + T("selNone")); return false; }
    if (!force && r.ver <= (cfg.selVer || 0)) return false;
    let n = 0;
    for (const [k, v] of Object.entries(r.sel)) if (KEYS.includes(k) && v && typeof v === "object") { cfg.selectors[k] = v; n++; }
    cfg.selVer = r.ver; save(); renderSelectors();
    log("🔧 " + T("selGot", n) + " · " + new Date(r.ver).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })); if (tgReady()) tgSend("🔧 " + T("selGot", n));
    return n > 0;
  }
  $("selPull").addEventListener("click", () => selPull(true));
  $("selPush").addEventListener("click", async () => {
    if (!cfg.tgSChat) return log("⚠ " + T("tgLinkNeed"));
    const r = await srv("/api/selpush", { sel: cfg.selectors });
    log(r && r.ok ? "📤 " + T("selPushed") : "⚠ " + T("selPushFail", (r && r.description) || "no response"));
    if (r && r.ok) { cfg.selVer = r.ver; save(false); }
  });
  // ---------- 📱 Mini App-এর জন্য অবস্থা সার্ভারে (চলার সময় মিনিটে একবার, থামা অবস্থায় ৫ মিনিটে) ----------
  let statePushAt = 0;
  async function stateSnap() {
    const tm = timing(), d = (await lget("avhDay")).avhDay;
    const per = state.volume > 0 && state.totalLoss != null ? ((state.totalLoss - 0) / state.volume) * 1000 : null;
    const pi = cfg.ptOn ? ptInfo() : null;
    return { running: !!state.running, paused: !!paused, volume: +(+state.volume || 0).toFixed(2), target: cfg.target, trades: state.trades || 0,
      totalLoss: state.totalLoss != null ? +state.totalLoss.toFixed(4) : null, per1000: per != null ? +per.toFixed(3) : null, bal: state.lastBal != null ? +(+state.lastBal).toFixed(2) : null,
      token: tokenName(), status: stText || "", eta: tm.eta || "", dz: !!cfg.dzOn, ai: !!(cfg.aiOn && aiK()), maker: !!cfg.makerSell, danger: cfg.dzOn && dz.danger && Date.now() - dz.at < 30000 ? dz.why : "",
      aiLine: aiLastLine(), pts: pi ? pi.pts : null, mk: mkStat.try ? `${mkStat.hit}/${mkStat.try}` : "", dayVol: d && d.d === alphaDay() ? Math.round(d.vol) : 0, ver: MY_VER,
      day: alphaDay(), dayLoss: d && d.d === alphaDay() ? +(+d.loss || 0).toFixed(4) : 0, dayTr: d && d.d === alphaDay() ? d.trades || 0 : 0, dayPts: d && d.d === alphaDay() ? ptOf((d.buy || d.vol / 2) * ([1, 2, 4].includes(+cfg.ptMult) ? +cfg.ptMult : 1) * PT_SAFE) : 0, lb: cfg.lbShow !== false,
      log: [...$("log").children].slice(0, 8).map((x) => x.textContent.trim().slice(0, 140)) };
  }
  async function statePush(force) {
    if (!cfg.tgSChat || !cfg.tgId || !tgSrvUrl()) return;
    const gap = state.running ? 60000 : 300000;
    if (!force && Date.now() - statePushAt < gap) return;
    statePushAt = Date.now();
    try { await srv("/api/state", { s: await stateSnap() }); } catch (_) {}
  }

  // ---------- Telegram: ফোন থেকে নিয়ন্ত্রণ ----------
  function settingsText() {
    return T("tgSettings3", cfg.amount, cfg.amountJitter, cfg.target, cfg.minDelay, cfg.maxDelay, cfg.lossOn, cfg.maxLoss, cfg.dzOn, cfg.obOn,
      cfg.spreadOn ? cfg.maxSpread : 0, bufNow(), cfg.tgReport, paused) +
      "\n" + T("tgSetExtra", cfg.ptOn, cfg.ptMult, cfg.autoSpeed, cfg.autoCost, T(SP_NAME[sp.lvl] || "spN0") + (sp.per != null ? ", " + sp.per.toFixed(3) : ""), cfg.healOn, cfg.autoBuf) +
      "\n" + T("tgSetBull2", T(EM_LBL[cfg.entryMode]), cfg.makerSell, cfg.makerWait, mkStat.hit, mkStat.try) +
      "\n" + (cfg.dzOn && cfg.aiOn && aiK() ? T("tgSetAi", AI_NAME[aiP()], cfg.aiEvery, aiP() === "openrouter" ? T(cfg.orMode === "paid" ? "orModePaid" : "orModeFree") : aiM()) : "🤖 AI: " + T("aiTagOff"));
  }
  async function marketText() {
    const lb = liveBook();
    const a = lb && lb.ask ? +lb.ask : NaN, b = lb && lb.bid ? +lb.bid : NaN;
    const sp = a > 0 && b > 0 ? ((a - b) / ((a + b) / 2)) * 100 : null;
    const s = await profitSignal();
    const why = s && s.closes ? dzRule(s) : [];
    return T("tgMarket2", tokenName(), curPrice() || "–", sp != null ? sp.toFixed(3) : "–", s && s.closes ? s.score : "–", s && s.closes ? s.why : "–",
      why.length ? "⚠ " + why.join(" · ") : "✅ " + T("dzSafe")) +
      (dz.ai && Date.now() - dz.aiAt < 120000 ? "\n🤖 " + T("aiDz", dz.ai.danger ? T("aiDzYes") : T("aiDzNo"), dz.ai.conf, dz.ai.reason) : "");
  }
  function statusText() {
    if (paused) return T("pausedNow") + "\n" + T("tgStatus", true, state.volume.toFixed(2), cfg.target, state.trades, timing().el, "", plText(state.totalLoss, true)).split("\n").slice(1).join("\n");
    if (!state.running && canContinue()) return T("progSaved", progSnap.volume.toFixed(2), cfg.target, progSnap.trades, progSnap.totalLoss != null ? fmt(progSnap.totalLoss) : "");
    const tm = timing();
    return T("tgStatus", state.running, state.volume.toFixed(2), cfg.target, state.trades, tm.el, tm.eta, plText(state.totalLoss, true)) +
      (cfg.dzOn ? "\n⚡ " + (dz.danger ? T("stDanger", dz.why) : T("dzSafe")) : "") + (cfg.ptOn ? "\n" + ptLine() : "");
  }
  // নিয়ন্ত্রণ প্যানেল: মেসেজের নিচে চাপার বোতাম (ইনলাইন)
  // ইনলাইন বোতাম (পুরনো /panel-এর বার্তায় থাকলে) চাপলে এখনো কাজ করে
  async function handleTg(u) {
    const cq = u && u.callback_query;
    if (cq) {
      if (!cq.message || !cq.message.chat || String(cq.message.chat.id) !== String(tgChatId())) return;
      bg({ type: "avh-tg-call", token: tgTok(), method: "answerCallbackQuery", params: { callback_query_id: cq.id, text: T("pnGot", cq.data) } });
      u = { message: { chat: cq.message.chat, text: String(cq.data || "") } };
    }
    const m = u && (u.message || u.edited_message);
    if (!m || !m.text || !m.chat) return;
    if (String(m.chat.id) !== String(tgChatId())) return; // শুধু তোমার নিজের চ্যাট
    const bc = btnToCmd(m.text.trim());
    const parts = (bc || m.text.trim()).split(/\s+/);
    const cmd = parts[0].split("@")[0].toLowerCase();
    const arg = parts[1] != null ? parseFloat(parts[1].replace(",", ".")) : null;
    if (!cmd.startsWith("/")) return;
    log(T("tgCmdLog", cmd));
    if (cmd === "/run") {
      if (state.running) return tgSend(T("tgAlready"));
      const rk = startRisks();
      await tgSend(T("tgStarting") + (rk.length ? "\n⚠ " + T("tgRiskNote", rk.join(", ")) : ""));
      run();
    } else if (cmd === "/stop") {
      await tgSend(requestStop() ? T("tgStopping") : T("tgNotRunning"));
    } else if (cmd === "/settings") {
      await tgSend(settingsText());
    } else if (cmd === "/target") {
      if (arg == null) return tgSend(T("tgCur", "target", cfg.target + " USDT"));
      if (!(arg > 0)) return tgSend(T("tgBad", "/target 20000"));
      const old = cfg.target; cfg.target = arg; save(); renderInputs();
      const tm = timing();
      await tgSend(T("tgTargetOk", old, arg, state.volume.toFixed(0), Math.min(100, (state.volume / arg) * 100).toFixed(0), state.running ? tm.eta : "") +
        (state.running && state.volume >= arg ? "\n" + T("tgTargetBelow") : ""));
      log(T("cfgChanged", "target", old, arg));
    } else if (cmd === "/amount") {
      if (arg == null) return tgSend(T("tgCur", "amount", cfg.amount + " USDT"));
      if (!(arg >= 1)) return tgSend(T("tgBad", "/amount 50"));
      if (state.lastBal != null && arg > state.lastBal) return tgSend(T("tgAmountHigh", arg, state.lastBal));
      const old = cfg.amount; cfg.amount = arg; save(); renderInputs();
      await tgSend(T("tgAmountOk", old, arg, state.running));
      log(T("cfgChanged", "amount", old, arg));
    } else if (cmd === "/random") {
      if (arg == null) return tgSend(T("tgCur", "random", "±" + cfg.amountJitter + "%"));
      if (!(arg >= 0 && arg <= 50)) return tgSend(T("tgBad", "/random 5  (0–50)"));
      const old = cfg.amountJitter; cfg.amountJitter = arg; save(); renderInputs();
      await tgSend(T("tgRandomOk", old, arg, cfg.amount));
      log(T("cfgChanged", "random", old, arg));
    } else if (cmd === "/pause") {
      await tgSend(setPaused(true) ? T("tgPaused") : state.running ? T("tgAlreadyPaused") : T("tgNotRunning"));
    } else if (cmd === "/resume") {
      await tgSend(setPaused(false) ? T("tgResumed") : T("tgNotPaused"));
    } else if (cmd === "/reset") {
      await tgSend(resetProgress() ? T("resetDone") : T("resetRunning"));
    } else if (cmd === "/status") {
      await tgSend(statusText());
    } else if (cmd === "/today") {
      const d = (await lget("avhDay")).avhDay, today = alphaDay();
      const s = d && d.d === today ? d : { vol: 0, trades: 0, loss: 0 };
      await tgSend(T("tgToday", today, s.vol.toFixed(2), s.trades, plText(s.loss, true) || "0", s.vol > 0 ? ((s.loss / (s.vol / 2)) * 1000).toFixed(3) : "–"));
    } else if (cmd === "/price" || cmd === "/market") {
      await tgSend(await marketText());
    } else if (cmd === "/balance") {
      let b = state.lastBal;
      if (!state.running) { const el = cfg.selectors.balanceText ? find("balanceText") : null; const v = readNum(el); if (v != null) b = v; }
      await tgSend(T("tgBal", b != null ? (+b).toFixed(2) : "–", state.startBal != null ? (+state.startBal).toFixed(2) : "–", plText(state.totalLoss, true) || "–", +(state.dust || 0).toFixed(4)));
    } else if (cmd === "/entry" || (cmd === "/bull" && /^(stable|bull|off)$/i.test(parts[1] || ""))) {
      const v = (parts[1] || "").toLowerCase();
      if (!["stable", "bull", "off"].includes(v)) return tgSend(T("tgEntryHelp", T(EM_LBL[cfg.entryMode])));
      cfg.entryMode = v; clampCfg(); bullCache = null; bullLog = ""; save(); renderInputs();
      await tgSend("✅ " + T("emSet", T(EM_LBL[cfg.entryMode])));
    } else if (cmd === "/bull") {
      const v = (parts[1] || "").toLowerCase();
      cfg.entryMode = v === "off" ? "stable" : v === "on" ? "bull" : cfg.entryMode === "bull" ? "stable" : "bull";
      clampCfg(); bullCache = null; bullLog = ""; save(); renderInputs();
      await tgSend("✅ " + T("emSet", T(EM_LBL[cfg.entryMode])));
    } else if (cmd === "/aievery") {
      if (!(arg >= 15 && arg <= 600)) return tgSend(T("tgAiEvery", cfg.aiEvery));
      cfg.aiEvery = clampVal("aiEvery", arg); save(); renderInputs();
      await tgSend("✅ " + T("aiEverySet", cfg.aiEvery));
    } else if (cmd === "/aipaid") {
      const v = (parts[1] || "").toLowerCase();
      cfg.orMode = v === "off" ? "free" : v === "on" ? "paid" : cfg.orMode === "paid" ? "free" : "paid";
      save(); renderInputs();
      await tgSend("✅ " + T("orModeSet", T(cfg.orMode === "paid" ? "orModePaid" : "orModeFree")) + (aiP() !== "openrouter" ? "\n" + T("orOnlyNote") : ""));
    } else if (cmd === "/news" || cmd === "/airdrop" || cmd === "/air") {
      const v = (parts[1] || "").toLowerCase();
      if (v === "on" || v === "off") { cfg.airTg = v === "on"; if (cfg.airTg) cfg.airOn = true; save(); renderInputs(); return tgSend((cfg.airTg ? "✅ " : "⏹ ") + T("airTgSet", cfg.airTg)); }
      if (!air.list.length) await airCheck(true);
      await tgSend("📰 " + T("airTitle") + "\n\n" + (air.list.slice(0, 8).map((x) => "• " + x.t + "\n" + x.url).join("\n\n") || T("airNone")) + "\n\n" + T("airTgHint"));
    } else if (cmd === "/plan") {
      if (arg != null && arg >= 0) { cfg.ptGoal = clampVal("ptGoal", arg); if (parts[2] != null && isFinite(+parts[2])) cfg.ptBalPts = clampVal("ptBalPts", +parts[2]); save(); renderInputs(); }
      await tgSend("🏅 " + T("plTitle") + "\n\n" + planText(cfg.ptGoal, cfg.ptBalPts) + "\n\n" + T("plHelp"));
    } else if (cmd === "/stats") {
      const [h, t, d] = await statsText();
      await tgSend(T("hsTitle") + "\n" + h + "\n\n" + T("tsTitle") + "\n" + t + "\n\n" + T("dhTitle") + "\n" + d);
    } else if (cmd === "/stopafter") {
      if (arg == null || !(arg >= 0)) return tgSend(T("tgStopAfterHelp", cfg.stopAfter));
      cfg.stopAfter = clampVal("stopAfter", arg); save(); renderInputs();
      await tgSend("⏰ " + (cfg.stopAfter > 0 ? T("stopAfterSet", cfg.stopAfter) : T("stopAfterOff")));
    } else if (cmd === "/stopat") {
      const v = (parts[1] || "").trim();
      if (/^off$/i.test(v)) cfg.stopAt = "";
      else if (/^\d{1,2}:\d{2}$/.test(v)) cfg.stopAt = v.padStart(5, "0");
      else return tgSend(T("tgStopAtHelp", cfg.stopAt || "—"));
      save(); renderInputs(); if (state.running) state.stopAtTs = stopAtTs();
      await tgSend("⏰ " + (cfg.stopAt ? T("stopAtSet", cfg.stopAt) : T("stopAtOff")));
    } else if (cmd === "/aistat") {
      if ((parts[1] || "").toLowerCase() === "reset") { aiStat = {}; aiPend = []; try { chrome.storage.local.set({ avhAiStat2: {} }); } catch (_) {} return tgSend("✅ " + T("aiStatReset")); }
      await tgSend((aiLastLine() ? aiLastLine() + "\n\n" : "") + "🤖 " + aiStatText());
    } else if (cmd === "/maker") {
      const key = "makerSell", v = (parts[1] || "").toLowerCase();
      cfg[key] = v === "on" ? true : v === "off" ? false : !cfg[key];
      save(); renderInputs();
      await tgSend((cfg[key] ? "✅ " : "⏹ ") + T("tgMakerSet", cfg[key]) + (key === "makerSell" && mkStat.try ? "\n" + T("mkStatLine", mkStat.hit, mkStat.try) : ""));
    } else if (cmd === "/points" || cmd === "/pt") {
      const v = (parts[1] || "").toLowerCase().replace(/^x|×/, "");
      if (v === "on" || v === "off") { cfg.ptOn = v === "on"; ptPlan = null; save(); renderInputs(); await tgSend((cfg.ptOn ? "✅ " : "⏹ ") + T("tgPtSet", cfg.ptOn)); }
      else if (["1", "2", "4"].includes(v)) { cfg.ptMult = +v; ptPlan = null; save(); renderInputs(); await tgSend("✅ " + T("tgPtMult", cfg.ptMult)); }
      else await tgSend(cfg.ptOn ? ptLine() : T("ptOff"));
    } else if (cmd === "/danger") {
      const v = (parts[1] || "").toLowerCase();
      cfg.dzOn = v === "on" ? true : v === "off" ? false : !cfg.dzOn;
      aiSync(); save(); renderInputs();
      await tgSend((cfg.dzOn ? "✅ " : "⏹ ") + T("tgDzSet", cfg.dzOn));
    } else if (cmd === "/ai") {
      const v = (parts[1] || "").toLowerCase();
      cfg.aiWant = v === "on" ? true : v === "off" ? false : !cfg.aiOn;
      if (cfg.aiWant && !aiK()) { cfg.aiWant = false; aiSync(); save(); renderInputs(); return tgSend("⚠ " + T("aiNoKey")); }
      if (cfg.aiWant) cfg.dzOn = true; // AI চলে বিপদে থামোর ভেতরে
      aiSync(); save(); renderInputs();
      await tgSend((cfg.aiOn ? "✅ " : "⏹ ") + T("tgAiSet", cfg.aiOn));
    } else if (cmd === "/preset") {
      const p = (parts[1] || "").toLowerCase();
      if (!PRESETS[p]) return tgSend(T("tgPresetHelp"));
      if (state.running) return tgSend(T("tgModeBusy"));
      Object.assign(cfg, PRESETS[p]); clampCfg(); save(); renderInputs();
      await tgSend("✅ " + T("psDone", p === "fast" ? T("psFast") : T("psSafe")));
    } else if (cmd === "/maxloss") {
      if (arg == null) return tgSend(T("tgCur", "maxloss", cfg.lossOn ? cfg.maxLoss + " USDT" : "off"));
      if (!(arg >= 0)) return tgSend(T("tgBad", "/maxloss 20  (0 = বন্ধ)"));
      cfg.lossOn = arg > 0; if (arg > 0) cfg.maxLoss = arg; save(); renderInputs();
      await tgSend("✅ " + T("tgMaxLossOk", cfg.lossOn ? arg + " USDT" : "off"));
    } else if (cmd === "/delay") {
      const a = arg, b2 = parts[2] != null ? parseFloat(parts[2]) : a;
      if (!(a >= 1) || !(b2 >= a)) return tgSend(T("tgBad", "/delay 2 4"));
      cfg.minDelay = a; cfg.maxDelay = b2; clampCfg(); save(); renderInputs();
      await tgSend("✅ " + T("tgDelayOk", cfg.minDelay, cfg.maxDelay));
    } else if (cmd === "/report") {
      const v = (parts[1] || "").toLowerCase();
      cfg.tgReport = v === "on" ? true : v === "off" ? false : !cfg.tgReport; save();
      await tgSend(T("tgReportSet", cfg.tgReport));
    } else if (cmd === "/sellall") {
      if (state.running) return tgSend(T("tgModeBusy"));
      try {
        await switchTab("sellTab", "sell"); await clickOrderType();
        const held = await readSellAvailable();
        if (!(held > 0)) return tgSend(T("tgNoHeld"));
        state.keep = 0; state.dust = 0;
        await doSell(); await settleOrders();
        await tgSend("✅ " + T("tgSoldAll", +held.toFixed(6)));
      } catch (e) { await tgSend("❌ " + e.message); }
    } else if (cmd === "/log") {
      const n = Math.max(5, Math.min(30, arg > 0 ? arg : 15));
      const rows = [...$("log").children].slice(0, n).reverse().map((r) => [...r.children].map((x) => x.textContent.trim()).join(" "));
      await tgSend("📜 " + T("tgLogHead", rows.length) + "\n\n" + (rows.join("\n") || "—"));
    } else if (cmd === "/reload") {
      if (state.running && parts[1] !== "now") return tgSend(T("tgReloadBusy"));
      await tgSend("🔄 " + T("tgReloading"));
      try { chrome.storage.local.set({ avhReloadAt: Date.now() }); } catch (_) {}
      log("🔄 " + T("tgReloading"));
      await sleep(800);
      unloading = true; releaseLock();
      location.reload();
    } else if (cmd === "/menu") {
      await tgMenuSync(true);
    } else if (cmd === "/start" || cmd === "/help") {
      await tgSend(T("tgHelp"), tgKeyboard());
    } else if (cmd === "/shot") {
      const r = await shotSend(shotCap(""));
      if (!r.ok) await tgSend(shotErr(r));
    } else if (cmd === "/live") {
      startLive(arg);
    } else if (cmd === "/stoplive") {
      if (live) { live.stop = true; } else await tgSend(T("liveNone"));
    } else {
      await tgSend(T("tgHelp")); // /start, /help ও অন্য সব কমান্ডে শুধু সাহায্য — /start দিয়ে ট্রেড শুরু হয় না
    }
  }
  // ---------- /shot ও /live: Binance পেজের ছবি ----------
  let live = null; // { stop, until }
  const hms = () => new Date().toLocaleTimeString("en-GB", { hour12: false });
  function shotCap(extra) {
    const st = state.running ? (paused ? T("livePaused") : T("liveRunning")) : T("liveIdle");
    return "📸 Binance · " + hms() + (extra ? " · " + extra : "") + "\n" + st + " · " + state.volume.toFixed(2) + " / " + cfg.target + " USDT · " + T("liveTrades", state.trades) +
      (state.totalLoss != null && state.trades ? " · " + plText(state.totalLoss, true) : "");
  }
  function shotErr(r) {
    if (r.why === "hidden") return T("shotHidden");
    return T("shotFail", r.description || r.why || "?");
  }
  async function shotSend(caption, editId) {
    if (document.hidden) return { ok: false, why: "hidden" };
    const r = await bg({ type: "avh-shot", token: tgTok(), chat: tgChatId(), caption, editId }, 30000);
    return r || { ok: false, why: "err", description: "timeout" };
  }
  async function startLive(sec) {
    const dur = Math.max(15, Math.min(300, sec > 0 ? sec : 60));
    if (live) { live.until = Date.now() + dur * 1000; return tgSend(T("liveExtended", dur)); }
    const L = (live = { stop: false, until: Date.now() + dur * 1000 });
    try {
      const left = () => Math.max(0, Math.round((L.until - Date.now()) / 1000));
      let r = await shotSend(shotCap("🔴 LIVE · " + T("liveLeft", left())));
      if (!r.ok) { await tgSend(shotErr(r)); return; }
      const id = r.id;
      log(T("liveLog", dur));
      let fails = 0;
      while (!L.stop && Date.now() < L.until) {
        await sleep(3000);
        if (L.stop) break;
        r = await shotSend(shotCap("🔴 LIVE · " + T("liveLeft", left())) + "\n" + T("liveHint"), id);
        if (r.ok || /not modified/i.test(r.description || "")) fails = 0;
        else if (r.why === "hidden") {
          if (++fails === 1) await bg({ type: "avh-tg-edit", token: tgTok(), chat: tgChatId(), id, caption: shotCap("⏸") + "\n" + T("shotHidden") });
          if (fails >= 20) break; // ~১ মিনিট সামনে না এলে বন্ধ
        } else if (/too many|retry after/i.test(r.description || "")) await sleep(5000);
        else if (++fails >= 5) break;
      }
      await bg({ type: "avh-tg-edit", token: tgTok(), chat: tgChatId(), id, caption: shotCap("⏹ " + T("liveEnded")) });
      if (L.stop) await tgSend("⏹ " + T("liveStopped"));
    } finally { if (live === L) live = null; }
  }

  // অনেকক্ষণ (১০ মিনিট) কোনো ট্রেড না হলে Telegram-এ একবার খবর
  let lastTradeAt = Date.now(), idleWarned = false, wasRunning = false;
  setInterval(() => {
    if (!state.running) { wasRunning = false; return; }
    if (!wasRunning) { wasRunning = true; lastTradeAt = Date.now(); idleWarned = false; }
    if (paused) { lastTradeAt = Date.now(); return; }
    const min = (Date.now() - lastTradeAt) / 60000;
    if (min >= 10 && !idleWarned && tgReady()) {
      idleWarned = true;
      tgSend("⏳ " + T("tgIdle", Math.floor(min), stText || T("stRun")) + "\n" + statusText());
    }
  }, 30000);

  // প্রতি ঘণ্টায় ছোট রিপোর্ট (Telegram /report on)
  let lastHourly = Date.now();
  setInterval(async () => {
    if (!cfg.tgReport || !tgReady() || !state.running || Date.now() - lastHourly < 3600000) return;
    lastHourly = Date.now();
    const d = (await lget("avhDay")).avhDay;
    tgSend("🕐 " + T("tgHourly") + "\n" + statusText() + (d ? "\n" + T("tgTodayShort", d.vol.toFixed(0), d.trades, plText(d.loss, true)) : ""));
  }, 60000);

  let tgOkLogged = false;
  async function tgLoop() {
    let lastErr = "";
    for (;;) {
      if (!tgReady() || otherTabRunning()) { await sleep(5000); continue; }
      const r = await bg({ type: "avh-tg-poll", token: tgTok() }, 35000);
      if (!r || r.busy) { await sleep(3000); continue; }
      if (r.ok === false) {
        const e = r.description || "?";
        if (e !== lastErr) { log(/conflict/i.test(e) ? T("tgConflict") : /unauthorized|not found/i.test(e) ? T("tgBadToken") : T("tgErr", e)); lastErr = e; }
        await sleep(15000);
        continue;
      }
      if (lastErr || !tgOkLogged) {
        log(T("tgConnected")); tgOkLogged = true;
        tgMenuSync(false);
        const d = await lget(["avhReloadAt", "avhHealWhy"]);
        if (d.avhReloadAt && Date.now() - d.avhReloadAt < 10 * 60000) {
          chrome.storage.local.remove(["avhReloadAt", "avhHealWhy"]);
          const w = d.avhHealWhy === "frozen" ? T("healFrozen") : d.avhHealWhy;
          tgSend("✅ " + (w ? T("healDone", w) : T("tgReloaded")) + "\n" + statusText(), tgKeyboard());
        }
      }
      lastErr = "";
      for (const u of r.result || []) { try { await handleTg(u); } catch (_) {} }
    }
  }

  // ---------- শুরু ----------
  let unloading = false;
  window.addEventListener("pagehide", () => { unloading = true; releaseLock(); });

  chrome.storage.local.get(["avhCfg", "avhVisible", "avhPos", "avhMin", "avhRun", "avhLock", "avhPt", "avhReloadAt", "avhHealWhy", "avhAP"], (d) => {
    lockCache = d.avhLock || null;
    if (d.avhPt && d.avhPt.d) ptDay = d.avhPt;
    const healed = !!d.avhHealWhy && Date.now() - (d.avhReloadAt || 0) < 10 * 60000;
    if (d.avhCfg) cfg = { ...cfg, ...d.avhCfg, selectors: { ...(d.avhCfg.selectors || {}) } };
    if (d.avhCfg && !(d.avhCfg.cfgVer >= 2)) {
      // পুরনো ডিফল্ট বিরতি (৩–৬ সে.) থাকলে নতুন ডিফল্ট ৫–১০ সে.
      if (cfg.minDelay === 3 && cfg.maxDelay === 6) { cfg.minDelay = 5; cfg.maxDelay = 10; }
      if (cfg.sellStep == null) cfg.sellStep = 0.05;
      cfg.cfgVer = 2; save();
    }
    // পুরনো "প্রতি 100" সীমা → "প্রতি 1000" (১০ গুণ), আচরণ একই থাকে
    if (d.avhCfg && d.avhCfg.maxPer100 != null && d.avhCfg.maxPer1000 == null) { cfg.maxPer1000 = +(d.avhCfg.maxPer100 * 10).toFixed(4); delete cfg.maxPer100; save(); }
    if ("keepHeld" in cfg) { delete cfg.keepHeld; save(); }
    if (/^llama-/i.test(cfg.aiModelGroq || "")) { cfg.aiModelGroq = "qwen/qwen3.8-27b"; save(false); } // Groq ফ্রি key-তে Llama বন্ধ
    if (!I18N[cfg.lang]) cfg.lang = "bn";
    // ৬.২: বাদ দেওয়া ফিচারের পুরনো সেটিং মুছে ফেলা
    for (const k of ["makerBuy", "makerBuyWait", "sizeAuto", "resumeOn", "tgOn", "tgToken", "tgChat", "tgMode", "tgSrv", "reportName", "v581", "aiKey", "aiModel"]) if (k in cfg) { delete cfg[k]; save(false); }
    if (d.avhCfg && !d.avhCfg.v570) { cfg.airOn = cfg.airOn !== false; cfg.airTg = cfg.airTg !== false; cfg.v570 = true; save(false); }
    if (d.avhCfg && !d.avhCfg.v561) { cfg.aiEvery = 15; cfg.v561 = true; save(false); } // ৫.৬.১: AI প্রতি ১৫ সে.
    if (d.avhCfg && !d.avhCfg.v560) { if (cfg.aiWant == null) cfg.aiWant = true; cfg.v560 = true; aiSync(); save(false); }
    if (d.avhCfg && !d.avhCfg.v550) { if (cfg.obOn == null) cfg.obOn = true; if (cfg.makerAuto == null) cfg.makerAuto = true; cfg.v550 = cfg.v540 = true; clampCfg(); save(false); try { chrome.storage.local.remove(["avhAiStat", "avhOrModels"]); } catch (_) {} }
    if (d.avhCfg && !d.avhCfg.v530) { if (cfg.autoCost === 0.05) cfg.autoCost = 0.2; cfg.autoSpeed = true; cfg.v530 = true; save(false); }
    if (d.avhCfg && !d.avhCfg.v510) { cfg.entryMode = "stable"; cfg.dzOn = true; cfg.v510 = true; save(false); }
    if (d.avhCfg && !d.avhCfg.v420) { if (cfg.makerWait === 8) cfg.makerWait = 4; cfg.v420 = true; save(false); }
    if (d.avhCfg && !d.avhCfg.v400) { if (cfg.autoCost === 0.4) cfg.autoCost = 0.05; cfg.makerSell = true; cfg.v400 = true; save(false); }
    clampCfg();
    if (chrome.storage.sync) {
      try {
        chrome.storage.sync.get(["avhSyncA", "avhSyncS"], (sd) => {
          if (chrome.runtime.lastError || !cfg.syncOn || state.running) return;
          applySync(sd.avhSyncA, sd.avhSyncS, "syncIn");
        });
        chrome.storage.onChanged.addListener((ch, area) => {
          if (area !== "sync" || !cfg.syncOn || !ch.avhSyncA) return;
          if (state.running) { log(T("syncLater")); return; }
          chrome.storage.sync.get(["avhSyncA", "avhSyncS"], (sd) => applySync(sd.avhSyncA, sd.avhSyncS, "syncIn"));
        });
      } catch (_) {}
    }
    if (d.avhMin) { $("panel").classList.add("min"); $("min").textContent = "+"; }
    if (d.avhPos) requestAnimationFrame(() => placeAt(d.avhPos.x, d.avhPos.y));
    renderInputs();
    applyI18n();
    const onAlpha = /\/alpha/i.test(location.pathname);
    if (d.avhVisible !== false && onAlpha) setVisible(true);
    if (!onAlpha) return;
    spreadGauge();
    chartLoop();
    tgLoop();
    airLoop();
    setTimeout(() => dayRoll(), 15000); setInterval(() => dayRoll(), 60000); // সকাল ৬টায় (UTC দিন বদল) আগের দিনের রিপোর্ট
    if (tgShared()) { tgSrvCheck(); setInterval(() => { tgSrvCheck(); }, 10 * 60000); setInterval(() => { statePush(false); }, 20000); setTimeout(() => statePush(true), 12000); }
    if (aiP() === "openrouter") orLoad(false);
    if (d.avhAP) chrome.storage.local.remove("avhAP");
    const rs = d.avhRun;
    progSnap = rs || null;
    renderProgress();
    if (rs && rs.active && otherTabRunning()) {
      // অন্য ট্যাবে বট চলছে — এই ট্যাব রিজিউম করবে না, সেভ করা অবস্থাও ছোঁবে না
      log(T("otherTabIdle"));
    } else if (rs && rs.active) {
      if (healed && Date.now() - rs.ts < 30 * 60 * 1000) {
        setVisible(true);
        log(T("reloadWait"));
        let cancelled = false;
        const onStop = () => { cancelled = true; log(T("reloadCancel")); progSnap = { ...rs, active: false }; chrome.storage.local.set({ avhRun: progSnap }); renderProgress(); };
        $("stop").addEventListener("click", onStop, { once: true });
        sleep(10000).then(async () => {
          $("stop").removeEventListener("click", onStop);
          if (cancelled || state.running) return;
          // ব্রাউজার ক্র্যাশের পর পুরনো লক থাকতে পারে — বাসি হওয়া পর্যন্ত অপেক্ষা; অন্য ট্যাব সত্যিই চললে বাদ
          const t0 = Date.now();
          while (otherTabRunning() && Date.now() - t0 < LOCK_STALE + 5000) await sleep(5000);
          if (otherTabRunning()) return log(T("otherTabIdle"));
          if (!state.running) { notify("Alpha Volume Helper", T("reloadNote")); run({ resume: rs }); }
        });
      } else { progSnap = { ...rs, active: false }; chrome.storage.local.set({ avhRun: progSnap }); renderProgress(); }
    }
  });
})();
